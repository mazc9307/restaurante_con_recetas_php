
<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="./favicon.ico">
    <title>Soul 45</title>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap/css/floating-labels.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    
  </head>

  <body>
      <form method="post" class="form-signin">
      <div class="text-center mb-4">
        <!--<img class="mb-4" src="" alt="" width="72" height="72"> -->
          <h1 class="h3 mb-3 font-weight-normal"><img src="img/logo.png"></h1>
      </div>
      <div class="text-center mb-4">
        <!--<img class="mb-4" src="" alt="" width="72" height="72"> -->
        <h1 class="h5 mb-3 font-weight-normal">Bienvenido</h1>
      </div>

      <div class="form-label-group">
          <input type="input"name="usuario" id="inputUser" class="form-control" placeholder="Usuario" required autofocus>
        <label for="inputUser">Usuario</label>
      </div>

      <div class="form-label-group">
          <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Contraseña" required>
        <label for="inputPassword">Contraseña</label>
      </div>

      <div class="checkbox mb-3">
          
          <?php include("validate_user.php"); ?>
          
      </div>
      <button class="btn btn-lg btn-primary btn-block" type="submit">Ingresar</button>
      <p class="mt-5 mb-3 text-muted text-center">&copy; 2020</p>
    </form>
  </body>
</html>
