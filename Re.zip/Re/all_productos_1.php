                   
<?php 

 include ('class/usuarios.php');
$usuariosCon = new Usuarios(); ?>
<div class="row">
                        
	         
                        <div class="card shadow mb-4" style="width: 99%;">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Productos / Mesa: <?php echo @$mesan; ?></h6>
                        </div>
                        <div class="card-body">
                            
                            <div class="table-responsive">
                                <table class="table table-bordered"  id="dataTable" width="100%" cellspacing="0">
                                  <thead>
                              <tr>
                                
                                  <th>#</th>
                                  <th>Cod</th>
                                  <th>Descripcion</th>
                                  <th>Stock</th>
                                  <th>Vr un</th>
                                  <th>Categoria</th>
                                  <th>Cantidad  </th>
                                 
                                  
                                 
                              </tr>
           
                              <?php 
				
                                
                                
                             
				
				?>
                              </thead>
                              
                              <tbody>
                                  <?php 
                                  $num =1;
                                  
                                  $productos=$usuariosCon->all_product();
					while ($pro=mysqli_fetch_object($productos)){
                                            
                                            $num2=$num++;
						$des=$pro->Descripcion_p;
						$enlace=$pro->Enlace;
						$vru=$pro->Valor_unitario;
						$iva=$pro->Iva;
						$cat=$pro->categoria;
						$cod_p=$pro->Cod_producto;
						$stock=$pro->Stock;
                                               
                                                
				?>
                              <tr class="">
                                  
                             
                                  <input type="hidden" name="mesa" value="<?php echo $mesan; ?>">
                                  <td><?php echo $num2; ?></td>
                                  <td><?php echo $cod_p;?></td>
                                  <td><?php echo $des;?></td>
                                  <td><?php echo $stock;?></td>
                                  <td>$ <?php echo $vru;?></td>
                                  <td><?php echo $cat;?></td>
                                  <td>
                                      <form action="#logoutModal1" method="post">
                                          <input type="hidden" name="pedido_i" value="<?php echo $numpedido; ?>" min="1" max="50">
                                          <input type="hidden" name="producto" value="<?php echo $cod_p; ?>" min="1" max="50">
                                          <input type="hidden" name="precio" value="<?php echo $vru; ?>" min="1" max="50">
                                          <input type="hidden" name="m" value="<?php echo @$mesan; ?>" min="1" max="50">
                                          <input type="hidden" name="estadomesa" value="<?php echo @$estadomesa; ?>" min="1" max="50">
                                          <input type="number" name="cantitem" value="1" min="1" max="<?php echo $stock; ?>">
                                  
                                       <button class="btn btn-info">+</button></td>
                               </form>
                                  
                              </tr>
                              <?php
					}
                                        
                                
				?>
                          
                        
                                </table>
                            </div>
                        </div>
                   
                    </div>
                  
                      <?php if( @$estadomesa == 2){ ?> 
                        
                         
                        
                        
   <div class="modal fade" id="logoutModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                   
                            <h6 class="m-0 font-weight-bold text-primary"> Pedido: <?php
                           
                            
                            $pedidomesa=$usuariosCon->mesa_pedido($mesan);
					while ($pem=mysqli_fetch_object($pedidomesa)){
                                            
                                           
						$numpedido=$pem->Cod_pedido;
						$cuentap=$pem->nump;
                                        
                                        if($cuentap==0){            
                                        $creapedido=$usuariosCon->creapedido($mesan,$user);
                                        $pedidomesa=$usuariosCon->mesa_pedido($mesan);
                                        while ($pem=mysqli_fetch_object($pedidomesa)){  
                                            
                                            $cuentap=$pem->nump;
                                            $numpedido=$pem->Cod_pedido;
                                            echo $numpedido;
                                            
                                        }
                                        }elseif ($cuentap>0) {
                                        echo $numpedido;
                                        }}
                                        
                                        
                       $pediodof=$numpedido;
                       @$productof=$_POST['producto'];
                       @$preciof=$_POST['precio'];
                       @$cantf=$_POST['cantitem'];
                       $preciot= $cantf*$preciof;
                          
                          if(@$productof==null){
                             
                          }else{
                          $pedidoLinea=$usuariosCon->creapedidolinea($pediodof,$productof,$cantf,$preciof,$preciot);
                          
                          $resta=$stock-$cantf;
                          
                          $sstock=$usuariosCon->Stock_b($productof);
                          $stockl=mysqli_fetch_object($sstock);
                          
                          $s1=$stockl->s1;
                          
                          $s2= $s1-$cantf;
                          $updatestock=$usuariosCon->Stock_u($productof,$s2);
                         
                          
                          }
                             
                            ?></h6>
                        </div>   
                                                   
                 <div class="card shadow mb-6">
                        
                     <form method="post">
                         <input value="1" name="estadomesa" type="hidden" >
                            <input type="hidden" name="m" value="<?php echo @$mesan; ?>">   
                         <input type="hidden" name="pedidoc" value="<?php echo @$pediodof; ?>" min="1" max="50">
                           <br>   
                           <button class="btn btn-sm btn-danger">Cancelar Pedido</button>         
                            </form>
                     <br>
                     <table class="table table-bordered">
                         <thead>
                         <th>#</th><th>Item</th><th>Cant</th><th>Linea total</th><th>Accion</th>
                         </thead>
                         
                         <?php 
                         $Num2 = 0;
                         $pedidomesalinea=$usuariosCon->mesa_pedido_suma_linea($numpedido);
					while ($linea=mysqli_fetch_object($pedidomesalinea)){
                                            
                                           $Num2++;
						$productolinea=$linea->cod_producto;
						$cantlinea=$linea->cant;
						$ltotal=$linea->lt;
						$dp=$linea->Descripcion_p;
						$idpedido=$linea->id;
                         
                         ?>
                         <tr>
                             <td><?php echo $Num2; ?></td>
                             <td><?php echo $dp; ?></td><td><?php echo $cantlinea; ?></td><td>$ <?php echo $ltotal; ?></td>
                             <td>
                                 <form method="post">
                                     <input type="hidden" name="m" value="<?php echo @$mesan; ?>" min="1" max="50">
                                          <input type="hidden" name="estadomesa" value="<?php echo @$estadomesa; ?>" min="1" max="50">
                                      
                                     <input type="hidden" value="<?php echo $idpedido; ?>" name="idlinea" >
                                 <button class="btn btn-danger">x</button>
                                 </form>
                             </td>
                         </tr>
                         
                         <?php 
                         
                                        }
                         
                         ?>
                     </table>
                        
  <div class="card-footer text-muted">
   Total: $ <?php 
   
   $totalpedido=$usuariosCon->pedido_total($numpedido);
   $pediototal=mysqli_fetch_object($totalpedido);
   
    $total=$pediototal->totalp;
    
    echo $total;
   
   ?>
  </div>
                    </div>
                 </div>
                 </div>
                 </div>
                
                        
                      <?php }  ?>
 
            </div>


 <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>