 <?php   session_start(); 
 @$user = $_SESSION["k_username"]; 
 @$tip_user = $_SESSION["tipo_user"];
 @$EmpresAct = $_SESSION["EmpresAct"];
 @$Cod_Empresa = $_SESSION["Cod_Empresa"];
 @$Numdoc = $_SESSION["Numdoc"];
 
 if($user== null){
          
     ?>
     
     <script language="javascript" type="text/javascript">                        
		window.location="logout.php";
		</script>
     <?php
 }else{
 
 ?>
<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Mesas</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
     <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
      <link href="tablab/jquery.dataTables.min.css" rel="stylesheet">


</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
   <?php   include 'class/menu.php' ?>
<?php   include './menu_user.php'; ?>
        
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <?php   include './menu_notifi.php'; 
               
               
               include ('class/usuarios.php');
				$usuariosCon = new Usuarios();
                              ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                   <!-- Content Row -->
                   <?php 
                     @$mesa = $_POST["mesa"];
                            @$descripcion = $_POST["descripcion"];
                            @$aforo = $_POST["aforo"];
                            
                            
                            if($mesa==null){
                                
               
                            }else{
                                
                                
                               ?>
                
                <div   class="alert alert-success" >
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                <?php $pr=$usuariosCon->creamesa($mesa,$descripcion,$aforo); ?>  
                
		</div>
                
                <?php
                            }
                            
@$mesa2=$_POST["mesa2"];
@$descripcions2 =$_POST["des2"];
@$aforo2=$_POST["aforo2"];
@$estados2=$_POST["estados2"];

if(@$mesa2==null){
    
    
}else{
    
                  ?>
                
                <div   class="alert alert-success" >
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                <?php $pr=$usuariosCon->uamesa($estados2,$aforo2,$descripcions2,$mesa2); ?>  
                
		</div>
                
                <?php
    
    
    
}
                              
                            
                            ?>
         
                   
                   <?php 
                   
                   @$update = $_POST["pedido"];
                   
                   if($update==null) {
                       
                       ?>
                   
                    <form method="post" id="formulario" class="card card-body col-sm-7 mx-auto" >
                        
          <div class="input-group mb-3">
              <h1>Crear Mesa</h1>  
          </div><!--/form-group-->
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Cod Mesa</label>
          <div class="col-sm-9">
              <input value="" placeholder="Cod Mesa" maxlength="20"  name="mesa" required="true" type="text" />
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Descripcion</label>
          <div class="col-sm-9">
          <input value="" placeholder="Cod Mesa" name="descripcion" type="text" />
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Aforo</label>
          <div class="col-sm-9">
              <input placeholder="Aforo" name="aforo" type="number" maxlength="2" max="20" min="1" />
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label"></label>
          <div class="col-sm-9">
              <input value="Crear" name="crear" required="true" type="submit" maxlength="2" max="20" min="1" />
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
                
          </form>
                   
                   <br>
                   <br>
                                <?php 

                       
                       
                   }else{
                       
                       $mesa=$usuariosCon->mesa_b($update);
                       $pro2=mysqli_fetch_object($mesa);
                       
                                                $nums2=$pro2->Cod;
						$estado=$pro2->estado;
						$cestado=$pro2->code1;
						$aforo=$pro2->aforo;
						$ref=$pro2->descripcion;
                   
                   ?>
                   
                    <form method="post" id="formulario" class="card card-body col-sm-7 mx-auto" >
                        <h1>Actualizar Mesa</h1>
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Cod Mesa</label>
          <div class="col-sm-9">
              <input readonly="true" value="<?php  echo $nums2;?>" placeholder="Cod Mesa" maxlength="20"  name="mesa2" required="true" type="text" />
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Descripcion</label>
          <div class="col-sm-9">
          <input value="<?php  echo $ref;?>" placeholder="descripcion (opcional)" name="des2" type="text" />
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Aforo</label>
          <div class="col-sm-9">
              <input value="<?php  echo $aforo;?>" placeholder="Aforo" name="aforo2" type="number" maxlength="2" max="20" min="1" />
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          <div class="form-group">
                    <label  class="col-sm-3 control-label">Estado</label>
                  <div class="col-sm-9">
                      
                      <select required name="estados2" class="form-control" id="busqueda">
                   <option  value="<?php echo $cestado; ?>"><?php echo $estado; ?></option>
                      <?php 
                                        $estadi=$usuariosCon->e_mesas();
					while ($es3=mysqli_fetch_object($estadi)){
						$Nit=$es3->id;
						$descripcionemp=$es3->estadod;
                                             
				?>
                    
                     <option value="<?php echo $Nit; ?>"><?php echo $descripcionemp; ?> </option>
                     
                                        <?php } ?>
                     </select>
                  </div><!--/col-sm-9-->
                  <label></label>   
                </div><!--/form-group-->
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label"></label>
          <div class="col-sm-9">
              <input value="Actualizar" name="Actualizar" required="true" type="submit" maxlength="2" max="20" min="1" />
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
                
          </form>
                   
                   <br>
                   <br>
                   
                   <?php }
                   
                   ?>
                          
                           <!-- Page Heading -->
                    
                    <!-- DataTales Example -->
                                  <div class="card shadow mb-4" style="width: 100%;">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Mesas</h6>
                        </div>
                        <div class="card-body">
                            
                            <div class="table-responsive">
                                <table class="table table-bordered"  id="dataTable" width="100%" cellspacing="0">
                                  <thead>
                              <tr>
                                
                                  <th>#</th>
                                  <th>Mesa</th>
                                  <th>Estado</th>
                                  <th>Aforo</th>
                                  <th>Descripcion</th>
                                  <th>Opcion</th>
                                  
                                 
                                  
                                 
                              </tr>
           
                              <?php 
				
                                
                                
                                if ($tip_user==3){
				
				?>
                              </thead>
                              
                              <tbody>
                                  <?php 
                                  $num =1;
                                  
                                  $productos=$usuariosCon->all_mesas();
					while ($pro=mysqli_fetch_object($productos)){
                                            
                                            $num2=$num++;
						$nums=$pro->Cod;
						$fecha=$pro->estado;
						$comen=$pro->aforo;
						$refe=$pro->descripcion;
						
                                               
                                                
				?>
                              <tr class="">
                                  
                             
                                  <input type="hidden" name="mesa" value="<?php echo $mesan; ?>">
                                  <td><?php echo $num2; ?></td>
                                  <td><?php echo $nums;?></td>
                                  <td><?php echo $fecha;?></td>
                                  <td><?php echo $comen;?></td>
                                  <td><?php echo $refe;?></td>
                                  <td> <form method="post" action="">
                                    <input value="<?php echo $nums;?>" type="hidden" name="pedido" >
                                    <input value="Editar" type="submit" name="Editar" >
                                          
                                      </form> </td>
                                  
                                  
                                      
                               </form>
                                  
                              </tr>
                              <?php
					}
                                        
                                }
				?>
                          
                        
                                </table>
                            </div>
                        </div>
                   
                    </div>

                </div>
                    
 
            </div><!--/porlets-content--> 
                   
                   
                   
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

   

    <?php include './footer.php'; ?>

</body>

</html>

 <?php } ?>