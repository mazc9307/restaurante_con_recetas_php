 <?php   session_start(); 
 $user = $_SESSION["k_username"]; 
 $tip_user = $_SESSION["tipo_user"];
 $EmpresAct = $_SESSION["EmpresAct"];
 $Cod_Empresa = $_SESSION["Cod_Empresa"];
 if($user== null){
          echo 'Ingreso no valido';
     ?>
     
     <script language="javascript" type="text/javascript">                        
		window.location="logout.php";
		</script>
     <?php
 }else{
 
 ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>USuarios</title>
<?php include './header.php'; ?>
<link href="plugins/data-tables/DT_bootstrap.css" rel="stylesheet"/>
<link href="plugins/advanced-datatable/css/demo_table.css" rel="stylesheet"/>
<link href="plugins/advanced-datatable/css/demo_page.css" rel="stylesheet"/>
 <link href="tablab/jquery.dataTables.min.css" rel="stylesheet">


        


</head>
<body class="light_theme fixed_header blue_thm atm-spmenu-push  left_nav_fixed">
  
<div class="wrapper">
  <!--\\\\\\\ wrapper Start \\\\\\-->
  <div class="header_bar">
<?php include './menu_notifi.php'; ?> 
  </div>
  <!--\\\\\\\ header end \\\\\\-->
 <?php   include './menu_user.php'; ?>
  
  
  <div  class="contentpanel">
      
      <?php   include './content_panel.php'; ?>
      <div  class="container clear_both padding_fix">
        <!--\\\\\\\ container  start \\\\\\-->
          
    
        <div id="central" >
         			
                          <div class="row align-content-sm-center ">
        
       <div id="main-content">
    <div class="page-content">
            
            
            
                   <div class="row">
        <div class="col-md-12">
          <div class="block-web">
            <div class="header">
              <div class="actions"> <a class="minimize" href="#"><i class="fa fa-chevron-down"></i></a> <a class="refresh" href="#"><i class="fa fa-repeat"></i></a> <a class="close-down" href="#"><i class="fa fa-times"></i></a> </div>
              <h3 class="content-header">Usuarios</h3>
            </div>
         <div class="porlets-content table-responsive">
          <div class="adv-table editable-table ">
                          <div class="clearfix">
                              <div class="btn-group">
                                  <a  class="btn btn-primary" href="crea-user.php">
                                        Agregar Nuevo<i class="fa fa-plus"></i>
                                  </a>
                              </div>
                              <div style="display: none;" class="btn-group pull-right">
                                  <button class="btn dropdown-toggle" data-toggle="dropdown">Tools <i class="fa fa-angle-down"></i>
                                  </button>
                                  <ul class="dropdown-menu pull-right">
                                      <li><a href="#">Print</a></li>
                                      <li><a href="#">Save as PDF</a></li>
                                      <li><a href="#">Export to Excel</a></li>
                                  </ul>
                              </div>
                          </div>
                          <div class="table-responsive"></div>
                          <table class="table table-striped table-hover table-bordered " id="editable-sample">
                              <thead>
                              <tr>
                                
                                  <th>#</th>
                                  <th>Documento</th>
                                  <th>Usuario</th>
                                  <th>Nombre</th>
                                  <th>Correo</th>
                                  <th>Telefono</th>
                                  <th>Tipo Usuario</th>
                                  <th>Empresa</th>
                                  <th>Estado</th>
                                  <th>Editar</th>
                                 
                              </tr>
                              <?php 
				include ('class/usuarios.php');
				$usuariosCon = new Usuarios();
                                
                                
                                if ($tip_user==3){
				$listado=$usuariosCon->all_usuarios2();
				?>
                              </thead>
                              
                              <tbody>
                                  <?php 
                                  $num =1;
					while ($row=mysqli_fetch_object($listado)){
                                            
                                            $num2=$num++;
						$Numdoc=$row->Numdoc;
                                                $usuario=$row->usuario;
						$Nombres=$row->Nombres." ".$row->Apellidos;
						$email=$row->email;
						$telefono=$row->telefono;
						$tipo_user=$row->tipo_user;
						$t_user=$row->descripcion_user;
						$rzu=$row->Razon_soc;
						$uestado=$row->Descripcion_e;
                                                
				?>
                              <tr class="">
                                 
                                  <td><?php echo $num2;?></td>
                                  <td><?php echo $Numdoc;?></td>
                                  <td><?php echo $usuario;?></td>
                                  <td><?php echo $Nombres;?></td>
                                  <td class="center"><?php echo $email;?></td>
                                  <td class="center"><?php echo $telefono;?></td>
                                  <td class="center"><?php echo $t_user;?></td>
                                  <td class="center"><?php echo $rzu;?></td>
                                  <td class="center"><?php echo $uestado;?></td>
                                  <td><a class="Editar" href="user_u.php?coduser=<?php echo $Numdoc ;?>">Editar</a></td>
                                  
                              </tr>
                              <?php
					}
                                        
                                }elseif($tip_user==1){
                                    
                                    $listado=$usuariosCon->all_usuempresa($Cod_Empresa);
				?>
                              </thead>
                              
                              <tbody>
                                  <?php 
                                  $num =1;
					while ($row=mysqli_fetch_object($listado)){
                                            
                                            $num2=$num++;
						$Numdoc=$row->Numdoc;
                                                $usuario=$row->usuario;
						$Nombres=$row->Nombres." ".$row->Apellidos;
						$email=$row->email;
						$telefono=$row->telefono;
						$tipo_user=$row->tipo_user;
						$t_user=$row->descripcion_user;
						$rzu=$row->Razon_soc;
						$uestado=$row->Descripcion_e;
                                                
				?>
                              <tr class="">
                                 
                                  <td><?php echo $num2;?></td>
                                  <td><?php echo $Numdoc;?></td>
                                  <td><?php echo $usuario;?></td>
                                  <td><?php echo $Nombres;?></td>
                                  <td class="center"><?php echo $email;?></td>
                                  <td class="center"><?php echo $telefono;?></td>
                                  <td class="center"><?php echo $t_user;?></td>
                                  <td class="center"><?php echo $rzu;?></td>
                                  <td class="center"><?php echo $uestado;?></td>
                                  <td><a class="Editar" href="user_u.php?coduser=<?php echo $Numdoc ;?>">Editar</a></td>
                                  
                              </tr>
                              <?php
					}
                                       
                                    
                                }
				?>
                          
                         
                              </tbody>
                          </table>
                      </div>
 
            </div><!--/porlets-content-->  
          </div><!--/block-web--> 
        </div><!--/col-md-12--> 
      </div><!--/row-->
      </div><!--/row-->
      </div><!--/row-->
      </div>
      </div>
      <!--\\\\\\\ container  end \\\\\\-->
    </div>
    <!--\\\\\\\ content panel end \\\\\\-->
  </div>
  <!--\\\\\\\ inner end\\\\\\-->
</div>
<!--\\\\\\\ wrapper end\\\\\\-->

   <?php include './modal.php'; ?>
   <?php include './chat.php'; ?>


<div class="demo"><span id="demo-setting"><i class="fa fa-cog txt-color-blueDark"></i></span> <form><legend class="no-padding margin-bottom-10" style="color:#6e778c;">Layout Options</legend><section><label><input type="checkbox" class="checkbox style-0" id="smart-fixed-header" name="subscription"><span>Fixed Header</span></label><label><input type="checkbox" class="checkbox style-0" id="smart-fixed-navigation" name="terms"><span>Fixed Navigation</span></label><label><input type="checkbox" class="checkbox style-0" id="smart-rigth-navigation" name="terms"><span>Right Navigation</span></label><label><input type="checkbox" class="checkbox style-0" id="smart-boxed-layout" name="terms"><span>Boxed Layout</span></label><span id="smart-bgimages" style="display: none;"></span></section><section><h6 class="margin-top-10 semi-bold margin-bottom-5">Clear Localstorage</h6><a id="reset-smart-widget" class="btn btn-xs btn-block btn-primary" href="javascript:void(0);"><i class="fa fa-refresh"></i> Factory Reset</a></section> <h6 class="margin-top-10 semi-bold margin-bottom-5">Ultimo Skins</h6><section id="smart-styles"><a style="background-color:#23262F;" class="btn btn-block btn-xs txt-color-white margin-right-5" id="dark_theme" href="javascript:void(0);"><i id="skin-checked" class="fa fa-check fa-fw"></i> Dark Theme</a><a style="background:#E35154;" class="btn btn-block btn-xs txt-color-white" id="red_thm" href="javascript:void(0);">Red Theme</a><a style="background:#34B077;" class="btn btn-xs btn-block txt-color-darken margin-top-5" id="green_thm" href="javascript:void(0);">Green Theme</a><a style="background:#56A5DB" class="btn btn-xs btn-block txt-color-white margin-top-5" data-skinlogo="img/logo-pale.png" id="blue_thm" href="javascript:void(0);">Blue Theme</a><a style="background:#9C6BAD" class="btn btn-xs btn-block txt-color-white margin-top-5" id="magento_thm" href="javascript:void(0);">Magento Theme</a><a style="background:#FFFFFF" class="btn btn-xs btn-block txt-color-black margin-top-5" id="light_theme" href="javascript:void(0);">Light Theme</a></section></form> </div>


   <?php include './footer.php'; ?>
<script src="js/jquery.slimscroll.min.js"></script>
<script src="plugins/data-tables/jquery.dataTables.js"></script>
<script src="plugins/data-tables/DT_bootstrap.js"></script>
<script src="plugins/data-tables/dynamic_table_init.js"></script>
<script src="plugins/edit-table/edit-table.js"></script>
<script>
          jQuery(document).ready(function() {
              EditableTable.init();
          });
 </script>
</body>
</html>
 <?php } ?>
