 <?php   session_start(); 
 @$user = $_SESSION["k_username"]; 
 @$tip_user = $_SESSION["tipo_user"];
 @$EmpresAct = $_SESSION["EmpresAct"];
 @$Cod_Empresa = $_SESSION["Cod_Empresa"];
 @$Numdoc = $_SESSION["Numdoc"];
 
 @$pedido_o=$_POST['pedido'];
 
 if($pedido_o==null){
     
     $pedido_o=$_GET['pedido'];
 }
 
 if($pedido_o==null){
 
     ?>
     
     <script language="javascript" type="text/javascript">                        
		window.history.back();
		</script>
     <?php
 }
 
 if($user== null){
          
     ?>
     
     <script language="javascript" type="text/javascript">                        
		window.location="logout.php";
		</script>
     <?php
 }else{
 
 ?>
<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Pedido Estado</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
     <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
   <?php   include 'class/menu.php' ?>
<?php   include './menu_user.php'; 
        include ('class/usuarios.php');
	$usuariosCon = new Usuarios();
        
        $numpropina=$usuariosCon->countpropina($pedido_o); 
        $rowpr=mysqli_fetch_object($numpropina);
        $numpr=$rowpr->num;
        
             
       if($numpr==0){
                                
        @$propina2 =$_POST["propina"];
        
        if ($propina2>0) {
            $pedidoLinea2=$usuariosCon->creapedidolineas3($pedido_o,$propina2);
            
                                }}
                
                ?>
        
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <?php   include './menu_notifi.php'; ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                   <!-- Content Row -->
                   
                   <a class="btn btn-light alert-link" style="height: 40px;" href="all_pedidos.php" >Pedidos</a> 
                          <a class="btn btn-light" href="excel/pedidos.php?pedido=<?php echo $pedido_o;?>" target="_blank">Exportar a excel</a> 
						  <b><a class="btn btn-light" href="open_pedido2.php?pedido=<?php echo $pedido_o;?>" target="_blank">Imprimir</a>                          
                           <!-- Page Heading -->
                    
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">
                                Pedido No.:
                                <?php 
                                $numeropedido=$usuariosCon->all_pedidos_num($pedido_o); 
                                $rowp=mysqli_fetch_object($numeropedido);
                                $numpedido=$rowp->Cod_pedido;
                                $totalpedido=$rowp->linea_total;
                                echo $numpedido;
                                ?>
                                
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" width="100%" cellspacing="0">
                                  <thead>
                              <tr>
                                
                                  <th># Pedido</th>
                                  <th>Mesa</th>
                                  <th>Usuario</th>
                                  <th>Estado</th>
                                  <th>Fecha</th>
                                
                                  
                                 
                                 
                              </tr>
                              <?php 

				$listado=$usuariosCon->all_pedidos_open($pedido_o);
				?>
                              </thead>
                              
                              <tbody>
                                  <?php 
                                  $num =1;
					while ($row=mysqli_fetch_object($listado)){
                                            
                                            
						$Cod_pedido=$row->Cod_pedido;
                                                $mesa=$row->mesa;
						$usuario=$row->usuario;
						$Descripcion_ep=$row->Descripcion_ep;
						$Fecha=$row->Fecha;
                                                $n_cliente=$row->n_cliente;
                                                $Doc_cliente=$row->Doc_cliente;
                                                $Tel_cliente=$row->Tel_cliente;
                                                $dir_cliente=$row->dir_cliente;
                                                $cor_cliente=$row->correo_cliente;
                                                $pagos=$row->efectivo;
                                                $tranferencia=$row->transferencia;
                                                $tarjeta=$row->tarjeta;
                                                $daviplata=$row->daviplata;
                                                $nequi=$row->nequi;
						
						
			
                                                
				?>
                              <tr class="">
                                 
                                  
                                  <td><?php echo $Cod_pedido;?></td>
                                  <td><?php echo $mesa;?></td>
                                  <td><?php echo $usuario;?></td>
                                  <td><?php echo $Descripcion_ep;?></td>
                                  <td><?php echo $Fecha;?></td>
                                  
                                  
                              </tr>
                              
                              <tr>
                                  <td colspan="2"> <b>Metodo de pago:</b></td>
                                  <td colspan="3"> <b><?php 
                                  echo 'efectivo: '.$pagos.'<br>Tranferencia: '.$tranferencia.'<br>Tarjeta: '.$tarjeta.'<br>Daviplata: '.$daviplata.'<br>Nequi: '.$nequi;
                                  
                                  ?></b></td>
                              </tr>
                              <tr>
                              </tr>
                              
                              <tr>
                                  <td colspan="5"> <b>Datos Cliente</b></td>
                              </tr>
                              <tr>
                                  <td><b>Nombre</b></td>
                                  <td><b>Documento</b></td>
                                  <td><b>Telefono</b></td>
                                  <td><b>Correo</b></td>
                                  <td><b>Direccion</b></td>
                              </tr>
                              <tr class="">
                                 
                                  
                                  
                                  <td><?php echo $n_cliente;?></td>
                                  <td><?php echo $Doc_cliente;?></td>
                                  <td><?php echo $Tel_cliente;?></td>
                                  <td><?php echo $cor_cliente;?></td>
                                  <td><?php echo $dir_cliente;?></td>
                                  
                                  
                                  
                              </tr>
                              
                                 <?php
                                  
                                  }
                                        
                                
				?>
                          
                        
                                </table>
                            </div>
                            <div class="table-responsive">
                                <table  class="table table-bordered" width="100%" cellspacing="0">
                                    <thead>
                                    <th>Cod Producto</th>
                                    <th>Des. Producto</th>
                                    <th>Cantidad</th>
                                    <th>Vr. Und</th>
                                    <th>Linea total</th>
                                        
                                    </thead>
                                 <?php 
                                  $numpedido = $pedido_o;
                                  
                                  
                                  $listadopro=$usuariosCon->mesa_pedido_suma_linea2($numpedido); 
                                  while ($rowlp=mysqli_fetch_object($listadopro)){
                                            
                                            
						$cod_producto=$rowlp->cod_producto;
						$Descripcion_p=$rowlp->Descripcion_p;
						$cant=$rowlp->cant;
						$price=$rowlp->precio;
						$lt=$rowlp->lt;
                                  
                                  ?>
                                  
                                  <tr>
                                  <td><?php echo $cod_producto; ?></td>
                                  <td><?php echo $Descripcion_p; ?></td>
                                  <td><?php echo $cant; ?></td>
                                  <td>$ <?php echo $price; ?></td>
                                  <td>$ <?php echo $lt; ?></td>
                                  
                              </tr>
                              
                              <?php
                              $propina = $totalpedido *0.10;
                              
                                  }
                                        $numpropina2=$usuariosCon->countpropina($pedido_o); 
        $rowpr2=mysqli_fetch_object($numpropina2);
        $numpr2=$rowpr2->num;
                                  
                                  
                                ?>
                              <tr>
                                  <td>
                                       <?php if($numpr2>0){
                                           
                                       }else{
                                       if ($Descripcion_ep=='Cerrado') {
                                                        ?>
                                      <form action="" method="post" >
                                          
                                          <input type="hidden" value="<?php echo $Cod_pedido  ?>"  name="pedido"/>
                                          <input type="hidden" value="<?php echo $propina;  ?>"  name="propina"/>
                                          <input class="btn btn-info" type="submit" value="Incluir propina" />
                                          10 % del total
                                      </form>  
                                       <?php }}?>
                                  </td>
                                  <td colspan="2">
                                       <?php if($numpr2>0){
                                           
                                       }else{
                                       if ($Descripcion_ep=='Cerrado') {
                                                        ?>
                                      <form action="" method="post" >
                                          Propina: 
                                          <input type="hidden" value="<?php echo $Cod_pedido  ?>"  name="pedido"/>
                                          <input type="text" value="<?php echo $propina;  ?>"  name="propina"/>
                                          <input class="btn btn-info" type="submit" value="Incluir propina" />
                                        
                                      </form>  
                                       <?php }}?>
                                  </td>
                                  
                                  <td>
                                      <b>Total</b>
                                  </td>
                                  <td><b>$ <?php echo $totalpedido; ?></b>
                                  </td>
                              </tr>
                              </table>
                            </div>
                             <div>
                    <?php 
                    if($Descripcion_ep=='Ordenado' or $Descripcion_ep=='Cancelado' or $Descripcion_ep=='Cobrado' ){}else{
                    ?>
                        
                        <input type="submit" value="Cobrar" class="btn btn-success" data-target="#logoutModal2" data-toggle="modal" >
                        
                        <?php 
                    }
                        ?>
                    </div>
                      
                   
                            
               
        <div class="modal fade" id="logoutModal2"  role="dialog" aria-labelledby="exampleModalLabel1"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Cobrar pedido?</h5>
                    
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div> 
                      <form action="crear_cliente2.php" method="get">
                      <table>
                          <tr>
                              <td><input name="agregar" class="btn btn-info" type="submit" value="+ Agregar Cliente"/></td>
                              <td><input name="nump" type="hidden" value="<?php echo $numpedido ?>"/></td>
                          </tr>
                      </table>
                      </form>
                   <br>
                   <br>
                    Valor faltante: <input style="color: red;" disabled="true" value="<?php echo $totalpedido; ?>" type="text" name="total" id="total"/>
       
                   <?php 
                   
                    echo 'Vr Total: '.$totalpedido.'<br>';
                   ?>
                   <br>
                   <form action="close_pedido.php" method="post">  
                   <table class="">
                    <tr>
                    <td>
                    Cliente: 
                    </td>
                    
                    <td>
                   <select id="mibuscador" name="documento" >
                   <option value="">Seleccione un producto</option>
                      <?php 
                       
                                $listapro=$usuariosCon->all_clientes();
				while ($row2=mysqli_fetch_object($listapro)){
				$Cod_producto=$row2->cod_cliente;
				$Descripcion_p=$row2->nombre;
				$stock3_p=$row2->Stock;
                                             
				?>
                    
                     <option value="<?php echo $Cod_producto; ?>"><?php echo $Cod_producto.'/'.$Descripcion_p; ?> </option>
                     
                                        <?php } ?>
                     </select>
                    </td> 
                    
                    </tr>
                    <tr>
                        
                        <td> Efectivo: </td> <td> <input id="txt_campo_1" class="monto" name="efectivo" value="0"  onchange="sumar();" type="number"  >    </td>
                    </tr>
                    <tr>
                    <td>Trasferencia bancaria:  </td><td><input id="txt_campo_1" class="monto" name="tranferencia" value="0" onchange="sumar();" type="number">  </td>  
                    </tr>
                    <tr>
                    <td>Tarjeta: </td><td> <input id="txt_campo_1" class="monto" name="Tarjeta" value="0" onchange="sumar();" type="number"> </td>
                    </tr>
                    <tr>
                    <td>Daviplata: </td><td> <input id="txt_campo_1" class="monto" name="daviplata" value="0" onchange="sumar();" type="number">  </td> 
                    </tr>
                    <tr>
                    <td>Nequi: </td><td> <input id="txt_campo_1" class="monto" name="nequi" value="0" onchange="sumar();" type="number">   </td>
                    </tr>
                   </table>
                   
                   <br>
                   
                    <?php
                    
                        echo 'No. Pedido: '.$Cod_pedido.'<br>';
                        echo '<input type="hidden" value="'.$Cod_pedido.'" name="pedido"/>';
                        echo '<input type="hidden" value="'.$totalpedido.'" name="Total"/>';
                  
                   
                    echo 'Vr Total: '.$totalpedido.'<br>';
                
                    
                    ?>
                               </div>
                   <br>
                   <br>
                   <br>
                   <b>Esta operacion no se puede reversar.</b>
                </div>
                <div class="modal-footer">
                    <input class="btn btn-success" type="submit"  value="Cobrar">
                    </form>
                </div>
            </div>
        </div>
        </div>
        
                            
                        </div>
                        
                    
                    </div>
                    
                    

                </div>
                    
                
                    
                    
                
                
                
            </div><!--/porlets-content--> 
                   
                   
                   
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

   

    <?php include './footer.php'; ?>
<link rel="stylesheet" type="text/css" href="css/select2.css">
	<script src="jquery-3.1.1.min.js"></script>
	<script src="js/select2.js"></script>
</body>

</html>

 <?php } ?>
<script language="javascript" type="text/javascript">                        
		function sumar()
{
  const $total = document.getElementById('total');
  let subtotal = <?php echo $totalpedido; ?>;
  [ ...document.getElementsByClassName( "monto" ) ].forEach( function ( element ) {
    if(element.value !== '') {
      subtotal -= parseFloat(element.value);
    }
  });
  $total.value = subtotal;
}
		</script>
<script type="text/javascript">
	$('#logoutModal').ready(function(){
		$('#mibuscador').select2();
	});
</script>
