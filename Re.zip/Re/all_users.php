 <?php   session_start(); 
 @$user = $_SESSION["k_username"]; 
 @$tip_user = $_SESSION["tipo_user"];
 @$EmpresAct = $_SESSION["EmpresAct"];
 @$Cod_Empresa = $_SESSION["Cod_Empresa"];
 @$Numdoc = $_SESSION["Numdoc"];
 
 if($user== null){
          
     ?>
     
     <script language="javascript" type="text/javascript">                        
		window.location="logout.php";
		</script>
     <?php
 }else{
 
 ?>
<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Usuarios</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
     <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
      <link href="tablab/jquery.dataTables.min.css" rel="stylesheet">
       <link href="tablab/jquery.dataTables.min.css" rel="stylesheet">


</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
   <?php   include 'class/menu.php' ?>
<?php   include './menu_user.php'; ?>
        
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <?php   include './menu_notifi.php'; ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                   <!-- Content Row -->
                   
                      
                          
                           <!-- Page Heading -->
                    
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Usuarios</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                  <thead>
                              <tr>
                                
                                  <th>#</th>
                                  <th>Documento</th>
                                  <th>Usuario</th>
                                  <th>Nombre</th>
                                  <th>Correo</th>
                                  <th>Telefono</th>
                                  <th>Tipo Usuario</th>
                                  <th>Estado</th>
                                  <th>Editar</th>
                                 
                              </tr>
                              <?php 
				include ('class/usuarios.php');
				$usuariosCon = new Usuarios();
                                
                                
                                if ($tip_user==3){
				$listado=$usuariosCon->all_usuarios2();
				?>
                              </thead>
                              
                              <tbody>
                                  <?php 
                                  $num =1;
					while ($row=mysqli_fetch_object($listado)){
                                            
                                            $num2=$num++;
						$Numdoc=$row->Numdoc;
                                                $usuario=$row->usuario;
						$Nombres=$row->Nombres." ".$row->Apellidos;
						$email=$row->email;
						$telefono=$row->telefono;
						$tipo_user=$row->tipo_user;
						$t_user=$row->descripcion_user;
						$estasuser=$row->estado;
			
                                                
				?>
                              <tr class="">
                                 
                                  <td><?php echo $num2;?></td>
                                  <td><?php echo $Numdoc;?></td>
                                  <td><?php echo $usuario;?></td>
                                  <td><?php echo $Nombres;?></td>
                                  <td><?php echo $email;?></td>
                                  <td><?php echo $telefono;?></td>
                                  <td><?php echo $t_user;?></td>
                                  <td class="center"><?php 
                                    if ($estasuser==1) {
                                        echo 'activo';
                                    }else{
                                        echo 'Inactivo';
                                        
                                    }
                                  
                                  ?></td>
                                  
                                  <td> <form method="post" action="user_u.php">
                                    <input value="<?php echo $Numdoc ;?>" type="hidden" name="coduser" >
                                    <input value="1" type="hidden" name="val" >
                                    <input value="Editar" type="submit" name="editar" >
                                          
                                      </form> </td>
                              </tr>
                              <?php
					}
                                        
                                }
				?>
                          
                        
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                    
 
            </div><!--/porlets-content--> 
                   
                   
                   
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

   

    <?php include './footer.php'; ?>

</body>

</html>

 <?php } ?>