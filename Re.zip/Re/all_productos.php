 <?php   session_start(); 
 @$user = $_SESSION["k_username"]; 
 @$tip_user = $_SESSION["tipo_user"];
 @$EmpresAct = $_SESSION["EmpresAct"];
 @$Cod_Empresa = $_SESSION["Cod_Empresa"];
 @$Numdoc = $_SESSION["Numdoc"];
 
 if($user== null){
          
     ?>
     
     <script language="javascript" type="text/javascript">                        
		window.location="logout.php";
		</script>
     <?php
 }else{
 
 ?>
<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Productos</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="tablab/jquery.dataTables.min.css" rel="stylesheet"> 
    <link href="tablab/searchPanes.dataTables.min.css" rel="stylesheet">
    <link href="tablab/select.dataTables.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap-theme.min.css">
    
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <link href="tablab/jquery-3.5.1.js" rel="stylesheet">
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/searchpanes/1.3.0/js/dataTables.searchPanes.min.js"></script>
    <script src="https://cdn.datatables.net/select/1.3.3/js/dataTables.select.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>


</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
   <?php   include 'class/menu.php' ?>
<?php   include './menu_user.php'; ?>
        
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <?php   include './menu_notifi.php'; 
               
               
               include ('class/usuarios.php');
				$usuariosCon = new Usuarios();
               ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                   <!-- Content Row -->
                   
                      
                          
                           <!-- Page Heading -->
                    
                    <!-- DataTales Example -->
                    
<div class="card shadow mb-4" style="width: 100%;">

<div class="card-header py-3">
<h6 class="m-0 font-weight-bold text-primary">Productos</h6>
</div>

<a class="btn btn-light" href="excel/stock.php" target="_blank">Exportar a excel</a>
<div class="card-body">

<div class="table-responsive">
<table class="display nowrap"  id="example2" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                
                                  <th>#</th>
                                  <th>Cod. Pro.</th>
                                  <th>Descripcion</th>
                                  <th>Stock</th>
                                  <th>Vr un</th>
                                  <th>Total vr Stock</th>
                                  <th>Categoria</th>
                                  <th>Opcion</th>
                                  
                                 
                                  
                                 
                              </tr>
           
                              <?php 
				
                                
                                
                                if ($tip_user==3){
				
				?>
                              </thead>
                              
                              <tbody>
                                  <?php 
                                  $num =1;
                                  
                                  $productos=$usuariosCon->all_product1();
					while ($pro=mysqli_fetch_object($productos)){
                                            
                                            $num2=$num++;
						$des=$pro->Descripcion_p;
						$enlace=$pro->Enlace;
						$vru=$pro->Valor_unitario;
						$iva=$pro->Iva;
						$cat=$pro->categoria;
						$cod_p=$pro->Cod_producto;
						$stock_p=$pro->Stock;
						$Rece=$pro->Receta;
                                               
                                                 $countingredie=$usuariosCon->buscar_ingredientes($cod_p);
                                $sc1=mysqli_fetch_object($countingredie);
                                $sihayingredientes=$sc1->num; 
				?>
                              <tr class="<?php if ($Rece=='Y' && $sihayingredientes==0 ) { echo 'alert-danger';}?>">
                                  
                             
                                  <input type="hidden" name="mesa" value="<?php echo $mesan; ?>">
                                  <td><?php echo $num2; ?></td>
                                  <td> 
                                      <?php echo $cod_p;?>
                                  <!--<img src="<?php //echo $cod_p;?>" width="50" height="50">-->
                                  </td>
                                  <td><?php echo $des;?></td>
                                  <td><?php echo $stock_p;?></td>
                                  <td>$ <?php echo $vru;?></td>
                                  <td>$ <?php $total_v= $vru*$stock_p;  echo $total_v?></td>
                                  <td><?php echo $cat;?></td>
                                  <td> <form method="post" action="product_u.php">
                                    <input value="<?php echo $cod_p;?>" type="hidden" name="idpro" >
                                    <input value="Editar" type="submit" name="editar" >
                                          
                                      </form> </td>
                                  
                                  
                                      
                               </form>
                                  
                              </tr>
                              <?php
					}
                                        
                                }
				?>
                          
                        
                                </table>
                            </div>
                        </div>
                   
                    </div>

                </div>
                    
 
            </div><!--/porlets-content--> 
                   
                   
                   
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->


</body>

</html>

 <?php } ?>

<script type="text/javascript">
	$(document).ready( function () {
  var table = $('#example2').DataTable({
      "deferRender": true,
        stateSave: true,
        searchPanes: {
          
            cascadePanes: true,
            columns: [2,4],
            layout: 'columns-1',
            dtOpts: {
                dom: "tp",
                paging: true,
                pagingType: 'numbers',
                searching: true,
                pageLength: 6
            }
        },
               
        pageLength: 10,
       dom: 'Bfrtip',
    buttons: [
        {
            text: "<i class='fas fa-hamburger btn-lg btn-outline-primary'></i>",
            action: function(e, dt, node, config){
                dt.search("HAMBURGUESA").draw();
               
                
            }               
                
            }
            ,
        {
           text: "<i class='fas fa-glass-whiskey btn-lg btn-outline-secondary'></i>",
            action: function(e, dt, node, config){
                dt.search("Shots").draw();
               
               
            }               
                
            }
            ,
        {
           text: "<i class='fa fa-beer btn-lg btn-outline-success'></i>",
            action: function(e, dt, node, config){
                dt.search("Cerveza").draw();
               
                
            }               
                
            },
            {
           text: "<i class='fa fa-beer btn-lg btn-outline-warning'> Vaso</i>",
            action: function(e, dt, node, config){
                dt.search("Vaso").draw();
               
                
            }               
                
            },{
           text: "<i class='fa fa-beer btn-lg btn-outline-info'> Jarra</i>",
            action: function(e, dt, node, config){
                dt.search("Jarra").draw();
               
                
            }               
                
            },
            {
                
           text: "<i class='fa fa-beer btn-lg btn-outline-Dark'> 2*1</i>",
            action: function(e, dt, node, config){
                dt.search("2*1").draw();
               
                
            }               
                
            }, {
           
            text: "<i class='fa fa-cookie-bite btn-lg btn-outline-success'></i>",
            titleAttr: 'Cocina',
            action: function(e, dt, node, config){
                dt.search("cocina").draw();
                    
            }               
                
            },
                    {
            text: "<i class='fa fa-eraser btn-lg btn-outline-danger'></i>",
            action: function(e, dt, node, config){
                dt.search("").draw();
               
                
            }               
                
            }
        
    ]
    });
  table.searchPanes()
  $("div.dtsp-verticalPanes").append(table.searchPanes.container());
  
    $('a.toggle-vis').on( 'click', function (e) {
        e.preventDefault();
 
        // Get the column API object
        var column = table.column( $(this).attr('data-column') );
 
        // Toggle the visibility
        column.visible( ! column.visible() );
    } );
} );
</script>
<script>
    $(document).ready(function() {
    var table = $('#example2').DataTable();
 
    $('#example tbody').on( 'click', 'tr', function () {
        if ( $(this).hasClass('selected') ) {
            $(this).removeClass('selected');
        }
        else {
            table.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
        }
    } );
 
    $('#button').click( function () {
        table.row('.selected').remove().draw( false );
    } );
} );
</script>