<?php 


header("Pragma: public");
header("Expires: 0");
$filename = "Pedidos.xls";
header("Content-type: application/x-msdownload");
header("Content-Disposition: attachment; filename=$filename");
header("Pragma: no-cache");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
@$fechaa=$_GET["fechaa"];
@$fechab=$_GET["fechab"];
echo $fechab;
include ('../class/usuarios.php');
$usuariosCon = new Usuarios();

?>
<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                  <thead>
                              <tr>
                                
                                  <th>#</th>
                                  <th>Documento</th>
                                  <th>Nombre</th>
                                  <th>Correo</th>
                                  <th>Telefono</th>
                                  <th>Direccion</th>
                                  <th>Tipo</th>
                                 
                              </tr>
                              <?php 
				$listado=$usuariosCon->all_clientes();
				?>
                              </thead>
                              
                              <tbody>
                                  <?php 
                                  $num =1;
					while ($row=mysqli_fetch_object($listado)){
                                            
                                            $num2=$num++;
						$Numdoc=$row->cod_cliente;
						$Nombres=$row->nombre;
						$email=$row->Correo;
						$telefono=$row->telefono;
                                                $t_user=$row->direccion;
                                                $tipo=$row->tipo;
			
                                                
				?>
                              <tr class="">
                                 
                                  <td><?php echo $num2;?></td>
                                  <td><?php echo $Numdoc;?></td>
                                  <td><?php echo $Nombres;?></td>
                                  <td><?php echo $email;?></td>
                                  <td><?php echo $telefono;?></td>
                                  <td><?php echo $t_user;?></td>
                                  
                                  
                                  <td><?php echo $tipo;?> </td>
                              </tr>
                              <?php
					}
                                        
                                
				?>
                          
                        
                                </table>