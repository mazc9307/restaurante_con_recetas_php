<?php 


header("Pragma: public");
header("Expires: 0");
$filename = "Stock.xls";
header("Content-type: application/x-msdownload");
header("Content-Disposition: attachment; filename=$filename");
header("Pragma: no-cache");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");

include ('../class/usuarios.php');
$usuariosCon = new Usuarios();

?>
<table>
<thead>
<tr>

<th>#</th>
<th>Cod. Pro.</th>
<th>Descripcion</th>
<th>Stock</th>
<th>Vr un</th>
<th>Total vr Stock</th>
<th>Categoria</th>
<th>Medida</th>




</tr>

</thead>

<tbody>
<?php 
$num =1;

$productos=$usuariosCon->all_product1();
    while ($pro=mysqli_fetch_object($productos)){

        $num2=$num++;
            $des=$pro->Descripcion_p;
            $vru=$pro->Valor_unitario;
            $iva=$pro->Iva;
            $cat=$pro->categoria;
            $cod_p=$pro->Cod_producto;
            $stock_p=$pro->Stock;
            $medidapro=$pro->Descripcion_m;


?>
<tr class="">
<td><?php echo $num2; ?></td>
<td><?php echo $cod_p;?></td>
<td><?php echo $des;?></td>
<td><?php echo $stock_p;?></td>
<td>$ <?php echo $vru;?></td>
<td>$ <?php $total_v= $vru*$stock_p;  echo $total_v?></td>
<td><?php echo $cat;?></td>
<td><?php echo $medidapro;?></td>


</tr>
<?php
    }


?>
                          
                        
 </table>