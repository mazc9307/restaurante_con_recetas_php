<?php 


header("Pragma: public");
header("Expires: 0");
$filename = "Pedidos.xls";
header("Content-type: application/x-msdownload");
header("Content-Disposition: attachment; filename=$filename");
header("Pragma: no-cache");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
@$fechaa=$_GET["fechaa"];
@$fechab=$_GET["fechab"];
echo $fechab;
include ('../class/usuarios.php');
$usuariosCon = new Usuarios();

?>
<table>
<thead>
<tr>

<th>#</th>
<th>Codigo_Pedido</th>
<th>Mesa</th>
<th>Fecha</th>
<th>Estado</th>
<th>Nombre_cliente</th>
<th>Doc_cliente</th>
<th>Tel_cliente</th>
<th>Mail_cliente</th>
<th>Dir_cliente</th>
<th>Cod_producto</th>
<th>Nom_producto</th>
<th>Cantidad</th>
<th>Medida</th>
<th>Precio_uni</th>
<th>Total_linea</th>
<th>Total_pedido</th>
<th>4 TIPO</th>
<th>5 vendedor</th>
<th>6 TIPO</th>
<th>7 LISTA DE PRECIOS</th>




</tr>

</thead>

<tbody>
<?php 
$num =1;
@$pedido=$_GET["pedido"];


if (@$pedido>0) {
    
    $productos=$usuariosCon->all_pedidos_excel2($pedido);
    
}else{
    
if(@$fechab!=null){
    
    $productos=$usuariosCon->all_pedidos_excel3($fechaa,$fechab);
}else{
    
    $productos=$usuariosCon->all_pedidos_excel();
}

}

    

    while ($pro=mysqli_fetch_object($productos)){

        $num2=$num++;
        $Codigo_Pedido=$pro->Cod_pedido;
        $Mesa=$pro->mesa;
        $Fecha=$pro->Fecha;
        $Estado=$pro->Descripcion_ep;
        $Nombre_cliente=$pro->n_cliente;
        $Doc_cliente=$pro->Doc_cliente;
        $Tel_cliente=$pro->Tel_cliente;
        $Mail_cliente=$pro->correo_cliente;
        $Dir_cliente=$pro->dir_cliente;
        $Cod_producto=$pro->cod_producto;
        $Nom_producto=$pro->Descripcion_p;
        $Cantidad=$pro->cantidad;
        $Medida=$pro->Descripcion_m;
        $Precio_uni=$pro->precio;
        $Total_linea=$pro->Linea_total;
        $Total_pedido=$pro->total_pedido;
            
           


?>
<tr class="">
<td><?php echo $num2; ?></td>
<td><?php echo $Codigo_Pedido; ?></td>
<td><?php echo $Mesa; ?></td>
<td><?php echo $Fecha; ?></td>
<td><?php echo $Estado; ?></td>
<td><?php echo $Nombre_cliente; ?></td>
<td><?php echo $Doc_cliente; ?></td>
<td><?php echo $Tel_cliente; ?></td>
<td><?php echo $Mail_cliente; ?></td>
<td><?php echo $Dir_cliente; ?></td>
<td><?php echo $Cod_producto; ?></td>
<td><?php echo $Nom_producto; ?></td>
<td><?php echo $Cantidad; ?></td>
<td><?php echo $Medida; ?></td>
<td><?php echo $Precio_uni; ?></td>
<td><?php echo $Total_linea; ?></td>
<td><?php echo $Total_pedido; ?></td>
<td>2</td>
<td>901413688</td>
<td>PED</td>
<td>1</td>



</tr>
<?php
    }


?>
                          
                        
 </table>