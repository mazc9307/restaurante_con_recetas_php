 <?php   session_start(); 
 @$user = $_SESSION["k_username"]; 
 @$tip_user = $_SESSION["tipo_user"];
 @$EmpresAct = $_SESSION["EmpresAct"];
 @$Cod_Empresa = $_SESSION["Cod_Empresa"];
 @$Numdoc = $_SESSION["Numdoc"];
 
 if($user== null){
          
     ?>
     
     <script language="javascript" type="text/javascript">                        
		window.location="logout.php";
		</script>
     <?php
 }else{
 
 ?>
<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Salida</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
     <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
   <?php   include 'class/menu.php' ?>
<?php   include './menu_user.php';
include './class/usuarios.php';
                                $usuariosCon = new Usuarios();

?>
        
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <?php   include './menu_notifi.php'; ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                   <!-- Content Row -->
                   <form action="" method="post">
                       ¿Cuantos productos desea sacar? <input type="number" placeholder="No." name="num" min="1" />  
                       <input type="submit" value="enviar" class="btn btn-info">
                   </form>
                   <br>
                   <br>
                   <form action="crear_salida_1.php" method="post">
                       
                       <table class="table">
                          
                        <?php
                   
                        @$num = $_POST['num'];
                        
                        
                        if (@$num>0){
               for ($i = 1; $i <= @$num; $i++) {
               ?>
                      <tr>
                          <td><?php echo $i; ?></td>
                      <td>
                          <select class="mibuscador" name="cod_p[]" >
                   <option value="">Seleccione un producto</option>
                      <?php 
                       
                                $listapro=$usuariosCon->producto_s();
				while ($row2=mysqli_fetch_object($listapro)){
				$Cod_producto=$row2->Cod_producto;
				$Descripcion_p=$row2->Descripcion_p;
				$stock3_p=$row2->Stock;
                                             
				?>
                    
                     <option value="<?php echo $Cod_producto; ?>"><?php echo $Descripcion_p; ?> </option>
                     
                                        <?php } ?>
                     </select>
        
                          
                       </td>
                       <td>
                           Catidad a Sacar:
                           <input value="1" type="number" min="1"   name="unidades[]" placeholder="Unidades"/> 
                       </td>
                       <td>
                           <input value="1" type="text" name="almacen[]" placeholder="Almacen"/> 
                       </td>

                       <tr>
                       
                        <?php }
                        ?>
                       </table>
                        <div class="form-group">
                        <label for="exampleFormControlTextarea1">Comentarios:</label>
                        <textarea name="comen" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                        </div>
                       
                       <input value="Sacar" type="submit" class="btn btn-success">
                       <?php }else{
                            
                            
                        } ?>
                       </form>
                   
                   
                           <!-- Page Heading -->
                    
                   

                </div>
                    
 
            </div><!--/porlets-content--> 
                   
                   
                   
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

   

    <?php include './footer.php'; ?>
 <link rel="stylesheet" type="text/css" href="css/select2.css">
	<script src="jquery-3.1.1.min.js"></script>
	<script src="js/select2.js"></script>
</body>

</html>

 <?php } ?>

<script type="text/javascript">
	$(document).ready(function(){
			$('.mibuscador').select2();
	});
</script>