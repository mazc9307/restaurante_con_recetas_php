<?php
		include 'class/usuarios.php';
                   
                        //    $usuariosCon= new Usuarios();
                           $usuariosCon= new Usuarios();
				
				if(isset($_POST) && !empty($_POST)){
                                    
                                    
                                    @$pedido_i = $usuariosCon->sanitize($_POST['pedido_i']); //codigo del pedido
                                    @$producto = $usuariosCon->sanitize($_POST['producto']);  //codigo del producto
                                    @$cantitem = $usuariosCon->sanitize($_POST['cantitem']); // catidad del producto a agregar al pedido
                                    @$precio  = $usuariosCon->sanitize($_POST['precio']); // precio del producto unitario
                                    @$m = $usuariosCon->sanitize($_POST['m']); // numero de la mesa
                                    @$estadomesa = $usuariosCon->sanitize($_POST['estadomesa']); //estado de la mesa
                                   
                                        if($cantitem == null){
                                        $alerta =0;
                                        }else{
                                        $alerta =1;
                                $sstock=$usuariosCon->Stock_b_3($producto);
                                $stockl=mysqli_fetch_object($sstock);
                                $stock_actual=$stockl->s1; //catidad de stock
                                $pro_receta=$stockl->Receta; // si tiene receta 
                                $pro_principal=$stockl->Principal; // o si es producto principal
               $sin_stock='0'; //contador                   
           if ($pro_receta=='Y' && $stock_actual=='0' ) {
           //echo 'consultar productos de la receta<br>';
           $productos=$usuariosCon->recetaitems2($producto);
            while ($pro=mysqli_fetch_object($productos)){
          
            $receta_cod_producto=$pro->subp; // codigo del producto de la recta listado
            $receta_descripcion_p=$pro->des; // descripcion del producto de la recta listado
            $receta_cantidad_requerida=$pro->cantsub; // cantidad requerida del producto de la receta listado
            $receta_stock_actual=$pro->Stock; //  stock actual del producto
            
           //echo $receta_cod_producto.' '.$receta_descripcion_p.' '.$receta_cantidad_requerida.' '.$receta_stock_actual.'<br>';
                
            $cantidad_final_stock =  $receta_stock_actual - ($receta_cantidad_requerida * $cantitem);
            
            //echo $cantidad_final_stock.'<br>';
           
            //echo '<br> sin stock cuenta'.$sin_stock.'<br>';
            if ($cantidad_final_stock<0){
              $sin_stock++; // aumenta contador poque no hay stock
              
                @$message ='no hay stock de alguno de los ingredientes ('.$receta_descripcion_p.') minimos para la receta';
                 @$class="alert alert-danger";
                 break;
            }
            }
         
            // si aumenta el contador es '0' proseguimos a insertar las filas en el pedido
           if($sin_stock=='0'){
              $preciot = ($cantitem * $precio);
            // insertamos el producto principal contine catidad y precio que es el que se visualiza en el pedido
               $pedidoLinea=$usuariosCon->creapedidolinea_new($pedido_i,$producto,$cantitem,$precio,$preciot);
               
                
           $message = 'Se agrego correctamente';
            $class="alert alert-success";
               // consultamos el id del ultimo producto  insertado                
               $idproducto=$usuariosCon->Productoid($producto,$pedido_i);
                                $productoidc=mysqli_fetch_object($idproducto);
                                $producto_idf=$productoidc->id; //id de la linea
                                
                                //echo '<br>id p:'.$producto_idf.'<br>';
                                
            // volvemos a consultar los productos
            $productos=$usuariosCon->recetaitems2($producto);
            while ($pro=mysqli_fetch_object($productos)){
          
            $receta_cod_producto2=$pro->subp; // codigo del producto de la recta listado
            $receta_descripcion_p=$pro->des; // descripcion del producto de la recta listado
            $receta_cantidad_requerida2=$pro->cantsub; // cantidad requerida del producto de la receta listado
            $receta_stock_actual=$pro->Stock; //  stock actual del producto
            
            $cantidad_final_linea = $receta_cantidad_requerida2 * $cantitem;
           
          //insertamos los productos de la receta  
           // echo $pedido_i.'/'.$receta_cod_producto2.'/'.$receta_cantidad_requerida2.'/'.$producto.'/'.$producto_idf.'<br>';                   
          $pedidoLinea2=$usuariosCon->creapedidolineas2_new($pedido_i,$receta_cod_producto2,$cantidad_final_linea,$producto,$producto_idf); 
                               
           }
           
            }// fin si el producto es receta y tiene stock     
                        
            }elseif ($pro_receta=='Y' && $stock_actual>'0' ) {
            $message = 'Este producto no es fisico y no deberia tener inventario';
            $class="alert alert-danger";
            }
                     
            if($pro_principal=='Y' && $pro_receta=='Y'){
                $message = 'Este producto no puede ser principal y al mismo tiempo tener receta verificar el producto 1';
            $class="alert alert-danger";
                
            }else{ 
          $stock_requeridos =  $stock_actual - $cantitem;
           if($pro_principal=='Y' && $stock_actual>0) {
           // insertar linea
           $preciot = ($cantitem * $precio);
           $pedidoLinea=$usuariosCon->creapedidolinea_new($pedido_i,$producto,$cantitem,$precio,$preciot);
            // actualizamos el stock del producto
           $s333 = $stock_actual - $cantitem;
           $retornarstock33=$usuariosCon->Stock_u_add($producto, $s333);
           
           $message = 'Se agrego correctamente';
            $class="alert alert-success";
           
           
            }elseif($pro_principal=='Y' && $stock_actual<0){
            $message = 'no hay stock suficiente('.$stock_actual.')';
            $class="alert alert-danger";
                
            }
                                        
            }                  
                             
       }
       ////////// final insertar producto ----- end --------
       
       
       /////inicio eliminar productos del pedido
       
       //elminar lineas del pedido
                 
                        @$idp2=$_POST['idlinea'];
                        @$canlinea=$_POST['cantlinea'];
                        if ($idp2>0) {
                            @$productof=$_POST['productl'];
                            
                             $cuenta_si_existe=$usuariosCon->cuenta_id_si_existe($idp2);
                                $cexiste=mysqli_fetch_object($cuenta_si_existe);
                                $c_s_existe=$cexiste->sx; //cuenta si existe el id para no borrar ni modificar el inventario
                                
                                if ($c_s_existe==0) {
                                    $alerta=1;
                                     $message='Ya se habia eliminado este producto';
                                     $class='alert alert-danger';
                                     
                                }else{
                                
                                $eliminarlpedido=$usuariosCon->eliminarpeidolinea($idp2);
                                $sstock=$usuariosCon->Stock_b($productof);
                                $stockl=mysqli_fetch_object($sstock);
                                $s1=$stockl->s1;
                                $s3=@$canlinea+$s1;
                                $retornarstock=$usuariosCon->Stock_u2($productof, $s3);
                                
                                
                           $sstockprf=$usuariosCon->Stock_bf($productof);
                           $stockl23=mysqli_fetch_object($sstockprf);
                           $profcero=$stockl23->Receta;
                           $sstockprf2=$usuariosCon->Stock_bf2($productof,$idp2);
                           $stockl234=mysqli_fetch_object($sstockprf2);
                           @$pedido22=$stockl234->cod_pedido;
                           
                           //consultamos los productos de la recta a eliminar
                           $qlisub=$usuariosCon->lineasup($productof,$pedido22,$idp2);
                           while ($pem=mysqli_fetch_object($qlisub)){
                            $idsupl=$pem->id; // id de la linea
                            $cansupl=$pem->cantidad; // cantidad de la linea
                            $codsupl=$pem->cod_producto; // codigo del producto
                            // consultamos el stock de cada item                            
                            $sstock33=$usuariosCon->Stock_b3($codsupl);
                            $stockl33=mysqli_fetch_object($sstock33);
                            $s133=$stockl33->s1; // stock del producto
                            /// fin de la consulata
                            $s333=@$cansupl+$s133; //sumamos el stock actual con la cantidad de la linea y queda almacenado en la nueva variable
                            //actualizacmos el stock
                            $retornarstock33=$usuariosCon->Stock_u2($codsupl, $s333);
                            //actualizamos el estado del las lineas adesactivado
                            $retornarstock33=$usuariosCon->Stock_u3($codsupl,$productof,$idp2);
                            
                           }
                           // eliminamos las filas del pedido que se encuentren en esatdo desactivado ya que son basura
                           $eliminarlpedido2=$usuariosCon->eliminarpeidolinea2();
//                            si el producto es receta actualizamos stock a 0
                           if ($profcero=='Y') {
                             $updatestock2=$usuariosCon->Stock_upreceta($productof);
                           }
                           
                           $alerta=1;
                                     $message='Operacion exitosa, produto borrado del pedido';
                                     $class='alert alert-success';
                        }
                        }
                        //end eliminar producto ------ end ----------
       
                @$pedm = $_POST['pedm'];
                @$pedmesa2 = $_POST['pedm2'];
                @$mesacam = $_POST['mesacam'];
                @$mesero = $_POST['mesero'];
                @$pedido_i2 = $_POST['pedido_i2'];
                 if (@$pedido_i2>0){
                $pedidousuario=$usuariosCon->pedidomesero($pedido_i2,$mesero);
                $alerta=1;
                                     $message='Operacion exitosa';
                                     $class='alert alert-success';
                 }
                 
                 // cambiar estado mesa
                if (@$pedm>1){
                    $camm=$usuariosCon->cambiarmesa(@$pedm,@$mesacam);
                    $camm2=$usuariosCon->cambiarmesapedidoestado(@$pedmesa2);
                    $camm3=$usuariosCon->cambiarmesapedidoestado2(@$mesacam);
                    $alerta=1;
                                     $message='Operacion exitosa 3';
                                     $class='alert alert-success';
                }
                                 @$mesan = $_POST['m'];
                                 @$estadomesa = $_POST['estadomesa'];
                                 @$cancelpedido = $_POST['pedidoc'];
                                 @$cerrarpedido = $_POST['pedidoc2'];
                                 @$liberado= $_POST['liberar'];
                                 
                                 // liberar mesa
                                 if(@$liberado=='60'){
                                     $updatepedido=$usuariosCon->cambio_mesa_borrarinfclie(@$mesan,@$estadomesa);
                                     $alerta=1;
                                     $message='Operacion exitosa, pedido liberado, recuerde que los productos aun continuan en el pedido.';
                                     $class='alert alert-success';
                                     }
                                 //end liberar mesa
                                 
                 //cancelar pedido
                 if (@$cancelpedido > 0) {
                $cacelp=$usuariosCon->cancelarpedido(@$cancelpedido);
                $cacelp=$usuariosCon->cancelarpedidoL(@$cancelpedido);
                $updatepedido=$usuariosCon->cambio_mesa(@$mesan,@$estadomesa);
                $Stockcan=$usuariosCon->Stock_cancelado($cancelpedido);
                while ($sc=mysqli_fetch_object($Stockcan)){
                $productof=$sc->cod_producto;
                $cantf=$sc->cantidad;    
                $sstock=$usuariosCon->Stock_b($productof);
                $stockl=mysqli_fetch_object($sstock);
                $s1=$stockl->s1;
                $s2= $s1+$cantf;
                $updatestock=$usuariosCon->Stock_u($productof,$s2);    
                }
     ?>         <script language="javascript" type="text/javascript">  
                alert("Pedido Cancelado");
		window.location="index.php";
		</script>
                 <?php
                 }
                 // end cancelar pedido                 
                 // cerrar pedido
                 if (@$cerrarpedido > 0) {
                $cacelp=$usuariosCon->cerrarpedido(@$cerrarpedido);
                $updatepedido=$usuariosCon->cambio_mesa(@$mesan,@$estadomesa); ?>
                 <script language="javascript" type="text/javascript">  
                alert("Pedido Cerrado, para cobrar.");
		window.location="open_pedido.php?pedido=<?php echo $cerrarpedido; ?>";
		</script>
                 <?php
                 }
                 if(@$mesan==null){
                                     
                ?>
                <script language="javascript" type="text/javascript">                        
		window.location="index.php";
		</script>
              <?php
                }   
                 $updatepedido=$usuariosCon->cambio_mesa(@$mesan,@$estadomesa);
                 
                 } 
                
                 if(@$alerta==0 or @$alerta==null){
                 }else{ ?>

				<div class="<?php echo @$class?>">
                                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                    </button>
				  <?php echo @$message;?>
				  <?php echo @$campo;
                                ?>
				</div>	
                        <?php  } ?>

<script type="text/javascript">
    $(".alert").delay(5000).slideUp(200, function () {
        $(this).alert('close');
    });
</script>