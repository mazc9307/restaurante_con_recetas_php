 <?php   session_start(); 
 @$user = $_SESSION["k_username"]; 
 @$tip_user = $_SESSION["tipo_user"];
 @$EmpresAct = $_SESSION["EmpresAct"];
 @$Cod_Empresa = $_SESSION["Cod_Empresa"];
 @$Numdoc = $_SESSION["Numdoc"];
 
 $pedido_o=$_POST['pedido'];
 
 if($pedido_o==null){
 
     ?>
     
     <script language="javascript" type="text/javascript">                        
		window.history.back();
		</script>
     <?php
 }
 
 if($user== null){
          
     ?>
     
     <script language="javascript" type="text/javascript">                        
		window.location="logout.php";
		</script>
     <?php
 }else{
 
 ?>
<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Entrada</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
     <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">


</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
   <?php   include 'class/menu.php' ?>
<?php   include './menu_user.php'; 
        include ('class/usuarios.php');
	$usuariosCon = new Usuarios();?>
        
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <?php   include './menu_notifi.php'; ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                   <!-- Content Row -->
                   
                      
                          
                           <!-- Page Heading -->
                    
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">
                                Entrada No.:
                                <?php 
                                $numeropedido=$usuariosCon->all_entradas_num($pedido_o); 
                                $rowp=mysqli_fetch_object($numeropedido);
                                
                                $numpedido=$rowp->id;
                                $fecha=$rowp->fecha;
                                $totalpedido=$rowp->comentarios;
                                $refe=$rowp->referencia;
                                echo $numpedido;
                                ?>
                                
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" width="100%" cellspacing="0">
                                  <thead>
                              <tr>
                                
                                  <th># Entrada</th>
                                  <th>Fecha</th>
                                  <th>Referencia</th>
                                
                                  
                                 
                                 
                              </tr>
                            </thead>
                              
                              <tbody>
                                
                              <tr class="">
                                 
                                  
                                  <td><?php echo $numpedido;?></td>
                                  <td><?php echo $fecha;?></td>
                                  <td><?php echo $refe;?></td>
                                  
                                  
                              </tr>
                              
                          
                        
                                </table>
                            </div>
                            <div class="table-responsive">
                                <table  class="table table-bordered" width="100%" cellspacing="0">
                                    <thead>
                                    <th>Cod Producto</th>
                                    <th>Des. Producto</th>
                                    <th>Cantidad</th>
                                    <th>Almacen</th>
                                   </thead>
                                 <?php 
                                  $numpedido = $pedido_o;
                                  
                                  
                                  $listadopro=$usuariosCon->entrada_linea_op($numpedido); 
                                  while ($rowlp=mysqli_fetch_object($listadopro)){
                                            
                                          
						$cod_producto=$rowlp->cod_producto;
						$Descripcion_p=$rowlp->Descripcion_p;
						$cant=$rowlp->unidades;
						$alma=$rowlp->almacen;
						
                                  
                                  ?>
                                  
                                  <tr>
                                  <td><?php echo $cod_producto; ?></td>
                                  <td><?php echo $Descripcion_p; ?></td>
                                  <td><?php echo $cant; ?></td>
                                  <td># <?php echo $alma; ?></td>
                                  
                              </tr>
                              
                              <?php
                                  }
                                ?>
                              <tr>
                                  <td colspan="2">
                                      
                                  </td>
                                  <td>
                                      <b>Comentarios: </b>
                                  </td>
                                  <td><b> <?php echo $totalpedido; ?></b>
                                  </td>
                              </tr>
                              </table>
                            </div>
                            
                        </div>
                        
                    
                    </div>
                    
                    

                </div>
                    
                
                    
                    
                
                
                
            </div><!--/porlets-content--> 
                   
                   
                   
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

   

    <?php include './footer.php'; ?>

</body>

</html>

 <?php } ?>