 <?php   session_start(); 
 @$user = $_SESSION["k_username"]; 
 @$tip_user = $_SESSION["tipo_user"];
 @$EmpresAct = $_SESSION["EmpresAct"];
 @$Cod_Empresa = $_SESSION["Cod_Empresa"];
 @$Numdoc = $_SESSION["Numdoc"];
 
 if($user== null){
          
     ?>
     
     <script language="javascript" type="text/javascript">                        
		window.location="logout.php";
		</script>
     <?php
 }else{
 
 ?>
<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Pedidos</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
     <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
      <link href="tablab/jquery.dataTables.min.css" rel="stylesheet">


</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
   <?php   include 'class/menu.php' ?>
<?php   include './menu_user.php'; ?>
        
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <?php   include './menu_notifi.php'; ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                   <!-- Content Row -->
                   
                      
                          
                           <!-- Page Heading -->
                    
                    <!-- DataTales Example --> 
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Pedidos</h6>
                        </div>
                       <a class="btn btn-light" href="excel/pedidos.php" target="_blank">Exportar todos a excel</a>
                       <form  method="get" action="excel/pedidos.php" target="_blank">
                           <input type="date" name="fechaa" value="">
                           <input type="date" name="fechab" value="">
                           <input type="submit" name="enviar" class="btn btn-light"  value="Exportar por fechas">
                               
                       </form>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                  <thead>
                              <tr>
                                
                                  <th>#</th>
                                  <th>No. Pedido</th>
                                  <th>Mesa</th>
                                  <th>Usuario</th>
                                  <th>Estado</th>
                                  <th>Fecha</th>
                                  <th>Total</th>
                                  <th>Ver</th>
                                  
                                 
                                 
                              </tr>
                              <?php 
				include ('class/usuarios.php');
				$usuariosCon = new Usuarios();
                                
                                
                                if ($tip_user==3 or $tip_user==2 or $tip_user==1){
				$listado=$usuariosCon->all_pedidos();
				?>
                              </thead>
                              
                              <tbody>
                                  <?php 
                                  $num =1;
					while ($row=mysqli_fetch_object($listado)){
                                            
                                            
						$Cod_pedido=$row->Cod_pedido;
                                                $mesa=$row->mesa;
						$usuario=$row->usuario;
						$Descripcion_ep=$row->Descripcion_ep;
						$Fecha=$row->Fecha;
						
						
			
                                                
				?>
                              <tr class="">
                                 
                                  
                                  <td><?php echo $num++;?></td>
                                  <td><?php echo $Cod_pedido;?></td>
                                  <td><?php echo $mesa;?></td>
                                  <td><?php echo $usuario;?></td>
                                  <td><?php echo $Descripcion_ep;?></td>
                                  <td><?php echo $Fecha;?></td>
                                  <td><?php 
                                  $pedido_o =$Cod_pedido;
                                  $numeropedido=$usuariosCon->all_pedidos_num($pedido_o); 
                                $rowp=mysqli_fetch_object($numeropedido);
                                $numpedido=$rowp->Cod_pedido;
                                $totalpedido=$rowp->linea_total; 
                                  
                                  echo $totalpedido;
                                  
                                  ?></td>
                                  <td>
                                      <form action="open_pedido.php" method="post">
                                          <input type="hidden" name="pedido" value="<?php  echo$Cod_pedido; ?>" >
                                          <button class=" btn-circle btn-sm fa fa-envelope-open"></button>
                                      </form>
                                  </td>
                                  
                              </tr>
                              <?php
					}
                                        
                                }
				?>
                          
                        
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                    
 
            </div><!--/porlets-content--> 
                   
                   
                   
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

   

    <?php include './footer.php'; ?>

</body>

</html>

 <?php } ?>