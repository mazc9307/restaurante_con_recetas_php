<!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion  toggled" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
                <div class=" ">
                    <i class=""><?php echo $EmpresAct; ?></i>
                </div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-home"></i>
                    <span>INICO</span></a>
            </li>
 <?php 
          $menu = new Menu();
          
          $online=$menu->up_online($user);
                   
           $num=1;
          $men_us=$menu->menu_user2($user);
          while ($row=mysqli_fetch_object($men_us)){
          $cod_menu=$row->Cod_menu;
          $Nom_menu=$row->Nombre_menu;
          $icono=$row->icono;
            $num++;                      
          
          ?>
            <!-- Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities<?php echo $num; ?>"
                   aria-expanded="true" aria-controls="collapseUtilities<?php echo $num; ?>">
                    <i class="fas fa-fw <?php echo $icono; ?>"></i>
                    <span><?php echo $Nom_menu; ?></span>
                </a>
            <!-- fin Menu -->    
            <!-- sumenu -->
            
             
                <div id="collapseUtilities<?php echo $num; ?>" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                       <?php 
               $sub=$menu->submenus2($user,$cod_menu);
               while ($row=mysqli_fetch_object($sub)){
                                                $Nom_sub=$row->Nombre_submenu;
						$link=$row->Link;
						$ldc=$row->idcarga;
               
               ?> 
                        
                        <a class="collapse-item" href="<?php echo $link; ?>"><?php echo $Nom_sub; ?></a>
                                          
                    
                    <?php }?>
                    
                    </div>
                </div>
             <!-- fin sumenu -->
            </li>
            
            <?php }?>

            <!-- Divider -->
            <hr class="sidebar-divider">
             <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

            <!-- Sidebar Message -->
            </ul>

