 <?php   session_start(); 
 @$user = $_SESSION["k_username"]; 
 @$tip_user = $_SESSION["tipo_user"];
 @$EmpresAct = $_SESSION["EmpresAct"];
 @$Cod_Empresa = $_SESSION["Cod_Empresa"];
 @$Numdoc = $_SESSION["Numdoc"];
 
 if($user== null){
          
     ?>
     
     <script language="javascript" type="text/javascript">                        
		window.location="logout.php";
		</script>
     <?php
 }else{
 
 ?>
<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Productos</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
        <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
<script>
		
			$(document).ready(function(){
                               
				  var consulta;
			 									 
				  //hacemos focus al campo de búsqueda
				  $("#busqueda").focus();
																   
				  //comprobamos si se pulsa una tecla
				  $("#busqueda").change(function(e){
						
						//obtenemos el texto introducido en el campo de búsqueda
						consulta = $("#busqueda").val();
												  
						 //hace la búsqueda
													   
							 $.ajax({
								   type: "POST",
								   url: "b_subcategorias.php",
								   data: "b="+consulta,
								   dataType: "html",
								   beforeSend: function(){
											  //imagen de carga
										   $("#resultado").html("<p align='center'><img src='imagenes/ajax-loader.gif' /></p>");
								   },
								   error: function(){
										   alert("error petición ajax");
									 },
								  success: function(data){                                                    
										$("#resultado").empty();
										$("#resultado").append(data);
										//$("#busqueda").val(consulta);
										
									}
							});
													   
												  
				  });
											
			});
			
		</script>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
   <?php   include 'class/menu.php' ?>
<?php   include './menu_user.php'; ?>
        
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <?php  
               
               include './menu_notifi.php'; ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    
             
                   <!-- Content Row -->
                    <div class="row ">
                        
                         <?php 
            include 'class/usuarios.php';
            
          
                 $usuariosCon = new Usuarios();
                 
                 
                      
                  
         @$cat = $_POST["cate"];         
         @$cod_producto = $_POST["cod_p"];         
         @$des = $_POST["desc"];         
         @$vru = $_POST["vrund"];         
         @$alma = $_POST["almacen"];         
         @$medx = $_POST["medida"];
         @$Despacho = $_POST["Despacho"];
         @$receta2 = $_POST["receta"];
         @$subcate=$_POST["subcate"];
         
         if(@$receta2=='Y'){@$receta2='Y';}else{@$receta2='N';}
         @$principal2 = $_POST["principal"];
         if(@$principal2=='Y'){@$principal2='Y';}else{@$principal2='N';}
         if(@$receta2=='Y' && @$receta2==Y){
             @$receta2=N;
             @$principal2=Y;
         }
         @$ingrediente2 = $_POST["ingrediente"];
         if(@$ingrediente2=='Y'){@$ingrediente='Y';}else{@$ingrediente2='N';}

         if ($cod_producto==null) {
             
         }else{
             

//@$archivo = ($_FILES['archivo']);
//
//if ($archivo) {
//   $extension = pathinfo($archivo['name'], PATHINFO_EXTENSION);
//   $extension = strtolower($extension);
//   $extension_correcta = ($extension == 'jpg' or $extension == 'jpeg' or $extension == 'gif' or $extension == 'png');
//   if ($extension_correcta) {
//      $ruta_destino_archivo = "productos/{$archivo['name']}";
//      $archivo_ok = move_uploaded_file($archivo['tmp_name'], $ruta_destino_archivo);
//   }
//}
//?>
                   
                   
   <!--   <?php// if (isset($archivo)): ?>
       <?php //if (!$extension_correcta): ?>
         <span style="color: #f00;"> La extensión es incorrecta, el archivo debe ser jpg, jpeg, gif o png. </span> 
       //<?php// elseif (!$archivo_ok): ?>
         <span style="color: #f00;"> Error al intentar subir el archivo o no se inserto ninguna imagen</span>
      //<?php// else: ?>
         
   --> 
   
     <?php// endif ?>
   <?php// endif; ?> 
 <?php 
$anom = "No disponible";
 //echo $cod_producto,$des,$vru,$cat,$alma,$medx,$anom,$Despacho,$receta2,$principal2,$subcate,$ingrediente2;

$listadoemp2=$usuariosCon->Crea_pro($cod_producto,$des,$vru,$cat,$alma,$medx,$anom,$Despacho,$receta2,$principal2,$subcate,$ingrediente2);
if ($res=true) {
    ?>
         <div style="height: 50px;"  class="alert alert-success">
             <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
             Creado con exito <form action="product_u.php" method="post">
                 <input type="hidden" name="idpro" value="<?php echo $cod_producto; ?>"/>
                 <input type="submit" value="ver"/></form>
				</div>	
   <br>
   <br>
    
    <?php
}else{
    
    echo 'error';
}

 } ?>
                        
                        
         <a class="btn btn-light alert-link" style="height: 40px;" href="all_productos.php" >Productos</a>
                        <form method="post" id="formulario" class="jumbotron col-sm-7 mx-auto" enctype="multipart/form-data">
            
  
               
            
            <div class="input-group mb-3">
                    <label  class="col-sm-3 control-label">Categoria</label>
                  <div class="col-sm-9">
                      
                      <select required name="cate" class="form-control mibuscador2" id="busqueda">
                        <option  value="">Seleccione una opcion </option>
                      <?php             
                      $Medida=0;
                      $listadoemp=$usuariosCon->Tipo_categoria($Medida);
					while ($row=mysqli_fetch_object($listadoemp)){
						$Nit=$row->id;
						$descripcionemp=$row->categoria;
                                             
				?>
                    
                     <option value="<?php echo $Nit; ?>"><?php echo $descripcionemp; ?> </option>
                     
                                        <?php } ?>
                     </select>
                  </div><!--/col-sm-9-->
                  <label></label>   
                </div><!--/form-group-->
                <div id="resultado"></div>
                
                <div class="input-group mb-3">
                    <label  class="col-sm-3 control-label">Despacho</label>
                  <div class="col-sm-9">
                      
                      <select required name="Despacho" class="form-control" >
                         <option  value="">Seleccione una opcion </option>
                          <option value="<?php echo 'Cocina'; ?>"><?php echo 'Cocina';?> </option>
                        <option value="<?php echo 'Barra'; ?>"><?php  echo 'Barra'; ?> </option>
                         </select>
                  </div><!--/col-sm-9-->
                  <label></label>   
                </div><!--/form-group-->
      

                <div id="resultado"></div>
		<div class="form-group">
                  <label>Codigo Producto</label>
                  <input type="text" name="cod_p" maxlength="10" required placeholder="Ingrese Codigo del producto" class="form-control">
                </div><!--/form-group-->
                <div class="form-group">
                  <label>Nombre Producto</label>
                  <input type="text" name="desc" parsley-trigger="change" required placeholder="Nombre Producto" class="form-control">
                </div><!--/form-group-->
                <div class="form-group">
                  <label>Precio unitario</label>
                  <input type="text" name="vrund" parsley-trigger="change" required placeholder="Precio Unitario" maxlength="11" class="form-control">
                </div><!--/form-group-->
              
 <div class="input-group mb-3">
                    <label  class="col-sm-3 control-label">Almacen</label>
                  <div class="col-sm-9">
                      
                      <select required name="almacen" class="form-control" id="">
                        <option  value="">Seleccione una opcion </option>
                      <?php             $listadoemp=$usuariosCon->Tipo_almacen();
					while ($row2=mysqli_fetch_object($listadoemp)){
						$almacen=$row2->id;
						$descripcionemp=$row2->descripcion;
                                             
				?>
                    
                     <option value="<?php echo $almacen; ?>"> <?php echo $descripcionemp; ?> </option>
                     
                                        <?php } ?>
                     </select>
                  </div><!--/col-sm-9-->
                  <label></label>   
                </div><!--/form-group-->                
                 <div class="input-group mb-3">
                    <label  class="col-sm-3 control-label">Medida</label>
                  <div class="col-sm-9">
                      
                      <select required name="medida" class="form-control">
                        <option  value="">Seleccione una opcion </option>
                      <?php             
                      $Medida=0;
                      $listadoemp2=$usuariosCon->Tipo_medida($Medida);
					while ($row2=mysqli_fetch_object($listadoemp2)){
						$Nit=$row2->id;
						$descripcionemp=$row2->Descripcion_m;
                                             
				?>
                    
                     <option value="<?php echo $Nit; ?>"><?php echo $descripcionemp; ?> </option>
                     
                                        <?php } ?>
                     </select>
                  </div><!--/col-sm-9-->
                  <label></label>   
                  <label><input type="checkbox" name="receta" value="Y"> Con receta </label>&nbsp;&nbsp; 
                  <label><input type="checkbox" name="principal" value="Y"> Con principal </label>&nbsp;&nbsp; 
                  <label><input type="checkbox" name="ingrediente" value="Y"> ingrediente </label>
                </div><!--/form-group-->
                <br><li>Los productos con receta dependen de el stock de sus ingredientes.</li>
                <br><li>Los productos principales depende de su propio stock.</li>
                <br><li>Un producto no puede se pricipal y requerir receta al mismo tiempo.</li>
                <br><li>Si es un prodcuto principal, pero al mismo tiempo un ingrediente, 
                marque la casilla ingrediente para que no aparezca en el listado principal del pedido.</li>
                <br>
<!--                <div class="form-group">
                  <label>Foto</label>
                  <input type="file" name="archivo" parsley-trigger="change" required placeholder="Foto" class="form-control">
                </div>/form-group-->
                <div class="checkbox">
                </div><!--/checkbox-->
                <input id="btn-ingresar" class="btn btn-primary" type="submit" value="Crear"/>
                <div id="resp"></div>
        
                
	</form>      
            </div>       
     
            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

   

    <?php include './footer.php'; ?>

</body>

</html>

 <?php } ?>


<script type="text/javascript">
	$(document).ready(function(){
			$('.mibuscador2').select2();
	});
</script>