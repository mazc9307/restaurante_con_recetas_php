 <?php   session_start(); 
 @$user = $_SESSION["k_username"]; 
 @$tip_user = $_SESSION["tipo_user"];
 @$EmpresAct = $_SESSION["EmpresAct"];
 @$Cod_Empresa = $_SESSION["Cod_Empresa"];
 @$Numdoc = $_SESSION["Numdoc"];
 if($user== null){?>
 <script language="javascript" type="text/javascript">window.location="logout.php";</script>
     <?php }else{ ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Pedido</title>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="tablab/jquery.dataTables.min.css" rel="stylesheet"> 
    <link href="tablab/searchPanes.dataTables.min.css" rel="stylesheet">
    <link href="tablab/select.dataTables.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap-theme.min.css">
    
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <link href="tablab/jquery-3.5.1.js" rel="stylesheet">
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/searchpanes/1.3.0/js/dataTables.searchPanes.min.js"></script>
    <script src="https://cdn.datatables.net/select/1.3.3/js/dataTables.select.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
    
    <style>
    div.dtsp-verticalContainer{
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: flex-start;
    align-content: flex-start;
    align-items: flex-start;
}
 
div.dtsp-verticalContainer div.dtsp-verticalPanes,
div.dtsp-verticalContainer div.container{
    width: 30%;
    flex-grow: 0;
    flex-shrink: 0;
    flex-basis: 0;
}
 
div.dtsp-verticalContainer div.dtsp-verticalPanes{
    flex-grow: 1;
    flex-shrink: 0;
    flex-basis: 26%;
}
 
div.dtsp-verticalPanes {
    margin-right: 20px;
}
 
div.dtsp-title {
    margin-right: 0px !important;
    margin-top: 13px !important;
}
 
input.dtsp-search {
    min-width: 0px !important;
    padding-left: 0px !important;
    margin: 0px !important;
}
 
div.dtsp-verticalContainer div.dtsp-verticalPanes div.dtsp-searchPanes{
    flex-direction: column;
    flex-basis: 0px;
}
 
div.dtsp-verticalContainer div.dtsp-verticalPanes div.dtsp-searchPanes div.dtsp-searchPane{
    flex-basis: 0px;
}
 
div.dtsp-verticalContainer div.container{
    flex-grow: 1;
    flex-shrink: 0;
    flex-basis: 60%;
}
 
div.dtsp-panesContainer {
    border: 1px solid #ccc;
    border-radius: 6px;
    padding: 5px;
}
    </style>
</head>
<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
<?php   include 'class/menu.php' ?>
<?php   include './menu_user.php'; ?>        
        <!-- End of Sidebar -->
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content">
               <?php   include './menu_notifi.php'; 
               
               //include ('class/usuarios.php');
               
               
               include './pedido_procesa.php'; 
               
                $usuariosCon = new Usuarios();               
               ?>
                
                <?php                      
                        
                      @$idpro = $_POST['documento'];
                      @$pclientee = $_POST['pedcl']; 
                      if(@$idpro>0){  
                      $lpro=$usuariosCon->Cliente_b($idpro);
                      $lp=mysqli_fetch_object($lpro);
                       @$cod_cliente=$lp->cod_cliente;
                       @$nombre=$lp->nombre;
                       @$email=$lp->Correo;
                       @$telefono=$lp->telefono;
                       @$direccion=$lp->direccion;    
                        $updatestock2=$usuariosCon->agregar_clie(@$cod_cliente,@$nombre,@$email,@$telefono,@$direccion,@$pclientee);
                       }else{  
                       }
                        ?>
                <!-- Begin Page Content -->
                    <div class="container-fluid">
                    <div class="row">    
                    <?php
                    if( @$estadomesa== 1){ ?>
                    <form method="post">
                            <input value="2" name="estadomesa"  type="hidden" >
                            <button class="btn btn-sm btn-danger">Ocupado</button>
                            <input type="hidden" name="m" value="<?php echo @$mesan; ?>">
                        
                    </form>
                    <form method="post">
			    <input value="60" name="liberar" type="hidden" >
                            <input value="1" name="estadomesa" type="hidden" >
                            <input type="hidden" name="m" value="<?php echo @$mesan; ?>">
                            <button disabled="true" class="btn btn-sm btn-success">Liberar</button>
                    </form>
                        <?php }elseif( @$estadomesa== 2){ ?>         
                      <form method="post">
                            <input value="2" name="estadomesa"  type="hidden" >
                            <button disabled="true" class="btn btn-sm btn-danger">Ocupado</button>
                            <input type="hidden" name="m" value="<?php echo @$mesan; ?>">
                    </form>
                    <form method="post">
                            <input value="60" name="liberar" type="hidden" >
                            <input value="1" name="estadomesa" type="hidden" >
                            <input type="hidden" name="m" value="<?php echo @$mesan; ?>">
                            <button  class="btn btn-sm btn-success">Liberar</button>
                    </form>
                        <a style="background-color: #0088cc; margin: 10px 0px 4px 0px; color: white"  class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal1">
                        <i class="fas fa-eye mr-2 text-gray-400"></i>
                        Ver Pedido</a>
                        <div id="initial"></div>
                        <?php $pedidomesa=$usuariosCon->mesa_pedido($mesan);
                              while ($pem=mysqli_fetch_object($pedidomesa)){
                              $numpedido=$pem->Cod_pedido;
			      $cuentap=$pem->nump;
                              if($cuentap==0){            
                                        $creapedido=$usuariosCon->creapedido($mesan);
                                        $pedidomesa=$usuariosCon->mesa_pedido($mesan);           
                                        while ($pem=mysqli_fetch_object($pedidomesa)){
                                            $cuentap=$pem->nump;
                                            $numpedido=$pem->Cod_pedido;
                                        }
                                        }elseif ($cuentap>0) {}}
                        $pedidocliente=$usuariosCon->pedidocli($mesan);
					while ($pedcli=mysqli_fetch_object($pedidocliente)){
						$pedcliente=$pedcli->Cod_pedido;
						$n_cliente=$pedcli->n_cliente;
						$n_mesero=$pedcli->usuario;
                                                if ($n_cliente!=  null){}else{
                                                    ?> 
                      <form action="crear_cliente2_1.php" method="get">   
                      <table>
                          <tr>
                              <td><input name="agregar" class="btn btn-info" type="submit" value="+ Agregar Cliente"/></td>
                              <td>
                                  <input name="estadomesa" value="<?php echo $estadomesa; ?>" type="hidden" >
                                  <input name="m" value="<?php echo $mesan; ?>" type="hidden" >
                                  <input name="pedcl" value="<?php echo $pedcliente; ?>" type="hidden" >
                                  
                              </td>
                          </tr>
                      </table>
                      </form>
                   <br>
                   <form action="pedido.php" method="post">  
                   <table class="">
                    <tr>
                    <td>
                    Cliente: 
                    </td> 
                    <td>
                   <select id="mibuscador" name="documento" >
                   <option value="">Seleccione un producto</option>
                      <?php
                                $listapro=$usuariosCon->all_clientes();
				while ($row2=mysqli_fetch_object($listapro)){
				$Cod_producto=$row2->cod_cliente;
				$Descripcion_p=$row2->nombre;
				$stock3_p=$row2->Stock;                  
				?>
                     <option value="<?php echo $Cod_producto; ?>"><?php echo $Cod_producto.'/'.$Descripcion_p; ?></option>
                    <?php } ?>
                    </select>
                    </td> 
                    <td><input type="submit" value="Agregar" >    
                    <input name="pedcl" value="<?php echo $pedcliente; ?>" type="hidden" >
                    <input name="estadomesa" value="<?php echo $estadomesa; ?>" type="hidden" >
                    <input name="m" value="<?php echo $mesan; ?>" type="hidden" >
                    </td>
                    </tr>
                    </table>
                    </form>    
                    <?php 
                    }
                    }
                    }elseif(@$estadomesa=='' or @$estadomesa==null){
                       // echo 'redireccionar';
                        ?>
                          <script language="javascript" type="text/javascript">window.location="index.php";</script>
                        <?php
                    }else{ ?> 
                    <form method="post">
                    <input value="2" name="estadomesa"  type="hidden" >
                    <button  class="btn btn-sm btn-danger">Ocupado</button>
                    <input type="hidden" name="m" value="<?php echo @$mesan; ?>">
                    </form>
                    <form method="post">
                            <input value="1" name="estadomesa" type="hidden" >
                            <input type="hidden" name="m" value="<?php echo @$mesan; ?>">
                            <button  class="btn btn-sm btn-success">Liberar</button>
                        
                    </form>
                    <?php } ?> 
                        <br><br>
                    </div>
                   <!-- Content Row -->
                    <div class="row"  id="tblBodyCurrentOrde">    
	           <?php
   @$pedl = $_POST['itemeslinea'];
   @$cock = $_POST['cocina'];
   if(@$pedl>0){
	//CXXXX
        if ($cock==0){
	 include ('ticket.php');  
  $sstockprf=$usuariosCon->Actualizar_impr(@$pedl);
   } else {
       include ('ticket2.php');
  $sstockprf=$usuariosCon->Actualizar_impr2(@$pedl);
       
   }
}
?>
<?php if( @$estadomesa == 2){ ?> 
   <div class="modal fade " id="logoutModal1">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                            <h6 class="m-0 font-weight-bold text-primary"> Pedido: <?php
                       $pediodof=$numpedido;
                       echo $numpedido;
                       @$productof=$_POST['producto'];
                       @$preciof=$_POST['precio'];
                       @$cantf=$_POST['cantitem'];//2
                       @$preciot= $cantf*$preciof;
                          if(@$productof==null){  
                          }else{
                            $sup_nodis=0;
                        $lisresub=$usuariosCon->sprodped(@$productof);
			while ($row=mysqli_fetch_object($lisresub)){
                        $codsp=$row->cod_sproducto;
                        $cansp=$row->cantidad;// cantidad utilizada solicitada en la receta
                        $canStock=$row->stock;// stock del ingrediente
                        $cantsf=($cansp*$cantf);//  Cantidad requerida del stock
                        if($cantsf>$canStock){
                            $sup_nodis++;
                        }elseif($canStock>=$cantsf && $sup_nodis==0  ) {
                      $cantls1= $cantf*$cansp;
                      $pedidoLinea2=$usuariosCon->creapedidolineas2($pediodof,$codsp,$cantls1,$productof);
                      $sstock=$usuariosCon->Stock_b2($codsp);
                      $stockl2=mysqli_fetch_object($sstock);
                      $s4=$stockl2->s1;
                      $s5=$s4-$cantls1;
                      $updatestock=$usuariosCon->Stock_us2($codsp,$s5);
                        }
                          }
                         
                          }
                            ?>
                            </h6>
                    <form action="" method="post">
                        <input name="pedm" value="<?php echo $numpedido; ?>" type="hidden" />
                        <input name="pedm2" value="<?php echo @$mesan; ?>" type="hidden" />   
                        <?php
                        $listaa=$usuariosCon->usuarioped($numpedido);
                        while ($row12=mysqli_fetch_object($listaa)){
			$usuarioped=$row12->usuario;
                        }
                        ?>
                        <button class="btn btn-sm btn-success">Cambiar Mesa</button>
                    <select required name="mesacam" class="form-control" id="busqueda">
                        <option  value="">Seleccione una opcion </option>
                      <?php             $listadoempm=$usuariosCon->p_mesas(@$mesan);
					while ($row=mysqli_fetch_object($listadoempm)){
						$Nit=$row->Cod;
						$descripcionemp=$row->descripcion;
				?>
                    <option value="<?php echo $Nit; ?>"><?php echo $descripcionemp; ?> </option>
                    <?php } ?>
                    </select>
                    </form>
                    </div>   
                 <div class="card shadow mb-6">
                     <table>
                         <tr>
                            <td>
                                <br>
                         <center>
                     <form method="post">
                         <input value="1" name="estadomesa" type="hidden" >
                            <input type="hidden" name="m" value="<?php echo @$mesan; ?>">   
                         <input type="hidden" name="pedidoc2" value="<?php echo @$pediodof; ?>" min="1" max="50">
                         
                         <?php
                         if($tip_user==3 or $tip_user==2 or $tip_user==1 ){
                         ?>
                          <?php 
                                $numeropedido=$usuariosCon->Contarlineasabiertas($numpedido); 
                                $rowp=mysqli_fetch_object($numeropedido);
                                $cuentae=$rowp->cuentae;
                                
                                if($cuentae==0){
                               
                                ?>

                           <button class="btn btn-sm btn-success">Cerrar pedido</button>  
                           
                           <?php
                                }
                         }
                           ?>
                            </form></center>
                                <br>
                            </td>
                      <td>
                          <br>
                         <center>
                     <form  method="post">
                         <input value="1" name="estadomesa" type="hidden" >
                            <input type="hidden" name="m" value="<?php echo @$mesan; ?>">   
                         <input type="hidden" name="pedidoc" value="<?php echo @$pediodof; ?>" min="1" max="50">
                             
                           <button class="btn btn-sm btn-danger">Cancelar Pedido</button>         
                     </form>
                         </center>
                          <br>
                      </td>
                         </tr>
                         <tr>
                             <td colspan="2">
                                 <center>     
                        <?php
                        
                        /// meseros listado
                        $listusu=$usuariosCon->Listusu();
                        while ($pemusu=mysqli_fetch_object($listusu)){
                        $usuariopedido=$pemusu->usuario;
                        ?>
                            <form style="display: inline-block;" action="#page-top" method="post">
                                <?php 
                                if(@$n_mesero != null){
                                }else{
                                ?>
                            <input type="hidden" name="mesero" value="<?php echo $usuariopedido; ?>" >
                            <?php
                            if($usuarioped==$usuariopedido){                          
                            ?>
                            <input class="btn btn-success" type="submit"  value="<?php echo $usuariopedido; ?>" >
                            <?php
                            }else{ ?>
                            <input type="submit"  value="<?php echo $usuariopedido; ?>" >
                            <?php }}    
                        $listusu2=$usuariosCon->pedidoconsulta(@$mesan);
                        while ($pemusu2=mysqli_fetch_object($listusu2)){
                        $uCod_pedido=$pemusu2->Cod_pedido;
                        ?>
                            <input type="hidden" name="pedido_i" value="<?php echo $uCod_pedido; ?>" min="1" max="50">
                            <input type="hidden" name="pedido_i2" value="<?php echo $uCod_pedido; ?>" min="1" max="50">
                        <?php } ?>
                            
                            <input type="hidden" name="m" value="<?php echo @$mesan; ?>" min="1" max="50">
                            <input type="hidden" name="estadomesa" value="<?php echo @$estadomesa; ?>" min="1" max="50">
                            </form>
                        <?php
                           }
                        ?>
                                 </center>
                            </td>
                         </tr>
                     </table>
                     <table class="table table-bordered">
                         <thead>
                         <th>#</th><th>Item</th><th>Cant</th><th>Linea total</th> <?php   if (@$tip_user==3){ ?><th>Accion</th><?php }?>
                         </thead>
                         <?php 
                         $Num2 = 0;
                         $pedidomesalinea=$usuariosCon->mesa_pedido_suma_linea2($numpedido);
					while ($linea=mysqli_fetch_object($pedidomesalinea)){
                                            
                                           $Num2++;
						$productolinea=$linea->cod_producto;
						$cantlinea=$linea->cant;
						$ltotal=$linea->lt;
						$dp=$linea->Descripcion_p;
						$idpedido=$linea->id;
						$estadolinea=$linea->estado;
                         
                         ?>
                         <tr>
                             <td><?php echo $Num2; ?></td>
                             <td><?php echo $dp; ?></td><td><?php echo $cantlinea; ?></td><td>$ <?php echo $ltotal; ?></td>
                             <td>
                                 <form action="#page-top" method="post">
                                     <input type="hidden" name="m" value="<?php echo @$mesan; ?>" min="1" max="50">
                                          <input type="hidden" name="estadomesa" value="<?php echo @$estadomesa; ?>" min="1" max="50">     
                                     <input type="hidden" value="<?php echo $productolinea; ?>" name="productl" >
                                     <input type="hidden" value="<?php echo $cantlinea; ?>" name="cantlinea" >
                                     <input type="hidden" value="<?php echo $idpedido; ?>" name="idlinea" >
                                     <?php   if ($estadolinea==2){ ?>
                                 <button class="btn btn-danger">x</button>
                                        <?php }elseif($estadolinea==1){ ?>
                                 <div class="btn btn-success">O</div>
                                 <?php if(@$tip_user==3){ ?>
                                 <button class="btn btn-danger">x</button>
                                        <?php } ?>
                                        <?php } ?>
                                 </form>
                             </td>
                         </tr>
                         <?php
                         }
                         ?>
                     </table>
  <div class="card-footer text-muted">
   Total: $ <?php
   $totalpedido=$usuariosCon->pedido_total($numpedido);
   $pediototal=mysqli_fetch_object($totalpedido);
    $total=$pediototal->totalp;
    echo $total;   ?>
   <form style="display: inline-block;" action="" method="post" >
       <input name="itemeslinea" value="<?php echo $pedcliente; ?>" type="hidden" >
       <input name="cocina" value="0" type="hidden" >
       <input name="estadomesa" value="<?php echo $estadomesa; ?>" type="hidden" >
       <input name="m" value="<?php echo $mesan; ?>" type="hidden" >
       <input class="btn btn-success" value="Enviar Barra" type="submit" >
   </form>
   <form style="display: inline-block;" action="" method="post" >
       <input name="itemeslinea" value="<?php echo $pedcliente; ?>" type="hidden" >
                     <input name="cocina" value="1" type="hidden" >
                     <input name="estadomesa" value="<?php echo $estadomesa; ?>" type="hidden" >
                     <input name="m" value="<?php echo $mesan; ?>" type="hidden" >
                     <input class="btn btn-success" value="Enviar Cocina" type="submit" >
   </form>
                 </div>
                 </div>
                 </div>
                 </div>
                 </div>
            <?php }  ?>
            <div class="card shadow mb-4" style="width: 99%;">
            <div  class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Productos / Mesa: <?php echo @$mesan;  ?> / Pedido: <?php echo @$numpedido;  ?> / Cliente: <?php  echo @$n_cliente; ?> / Mesero: <?php  echo @$n_mesero; ?>  </h6>
            </div>
            <div class="card-body">
            <div class="dtsp-verticalContainer">
            <div class="dtsp-verticalPanes"></div>
            <div class="container"><div>
            Click Ocultar o mostrar columnas: <a class="toggle-vis btn btn-info" data-column="0">Cod</a> <a class="toggle-vis btn btn-info" data-column="1">Descripcion</a> <a class="toggle-vis btn btn-info" data-column="2">Categoria</a> <a class="toggle-vis btn btn-info" data-column="3">Sub Cat.</a> <a class="toggle-vis btn btn-info" data-column="4">Vr und </a>
            </div>
                <br>
            <table id="example" class="display nowrap" width="100%" >
            <thead>
            <tr><th>Cod</th>
                <th>Descripcion</th>
                <th>Categoria</th>
                <th>SubCategoria</th>
                <th>Vr un</th>
                <th>Cantidad  </th>
                </tr>
            </thead>
            <tbody>
            <?php 
            $num =1;
            $productos=$usuariosCon->all_productp();
            while ($pro=mysqli_fetch_object($productos)){
            $num2=$num++;
            $des=$pro->Descripcion_p;
            $enlace=$pro->Enlace;
            $vru=$pro->Valor_unitario;
            $iva=$pro->Iva;
            $cat=$pro->categoria;
            $cod_p=$pro->Cod_producto;
            $stock=$pro->Stock;
            $Rece=$pro->Receta;
            $desm=$pro->Descripcion_m;
            $subcategoria=$pro->subcategoria;
            
            $countingredie=$usuariosCon->buscar_ingredientes($cod_p);
                                $sc1=mysqli_fetch_object($countingredie);
                                $sihayingredientes=$sc1->num; 
           
            ?>
            <tr class="<?php if ($Rece=='Y' && $sihayingredientes==0 ) { echo 'alert-danger';}?>">
            <input type="hidden" name="mesa" value="<?php echo $mesan; ?>">
              <td><?php echo $cod_p;?></td>
              <td><?php echo $des;?></td>
              <td><?php echo $cat;?></td>
              <td><?php echo $subcategoria;?></td>
              <td>$ <?php echo $vru;?></td>
              <th>
                  <form action="#page-top" method="post">
              <input type="hidden" name="pedido_i" value="<?php echo $numpedido; ?>" min="1" max="50">
              <input type="hidden" name="producto" value="<?php echo $cod_p; ?>" min="1" max="50">
              <input type="hidden" name="precio" value="<?php echo $vru; ?>" min="1" max="50">
              <input type="hidden" name="m" value="<?php echo @$mesan; ?>" min="1" max="50">
              <input type="hidden" name="estadomesa" value="<?php echo @$estadomesa; ?>" min="1" max="50">
                <?php 
                            if ($Rece=='Y' && $sihayingredientes==0 ) {
                                
                                echo 'Este producto no tiene <br> ingredientes asociados <br> en su receta, <br>no se puede usar<br> verifique sus ingredientes';
                                
                            }else{
                
                if (@$estadomesa==2){ ?>
                  <input type="number" name="cantitem" value="1" min="1" required max="<?php
                  if($Rece=='Y'){
                      echo 9999;
                  }else{
                  echo $stock;
                  }
                  ?>"> <button class="btn btn-info">+</button></td>
                  <?php 
                  }else{
                  } 
                  
                  
            }
                  ?>
                  </form>
                  </th>
                  <?php } ?>
                        </table></div></div>
                            <!-- end-->
                        </div></div></div></div>
            <!-- End of Main Content -->
<!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->
        </div>
        <!-- End of Content Wrapper -->
    </div>
    <!-- End of Page Wrapper -->
     <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

<!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Desea Cerrar sesion?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
               <div class="modal-footer fa fa-angle-up">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Cerrar Sesion</a>
                </div>
            </div>
        </div>
    </div>
<link rel="stylesheet" type="text/css" href="css/select2.css">
        <script src="js/select2.js"></script>
        <script type="text/javascript">
 $(document).ready(function(){
   $("#logoutModal1").modal("show");
});
</script>
</body>
</html>
 <?php } ?>
<script type="text/javascript">
	$('#logoutModal').ready(function(){
		$('#mibuscador').select2();
	});
</script>
<script type="text/javascript">
	$(document).ready( function () {
  var table = $('#example').DataTable({
      "deferRender": true,
        stateSave: true,
        searchPanes: {
          
            cascadePanes: true,
            columns: [3,2],
            layout: 'columns-1',
            dtOpts: {
                dom: "tp",
                paging: true,
                pagingType: 'numbers',
                searching: true,
                pageLength: 6
            }
        },
        "initComplete": function () {
            var api = this.api();
            api.$('td').click( function () {
                api.search( this.innerHTML ).draw();
            } );
        },
        
        pageLength: 10,
       dom: 'Bfrtip',
    buttons: [
        {
            text: "<i class='fas fa-hamburger btn-lg btn-outline-primary'></i>",
            action: function(e, dt, node, config){
                dt.search("HAMBURGUESA").draw();
               
                
            }               
                
            }
            ,
        {
           text: "<i class='fas fa-glass-whiskey btn-lg btn-outline-secondary'></i>",
            action: function(e, dt, node, config){
                dt.search("Shots").draw();
               
               
            }               
                
            }
            ,
        {
           text: "<i class='fa fa-beer btn-lg btn-outline-success'></i>",
            action: function(e, dt, node, config){
                dt.search("Cerveza").draw();
               
                
            }               
                
            },
            {
           text: "<i class='fa fa-beer btn-lg btn-outline-warning'> Vaso</i>",
            action: function(e, dt, node, config){
                dt.search("Vaso").draw();
               
                
            }               
                
            },{
           text: "<i class='fa fa-beer btn-lg btn-outline-info'> Jarra</i>",
            action: function(e, dt, node, config){
                dt.search("Jarra").draw();
               
                
            }               
                
            },
            {
                
           text: "<i class='fa fa-beer btn-lg btn-outline-Dark'> 2*1</i>",
            action: function(e, dt, node, config){
                dt.search("2*1").draw();
               
                
            }               
                
            }, {
            text: "<i class='fa fa-eraser btn-lg btn-outline-danger'></i>",
            action: function(e, dt, node, config){
                dt.search("").draw();
               
                
            }               
                
            }
        
    ]
    });
  table.searchPanes()
  $("div.dtsp-verticalPanes").append(table.searchPanes.container());
  
    $('a.toggle-vis').on( 'click', function (e) {
        e.preventDefault();
 
        // Get the column API object
        var column = table.column( $(this).attr('data-column') );
 
        // Toggle the visibility
        column.visible( ! column.visible() );
    } );
} );
</script>


 



 
