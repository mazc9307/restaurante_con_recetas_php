
<?php 
@session_start(); 
 @$user = $_SESSION["k_username"]; 
 @$tip_user = $_SESSION["tipo_user"];
 @$EmpresAct = $_SESSION["EmpresAct"];
 @$Cod_Empresa = $_SESSION["Cod_Empresa"];
 @$Numdoc = $_SESSION["Numdoc"];
include './class/usuarios.php'; 
                      
                                             
                            $usuariosCon = new Usuarios();
                          
                      
                            ?>
<div class="card mx-3" >
    <div class="card-header">Productos Pedido</div>
<div class="card-body">
                            <div class="table-responsive">
                <table class="table table-bordered">
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>No. pedido</th>
                    <th colspan="2">Mover a pedido</th>
                  
                   
                
                <tbody>
                
                            
                            <?php
                                $usero=$usuariosCon->pedido_on();
                                while ($row2=mysqli_fetch_object($usero)){
						$decp=$row2->Descripcion_p;
						$cantidad=$row2->cantidad;
						$cod_pedido=$row2->cod_pedido;
						$cod_producto=$row2->cod_producto;
						$id=$row2->id;
						$estado=$row2->estado;
						
                                         
                                                 ?>
          
                <tr>
                    <td>   <?php echo $decp; ?></div></td>
                    <td>   <?php echo $cantidad; ?></div></td>
                    <td>   <?php echo $cod_pedido; ?></div></td>
                    <td style="width: 351px" colspan="2">
                        <form action="cocina.php" method="post">
                    <div class="input-group mb-3">
                        <label  class="col-sm-4 control-label">
                             <input name="idlinea" type="hidden" value="<?php echo $id; ?>" >
                            
                            <select  required name="mover_l" style="width: 80px" class="form-control">   
                                 <option value="0?>">Selecione</option>
                      <?php             $listadoemp=$usuariosCon->mover_linea();
					while ($row=mysqli_fetch_object($listadoemp)){
						$Cod_pedido_linea=$row->Cod_pedido;
						
                                             
				?>
                    
                     
                     <option value="<?php echo $Cod_pedido_linea ; ?>"><?php echo $Cod_pedido_linea; ?> </option>
                     
                                        <?php } ?>
                     </select>
                             
                            
                        </label>
                                     <div class="col-sm-3">
                      
                      <label  class="col-sm-3 control-label">
                                         <input type="submit" value="mover" name="mover" >
                      </label>
                  </div>
                  </div><!--/col-sm-9-->
                                     
                 
                                     
                                     
                                 </form>
                    </td>
                    
                    
                    
                </tr>
                    <?php 
                
            
                                                        
                                }
                            
                                ?>
                </tbody>
                </table>
                            
    </div>
    </div>
    </div>
    