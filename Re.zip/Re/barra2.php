
<?php 
@session_start(); 
 @$user = $_SESSION["k_username"]; 
 @$tip_user = $_SESSION["tipo_user"];
 @$EmpresAct = $_SESSION["EmpresAct"];
 @$Cod_Empresa = $_SESSION["Cod_Empresa"];
 @$Numdoc = $_SESSION["Numdoc"];
include './class/usuarios.php'; 
                      
                                             
                            $usuariosCon = new Usuarios();
                            
                      
                            ?>
<div class="card mb-4" >
    <div class="card-header">Productos Pedido</div>
<div class="card-body">
                            <div class="table-responsive">
                <table class="table table-bordered">
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>No. pedido</th>
                    <th>Estado</th>
                    <th> </th>
                    <th> </th>
                    <th> </th>
                    <th> </th>
                <tbody>
                
                            
                            <?php
                                $usero=$usuariosCon->pedido_on2();
                                while ($row2=mysqli_fetch_object($usero)){
						$decp=$row2->Descripcion_p;
						$cantidad=$row2->cantidad;
						$cod_pedido=$row2->cod_pedido;
						$cod_producto=$row2->cod_producto;
						$id=$row2->id;
						$estado=$row2->estado;
						
                                         
                                                 ?>
          
                <tr>
                    <td>   <?php echo $decp; ?></div></td>
                    <td>   <?php echo $cantidad; ?></div></td>
                    <td>   <?php echo $cod_pedido; ?></div></td>
                    <td>   <?php 
                                                                        
                         if ($estado==2) {
                             echo '<div class="btn-danger">';
                             echo "Solicitado";
                             echo '</div>';
                         }elseif ($estado=="-1") {
                             echo '<div class="btn-warning ">';
                             echo 'preparacion';
                             echo '</div>';
                                
                            }elseif ($estado=='-2') {
                                echo '<div class="btn-info">';
                                echo " Listo";
                                echo '</div>';
                            }
                    
                    ?>
                    
                    </div></td>
                    <td>
                        <form id="enviar" action="barra.php" method="post">
                            <input value="<?php echo $id; ?>" name="Pedido" type="hidden" />
                            <input value="1" name="valida" type="hidden" />
                            <?php 
                           
                             if($tip_user==2 or $tip_user==3){
                            
                            ?>
                        <input id="btn-ingresar" class="btn btn-warning " type="submit" name="success" value="Preparacion" style="display: inline-block"/>
                             <?php } ?>
                        </form>
                    </td>
                    <td>
                        <form id="enviar" action="barra.php" method="post">
                            <input value="<?php echo $id; ?>" name="Pedido" type="hidden" />
                            <input value="4" name="valida" type="hidden" />
                            <?php  if($tip_user==2 or $tip_user==3){ ?>
                        <input id="btn-ingresar" class="btn btn-info " type="submit" name="success" value="Listo" style="display: inline-block"/>
                            <?php } ?>
                        </form>
                    </td>
                    <td>
                        <form id="enviar" action="barra.php" method="post">
                            <input value="<?php echo $id; ?>" name="Pedido" type="hidden" />
                            <input value="2" name="valida" type="hidden" />
                        <input id="btn-ingresar" class="btn btn-success " type="submit" name="success" value="Entregado" style="display: inline-block"/>
                        
                        </form>
                    </td>
                    <td>
                        <?php  if($tip_user==2 or $tip_user==3){ ?>
                        <form id="enviar" action="barra.php" method="post">
                            <input value="<?php echo $id; ?>" name="Pedido" type="hidden" />
                            <input value="3" name="valida" type="hidden" />
                        <input class="btn btn-danger " type="submit"  name="cancel" value="X" style="display: inline-block" /> 
                        </form>
                                                <?php } ?>

                    </td>
                </tr>
                    <?php 
                
            
                                                        
                                }
                            
                                ?>
                </tbody>
                </table>
                            
    </div>
    </div>
    </div>
    