<?php
				
                   
                            @$usuarios2= new Usuarios();
				
				if(isset($_POST) && !empty($_POST)){
                                    
                                        $Tempresa = $usuarios2->sanitize($_POST['Tempresa']);
                                    	$tipo_user = @$usuarios2->sanitize($_POST['tipo_user']);
                                    	$Numdoc = @$usuarios2->sanitize($_POST['documento']);
					$usuario = @$usuarios2->sanitize($_POST['usuario']);
					$Nombres = @$usuarios2->sanitize($_POST['nombres']);
					$Apellidos = @$usuarios2->sanitize($_POST['apellidos']);
					$Telefono = @$usuarios2->sanitize($_POST['telefono']);
					$Password1 =@$usuarios2->sanitize($_POST['password']);
                                        $Password = sha1($Password1);
					$Email = @$usuarios2->sanitize($_POST['correo']);
					$Area3 = @$usuarios2->sanitize($_POST['Area']);
				
                                        if($_POST['Tempresa']== null){
                                        
                                                $message="Debe seleccionar una empresa asociada";
						$class="alert alert-danger";
                                        }elseif($_POST['tipo_user']== null){
                                        
                                                $message="Debe seleccionar tipo de usuario";
						$class="alert alert-danger";
                                        }elseif($_POST['documento']== null){
                                        
                                                $message="Debe llenar el documento";
						$class="alert alert-danger";
                                        }elseif ($_POST['usuario'] == null) {
                                            
                                            $message="Debe el Usuario";
						$class="alert alert-danger";
                                        
                                        }elseif ($Nombres == null) {
                                            
                                            $message="Debe llenar Nombre";
						$class="alert alert-danger";
                                        
                                        }elseif ($Apellidos == null) {
                                            
                                            $message="Debe llenar el Apellido";
						$class="alert alert-danger";
                                        }elseif ($Telefono == null) {
                                            
                                            $message="Debe llenar Telefono";
						$class="alert alert-danger";
                                        
                                        }elseif ($Email == null) {
                                            
                                            $message="Debe llenar Email";
						$class="alert alert-danger fade in";
                                        
                                        }elseif ($Password == null) {
                                            
                                            $message="Debe llenar el Password";
						$class="alert alert-danger fade in";
                                        }else{
                                        
                                        
                            
                                 
                                     $res2 = $usuarios2->crea_user($Numdoc,$usuario,$Nombres,$Apellidos,$Password,$Email,$tipo_user,$Telefono,$Tempresa);
					if($res2== true){
                                              $message= "Datos Actualizados con éxito";
						$class="alert alert-success";
                                                ?>

                            <script>
                            
                            </script>


                                          <?php
					}else{
                                         
                                            ?>
                          
                                         
                            <?php               
                                        }}
                        
					?>
				<div class="<?php echo @$class?>">
                                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
				  <?php echo @$message;?>
				  <?php echo @$campo;
                                ?>
				</div>	
					<?php
                                        
				}
	
			?>