<?php


            
 class Usuarios{
     
     public $con;
		//public $dbhost="localhost:3309";
		public $dbhost="localhost:4040";
		public $dbuser="root";
		//public $dbpass="Gbar2120*";
		public $dbpass="123456";
		public $dbname="bar";
		function __construct(){
			$this->connect_db();
		}
		public function connect_db(){
			$this->con = mysqli_connect($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname);
			if(mysqli_connect_error()){
				die("Conexión a la base de datos falló " . mysqli_connect_error() . mysqli_connect_error());
			}
		}
		
		public function sanitize($var){
			$return = mysqli_real_escape_string($this->con, $var);
			return $return;
		}   
     
     public function crea_user($Numdoc,$usuario,$Nombres,$Apellidos,$Password,$Email,$tipo_user,$Telefono,$Tempresa) {
         
         $sql = "INSERT INTO usuarios (Numdoc, usuario, Nombres, Apellidos, password, email, tipo_user,telefono,cod_empresas)"
                 . " VALUES ('$Numdoc','$usuario','$Nombres','$Apellidos','$Password','$Email','$tipo_user','$Telefono','$Tempresa')";
			$res2 = mysqli_query($this->con, $sql);
                        
                        if($res2){
				return true;
			}else{
				return false;
			}
    
}
     public function crea_clie($Numdoc,$Nombres,$Telefono,$Email,$direccion,$tipo) {
         
         $sql = "INSERT INTO clientes (cod_cliente, nombre, telefono, Correo, direccion, tipo) VALUES ('$Numdoc','$Nombres','$Telefono','$Email','$direccion','$tipo')";
			$res2 = mysqli_query($this->con, $sql);
                        
                      if($res2==TRUE){
			$message ="Actualizado con exito";
                        $class="alert alert-success";
                        
                      echo'  <div class="'.$class.'">';
                      echo '<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>';
                      echo $message;
                      echo '</div>';	
                        
			}else{
                        $message= '<b style="color: red;">Error al Crear el Cliente</b>';
                        $class="alert alert-danger";
                        
                      echo'  <div class="'.$class.'">';
                      echo '<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>';
                      echo $message;
                      echo '</div>';	
                        
                      }
    
}
     public function usuario_b($coduser) {
         
         $sql = "select Numdoc, usuario, Nombres, Apellidos, email, tipo_user,tu.descripcion_user,u.telefono,cod_empresas,emp.Razon_soc, cod_area from usuarios as u inner JOIN empresas as emp on emp.cod_empresa=u.cod_empresas inner join tipos_usuarios as tu on tu.id_tipo_user=u.tipo_user where Numdoc='$coduser' ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
     public function usuario_update($Tempresa,$Numdoc,$usuario,$Nombres,$Apellidos,$Email,$tipo_user,$Telefono,$Area) {
         
         $sql = "update usuarios SET Numdoc='$Numdoc', usuario='$usuario', Nombres='$Nombres', Apellidos='$Apellidos', email='$Email', tipo_user='$tipo_user',telefono='$Telefono',cod_empresas='$Tempresa',cod_area='$Area' where Numdoc='$Numdoc' ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
                
    
}

    
                
               public function menu_user2(){
    
            $sql ="select Cod_menu, Nombre_menu, icono from menu";
//            $res = mysqli_query($this->con, $sql);
//            return $return ;
            $res = mysqli_query($this->con, $sql);
            return $res;
    
}

public function cambio_mesa_borrarinfclie($mesan,$estadomesa){
   
     $sql ="UPDATE pedido SET estado='$estadomesa', n_cliente='', Doc_cliente='',Tel_cliente='',correo_cliente='',dir_cliente='', usuario='' WHERE mesa='$mesan' and estado='1' ";
            $res2 = mysqli_query($this->con, $sql);
            return $res2;
            
//                  if($res2==TRUE){
//			echo "actualizado con exito";
//			}else{
//			echo '<b style="color: red;">no se modifico la informacion</b>';
//			}
            }

public function submenus($cod_menu){
                $sql ="select Nombre_submenu, idcarga,Link, Cod_submenu "
                        . "from menu as m inner join sub_menu as s on m.Cod_menu=s.cod_menu  "
                        . "where m.Cod_menu='$cod_menu' ";
                $res = mysqli_query($this->con, $sql);
                return $res;
                
            }
            
             public function existentes($usuario,$num){
    
            $sql ="select count(*) as uno from permisos as mc left join
                sub_menu as c on c.Cod_submenu=mc.cod_consulta where mc.cod_usuario='$usuario' and mc.cod_consulta='$num'";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
            
            
              public function crea_permiso($usuario, $num) {
         
         $sql = "insert into permisos(cod_usuario,Cod_consulta) VALUES ('$usuario','$num')";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}            
            }

     public function Stock_u($productof,$s2) {
         
         $sql = "update productos SET Stock='$s2' where Cod_producto='$productof'; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
     public function Stock_upreceta($productof) {
         
         $sql = "update productos SET Stock='0' where Cod_producto='$productof'; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
     public function agregar_clie($cod_cliente,$nombre,$email,$telefono,$direccion,$pclientee) {
         
         $sql = "update pedido SET Doc_cliente='$cod_cliente' , n_cliente='$nombre',correo_cliente='$email',Tel_cliente='$telefono', dir_cliente='$direccion' where Cod_pedido='$pclientee'; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
     public function Stock_us2($codsp,$s5) {
         
         $sql = "update productos SET Stock='$s5' where Cod_producto='$codsp'; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}

     public function Stock_cancelado($cancelpedido) {
         
         $sql = "SELECT p1.Cod_pedido, p2.cod_producto, p2.cantidad FROM pedido as p1 INNER JOIN pedido_filas as p2 on p2.cod_pedido=p1.Cod_pedido WHERE p1.Cod_pedido='$cancelpedido'; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}

     public function Stock_u2($codsupl,$s333) {
         
         $sql = "update productos SET Stock='$s333' where Cod_producto='$codsupl'; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
     public function Stock_u_add($producto,$s333) {
         
         $sql = "update productos SET Stock='$s333' where Cod_producto='$producto'; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
     public function Stock_u3($codsupl,$productof,$idp2) {
         
         $sql = "update pedido_filas SET estado='3' where Cod_producto='$codsupl' and pro_principal='$productof' and id_linea='$idp2' ; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
     public function Stock_b($productof) {
         
         $sql = "select Stock as s1 from productos where Cod_producto='$productof'; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
 ////// conusltar stock y tipo de preoducto

 
     public function Stock_b_3($productof) {
         
         $sql = "select Stock as s1, Receta, Principal from productos where Cod_producto='$productof'; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
 ////// conusltar stock y tipo de preoducto

 
     public function cuenta_id_si_existe($idp2) {
         
         $sql = "select count(id) as sx from pedido_filas where id='$idp2'; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
// consulta el id del ultimo producto insertado que sea principal
     public function Productoid($producto,$pedido_i) {
         
         $sql = "SELECT id FROM pedido_filas AS pf WHERE pf.cod_pedido='$pedido_i' AND pf.cod_producto='$producto' ORDER BY id DESC LIMIT 1; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
    public function buscar_ingredientes($cod_p) {
         
         $sql = "SELECT COUNT(*) AS num FROM sub_productos AS p WHERE p.cod_producto='$cod_p'; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}

     public function Stock_b3($codsupl) {
         
         $sql = "select Stock as s1 from productos where Cod_producto='$codsupl'; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
     public function Stock_bf($productof) {
         
         $sql = "select Receta from productos where Cod_producto='$productof'; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
public function imprimir_tiket($pedl) {
         
         $sql = "SELECT p.mesa, p1.cod_pedido, p1.cantidad, p1.cod_producto, pro.Descripcion_p, pro.Despacho FROM   pedido_filas AS p1 INNER JOIN pedido AS p ON p.Cod_pedido=p1.cod_pedido 
INNER JOIN productos AS pro ON pro.Cod_producto=p1.cod_producto  
WHERE p1.estado=2 AND p1.cod_pedido='$pedl' and pro.Despacho='Barra';";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
public function imprimir_tiket2($pedl) {
         
         $sql = "SELECT p.mesa, p1.cod_pedido, p1.cantidad, p1.cod_producto, pro.Descripcion_p, pro.Despacho FROM   pedido_filas AS p1 INNER JOIN pedido AS p ON p.Cod_pedido=p1.cod_pedido 
INNER JOIN productos AS pro ON pro.Cod_producto=p1.cod_producto  
WHERE p1.estado=2 AND p1.cod_pedido='$pedl' and pro.Despacho='Cocina';";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
     public function Actualizar_impr($pedl) {
         
         $sql = "update pedido_filas AS p1 INNER JOIN productos AS pro ON pro.Cod_producto=p1.cod_producto SET p1.estado='1' WHERE p1.estado='2' AND pro.Despacho='Barra' AND p1.cod_pedido='$pedl'; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
     public function Actualizar_impr2($pedl) {
         
         $sql = "update pedido_filas AS p1 INNER JOIN productos AS pro ON pro.Cod_producto=p1.cod_producto SET p1.estado='1' WHERE p1.estado='2' AND pro.Despacho='Cocina' AND p1.cod_pedido='$pedl'; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
     public function Stock_bf2($productof,$idp2) {
         
         $sql = "select cod_pedido from pedido_filas where cod_producto='$productof' and id='$idp2' ; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
     public function Stock_b2($codsp) {
         
         $sql = "select Stock as s1 from productos where Cod_producto='$codsp'; ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}
      public function usuario_pass($usua,$password) {
         
         $sql = "update usuarios SET password='$password' where Numdoc='$usua' ";
		$res = mysqli_query($this->con, $sql);
                return $res;
		
    
}

public function mesas(){
    
     $sql ="SELECT Cod,e.estado,Aforo, m.estado as estado_mesa, m.descripcion FROM mesas as m inner JOIN estadom as e on e.id=m.estado where m.estado<4 order by  Convert(Cod,integer) asc";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function user_on(){
    
     $sql ="SELECT usuario FROM usuarios where online =2 order by usuario";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            
   public function pedido_on(){
    
     $sql ="SELECT pf.id,pf.cod_pedido,p.cod_producto,p.Descripcion_p,cantidad,precio,Linea_total,pf.estado FROM pedido_filas as pf inner join productos as p on p.Cod_producto=pf.cod_producto inner join  pedido as p1 on p1.Cod_pedido=pf.cod_pedido where pf.estado='1' and p1.estado='1' order by pf.cod_pedido desc";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            
     
   public function pedido_on2(){
    
     $sql ="SELECT id,cod_pedido,p.cod_producto,p.Descripcion_p,cantidad,precio,Linea_total,pf.estado FROM pedido_filas as pf inner join productos as p on p.Cod_producto=pf.cod_producto where  p.Despacho='Barra' and pf.estado='1' or pf.estado='3' or  pf.estado='2' or pf.estado='-1' or pf.estado='-2' order by cod_pedido desc";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            
public function all_product(){
    
     $sql ="SELECT Cod_producto,Descripcion_p, Enlace, Valor_unitario, Iva, p.Receta, c.categoria , Stock , m.Descripcion_m FROM productos as p INNER JOIN cat_productos as c on c.id=p.cod_cat inner join medidas as m on m.id=p.Medida where Stock>=0  order by Convert(p.Cod_producto, integer) asc ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function all_productp(){
    
     $sql ="SELECT Cod_producto,Descripcion_p, Enlace, Valor_unitario, Iva, p.Receta, c.categoria , Stock , m.Descripcion_m, su.subcategoria FROM productos as p INNER JOIN cat_productos as c on c.id=p.cod_cat inner join medidas as m on m.id=p.Medida left JOIN subcat_productos AS su ON su.id_s=p.id_subcategoria  where Stock>=0 and p.Ingrediente='N' order by Convert(p.Cod_producto, integer) asc ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function all_product1(){
    
     $sql ="SELECT Cod_producto,Descripcion_p, Enlace, Valor_unitario, Iva, c.categoria ,Receta, Stock, m.Descripcion_m FROM productos as p INNER JOIN cat_productos as c on c.id=p.cod_cat  inner join medidas as m on m.id=p.Medida order by Convert(p.Cod_producto, integer) asc ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function all_salidas(){
    
     $sql ="select id,fecha,comentarios, referencia, ref2 from salidas ORDER by id desc ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function all_entradas(){
    
     $sql ="select id,fecha,comentarios, referencia from entradas ORDER by id desc ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function e_mesas(){
    
     $sql ="select id, estado as estadod from  estadom ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function all_mesas(){
    
     $sql ="select Cod,m.estado as code1, e.estado,aforo, descripcion from mesas as m INNER JOIN estadom as e on e.id=m.estado ORDER by Cod  ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function all_categorias(){
    
     $sql ="select id, categoria  , estado from cat_productos ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function all_categorias_b(){
    
     $sql ="select id, categoria  , estado from cat_productos where id<>'$idcat' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function b_subcate($idcat){
    
     $sql ="select count(id_s) as No, id_s ,subcategoria  , estado from subcat_productos where id_categoria='$idcat' and estado='1' GROUP BY id_s, subcategoria, estado ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function b_subcate2($idcategoria1){
    
    
    
     $sql ="select count(id_s) as No, id_s ,subcategoria  , estado from subcat_productos where id_categoria='$idcategoria1' and estado='1' GROUP BY id_s, subcategoria, estado ";
            $res = mysqli_query($this->con, $sql);
            return $res;
}
public function b_subcate3($idcategoria1,$idsubcategoria2){
    
    
    
     $sql ="select count(id_s) as No, id_s ,subcategoria  , estado from subcat_productos where id_categoria='$idcategoria1' and estado='1' and id_s<>'$idsubcategoria2' GROUP BY id_s, subcategoria, estado ";
            $res = mysqli_query($this->con, $sql);
            return $res;
}

            
public function all_scategorias2(){
    
     $sql ="select id_s, subcategoria  , s.estado, s.id_categoria, c.categoria from subcat_productos as s inner join cat_productos as c on c.id=s.id_categoria ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }

public function all_medidas(){
    
     $sql ="select id, Descripcion_m , estado from medidas ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function all_arqueo(){
    
     $sql ="select id, Fecha  , estado, Efectivo, Transferencia,Tarjeta, Daviplata, Nequi, Extras, Gastos, base,Total, diferencia from arqueo ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function mesa_b($update){
    
     $sql ="select Cod,m.estado as code1, e.estado,aforo, descripcion from mesas as m INNER JOIN estadom as e on e.id=m.estado where Cod='$update'  ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function cate_b($update){
    
     $sql ="select id,categoria,estado from cat_productos where id='$update'  ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function scate_b($update){
    
     $sql ="select id_s, subcategoria  , s.estado, s.id_categoria, c.categoria, c.id from subcat_productos as s inner join cat_productos as c on c.id=s.id_categoria  where id_s='$update'  ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function med_b($update){
    
     $sql ="select  id, Descripcion_m, estado FROM medidas where id='$update'  ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function arqueo_b($update){
    
     $sql =" SELECT ID,Fecha, Efectivo, Transferencia, Tarjeta, Daviplata, Nequi, Extras, Gastos, base,Total, Comentarios, estado from arqueo where ID='$update'  ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function cambio_mesa($mesan,$estadomesa){
    
     $sql ="UPDATE mesas SET estado='$estadomesa' WHERE Cod='$mesan' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }

public function cancelarpedido($cancelpedido){
    
     $sql ="UPDATE pedido SET estado='4' WHERE Cod_pedido='$cancelpedido' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            
            
            public function cambiarmesa($pedm,$mesacam){
    
     $sql ="UPDATE pedido SET mesa='$mesacam' WHERE Cod_pedido='$pedm' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            public function cambiarmesapedidoestado($pedmesa2){
    
     $sql ="UPDATE mesas SET estado='1' WHERE Cod='$pedmesa2' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            public function cambiarmesapedidoestado2($mesacam){
    
     $sql ="UPDATE mesas SET estado='2' WHERE Cod='$mesacam' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function cancelarpedidoL($cancelpedido){
    
     $sql ="UPDATE pedido_filas SET estado='3' WHERE cod_pedido='$cancelpedido' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function cerrarpedido($cerrarpedido){
    
     $sql ="UPDATE pedido SET estado='2' WHERE Cod_pedido='$cerrarpedido' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function eliminarpeidolinea($idp2){
    
     $sql ="UPDATE pedido_filas SET estado='3' WHERE id='$idp2' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function eliminarpeidolinea2(){
    
     $sql ="delete from pedido_filas where estado='3'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }

public function mesa_pedido($mesan){
    
     $sql ="SELECT count(*) as nump, Cod_pedido, mesa, estado, usuario FROM pedido WHERE mesa='$mesan' and estado=1 ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function Listusu(){
    
     $sql ="SELECT usuario from usuarios where estado='1' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function pedidoconsulta($mesan){
    
     $sql ="SELECT Cod_pedido from   pedido where mesa='$mesan' ORDER BY  Cod_pedido DESC LIMIT 1 ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function lineasup($productof,$pedido22,$idp2){
    
     $sql ="SELECT id,cantidad,cod_producto FROM pedido_filas WHERE pro_principal='$productof' and cod_pedido='$pedido22' AND id_linea='$idp2'  ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function mesa_pedido_suma_linea($numpedido){
    
     $sql ="SELECT pf.id, pf.cod_pedido, pf.cod_producto, p.Descripcion_p,pf.cantidad as cant ,pf.precio, pf.Linea_total as lt FROM pedido_filas as pf  inner join productos as p on p.Cod_producto=pf.cod_producto WHere cod_pedido='$numpedido' and pf.estado in ('0','1','2','3','5')";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function mesa_pedido_suma_linea2($numpedido){
    
     $sql ="SELECT pf.id, pf.cod_pedido, pf.cod_producto, p.Descripcion_p,pf.cantidad as cant ,pf.precio, pf.Linea_total as lt, pf.estado FROM pedido_filas as pf  inner join productos as p on p.Cod_producto=pf.cod_producto WHere cod_pedido='$numpedido' and pf.estado in ('0','1','2','3')";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function pedidocli($mesan){
    
     $sql ="select Cod_pedido, n_cliente, usuario FROM pedido WHERE mesa ='$mesan' ORDER BY Cod_pedido DESC LIMIT 1 ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function salida_linea_op($numpedido){
    
     $sql ="SELECT s.cod_producto,p.Descripcion_p,s.unidades,s.almacen FROM salidas_filas as s INNER JOIN productos as p on p.Cod_producto=s.cod_producto  WHERE s.cod_salida='$numpedido'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function entrada_linea_op($numpedido){
    
     $sql ="SELECT s.cod_producto,p.Descripcion_p,s.unidades,s.almacen FROM entradas_filas as s INNER JOIN productos as p on p.Cod_producto=s.cod_producto  WHERE s.cod_entrada='$numpedido'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function pedido_total($numpedido){
    
     $sql ="SELECT Sum( Linea_total) as totalp FROM pedido_filas  WHere cod_pedido='$numpedido' and estado<'3'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function creapedido($mesan){
    
     $sql ="insert into pedido (mesa) VALUES ('$mesan')";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function creamesa($mesa,$descripcion,$aforo){
    
     $sql ="insert into mesas (Cod,Aforo, descripcion) VALUES ('$mesa','$aforo','$descripcion')";
            $res2 = mysqli_query($this->con, $sql);
            
         if($res2==TRUE){
				echo "Creado con exito";
			}else{
				echo '<b style="color: red;">error al crear la mesa</b>';
			}
            

            }
public function creacadia($descripcion,$base){
    
     $sql ="insert into arqueo (Fecha,base,Total) VALUES ('$descripcion','$base','$base')";
            $res2 = mysqli_query($this->con, $sql);
            
         if($res2==TRUE){
			echo "Creado con exito";
			}else{
			echo '<b style="color: red;">error al habilitar el dia o ya se creo</b>';
			}
            

            }
public function creacate($descripcion){
    
     $sql ="insert into cat_productos (categoria) VALUES ('$descripcion')";
            $res2 = mysqli_query($this->con, $sql);
            
         if($res2==TRUE){
			echo "Creado con exito";
			}else{
			echo '<b style="color: red;">error al crear la categoria</b>';
			}
            

            }
public function creacates($descripcion,$catego){
    
     $sql ="insert into subcat_productos (subcategoria,id_categoria) VALUES ('$descripcion','$catego')";
            $res2 = mysqli_query($this->con, $sql);
            
         if($res2==TRUE){
			echo "Creado con exito";
			}else{
			echo '<b style="color: red;">error al crear la categoria</b>';
			}
            

            }
public function uamesa($estados2,$aforo2,$descripcions2,$mesa2){
    
     $sql ="update mesas set `estado`='$estados2', `Aforo`='$aforo2', `descripcion`='$descripcions2' where `Cod`='$mesa2' ";
            $res2 = mysqli_query($this->con, $sql);
            
         if($res2==TRUE){
			echo "Actualizado con exito";
			}else{
				echo '<b style="color: red;">Error al actualizar la mesa</b>';
			}

            }
public function uarqueo($estados2,$mesa2,$comentarios2,$efectivo2,$transferencia2,$tarjeta2,$nequi2,$daviplata2,$extras2,$gastos2,$totala,$diferencia){
    
   
     $sql ="update arqueo set `estado`='$estados2', comentarios='$comentarios2', Efectivo='$efectivo2', Transferencia='$transferencia2',"
             . " Tarjeta='$tarjeta2', Nequi='$nequi2', Daviplata='$daviplata2', Extras='$extras2', Gastos='$gastos2', Total='$totala', diferencia='$diferencia'  where  ID='$mesa2' ";
            $res2 = mysqli_query($this->con, $sql);
            
         if($res2==TRUE){
			echo "Actualizado con exito";
			}else{
				echo '<b style="color: red;">Error al actualizar</b>';
			}

}
public function ucate($estados2,$descripcions2,$mesa2){
    
     $sql ="update cat_productos set `estado`='$estados2', `categoria`='$descripcions2' where `id`='$mesa2' ";
            $res2 = mysqli_query($this->con, $sql);
            
         if($res2==TRUE){
			echo "Actualizado con exito";
			}else{
				echo '<b style="color: red;">Error al actualizar la categoria</b>';
			}

}
public function uscate($estados2,$descripcions2,$cate2,$mesa2){
    
     $sql ="update subcat_productos set estado='$estados2', subcategoria='$descripcions2',id_categoria='$cate2'  where id_s='$mesa2' ";
            $res2 = mysqli_query($this->con, $sql);
            
         if($res2==TRUE){
			echo "Actualizado con exito";
			}else{
				echo '<b style="color: red;">Error al actualizar la subcategoria</b>';
			}

}
public function umedi($estados2,$descripcions2,$mesa2){
    
     $sql ="update medidas set `estado`='$estados2', `Descripcion_m`='$descripcions2' where `id`='$mesa2' ";
            $res2 = mysqli_query($this->con, $sql);
            
         if($res2==TRUE){
			echo "Actualizado con exito";
			}else{
				echo '<b style="color: red;">Error al actualizar la mesa</b>';
			}

}
       public function creapedidolinea($pediodof,$productof,$cantf,$preciof,$preciot){
    
     $sql ="insert into pedido_filas (cod_pedido,cod_producto,cantidad,precio,Linea_total,estado) VALUES ('$pediodof','$productof','$cantf','$preciof','$preciot','2')";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
       public function creapedidolinea_new($pedido_i,$producto,$cantitem,$precio,$preciot){
    
     $sql ="insert into pedido_filas (cod_pedido,cod_producto,cantidad,precio,Linea_total,estado) VALUES ('$pedido_i','$producto','$cantitem','$precio','$preciot','2')";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
       public function creapedidolineas2($pediodof,$codsp,$cantls1,$productof){
    
     $sql ="insert into pedido_filas (cod_pedido,cod_producto,cantidad,precio,Linea_total,estado,pro_principal) VALUES ('$pediodof','$codsp','$cantls1','0','0','5','$productof')";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
       public function creapedidolineas2_new($pedido_i,$receta_cod_producto2,$cantidad_final_linea,$producto,$producto_idf){
    
     $sql ="insert into pedido_filas (cod_pedido,cod_producto,cantidad,precio,Linea_total,estado,pro_principal,id_linea) VALUES ('$pedido_i','$receta_cod_producto2','$cantidad_final_linea','0','0','5','$producto','$producto_idf')";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
       public function pedidomesero($numpedido,$mesero){
    
     $sql ="update pedido set usuario='$mesero' where Cod_pedido='$numpedido'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
       public function creapedidolineas3($pedido_o,$propina2){
    
     $sql ="insert into pedido_filas (cod_pedido,cod_producto,cantidad,precio,Linea_total,estado,pro_principal) VALUES ('$pedido_o','15','0','$propina2','$propina2','1','')";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
       public function crear_salida($Cod_pedido){
    
     $sql ="insert into salidas (comentarios, referencia, ref2) VALUES ('Venta','$Cod_pedido','P')";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
       public function crear_salidaL($Numsalida,$cod_producto,$cant,$price,$lt,$almacen){
    
     $sql ="INSERT INTO `salidas_filas` (`id`, `cod_salida`, `cod_producto`, `unidades`, `vr_uni`, `vr_total`, `almacen`, `Stock`) "
             . "VALUES (NULL, '$Numsalida', '$cod_producto', '$cant', '$price', '$lt', '$almacen', '0');";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            
public function consultamesa($mesa){
    
     $sql ="select e.estado, m.estado as e2  from  mesas as m inner join estadom as e on e.id=m.estado WHERE Cod='$mesa' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
            }


public function all_usuarios2(){
    
    $sql ="SELECT  s.Numdoc,s.usuario,s.Nombres,s.Apellidos,s.email,s.tipo_user,t.descripcion_user,s.telefono, s.estado  FROM usuarios as s inner join tipos_usuarios as t on t.id_tipo_user=s.tipo_user";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function all_clientes(){
    
    $sql ="SELECT  cod_cliente, nombre, telefono, Correo, direccion, tipo FROM clientes";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}

public function all_pedidos(){
    
    $sql ="SELECT Cod_pedido, mesa, usuario, e.Descripcion_ep, Fecha FROM pedido as p INNER JOIN estadop as e on e.id_e=p.estado order by p.Cod_pedido desc  ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function countpropina($pedido_o){
    
    $sql ="SELECT count(*) as num  FROM pedido as p inner join pedido_filas as p2 on p.Cod_pedido=p2.cod_pedido  INNER JOIN productos as pro on pro.Cod_producto=p2.cod_producto where p.Cod_pedido='$pedido_o' and pro.Descripcion_p LIKE '%PROPINA%'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function all_pedidos_num($pedido_o){
    
    $sql ="SELECT p.Cod_pedido, sum(Linea_total) as linea_total  FROM pedido as p inner join pedido_filas as p2 on p.Cod_pedido=p2.cod_pedido where p.Cod_pedido='$pedido_o' and p2.estado='1' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function total_arqueo($fecha){
    
    $sql ="SELECT SUM(efectivo) tefectivo, SUM(transferencia)ttransferencia, SUM(tarjeta) ttarjeta,
SUM(daviplata) tdaviplata, SUM(nequi) tnequi, SUM(efectivo+transferencia+tarjeta+daviplata+nequi) ttotal
 FROM pedido WHERE convert(Fecha, DATE)='$fecha' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function base_b($fecha){
    
    $sql ="select base from arqueo  WHERE convert(Fecha, DATE)='$fecha' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function Contarlineasabiertas($numpedido){
    
    $sql ="SELECT count(estado) as cuentae  FROM pedido_filas where estado='2' and cod_pedido='$numpedido' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function all_salida_num($pedido_o){
    
    $sql ="select id,fecha,comentarios, referencia, ref2 from salidas  where id='$pedido_o' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function all_entradas_num($pedido_o){
    
    $sql ="select id,fecha,comentarios, referencia from entradas  where id='$pedido_o' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function all_pedidos_open($pedido_o){
    
    $sql ="SELECT Cod_pedido, mesa, usuario, e.Descripcion_ep, p.estado, Fecha,  n_cliente, Doc_cliente, Tel_cliente, correo_cliente, dir_cliente, efectivo, transferencia, tarjeta, daviplata, nequi FROM pedido as p INNER JOIN estadop as e on e.id_e=p.estado where Cod_pedido='$pedido_o' order by Fecha asc  ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function all_pedidos_excel(){
    
    $sql ="SELECT ped.Cod_pedido, ped.mesa,CONVERT(ped.Fecha, date) as Fecha,e.Descripcion_ep, ped.n_cliente, ped.Doc_cliente, ped.Tel_cliente, ped.correo_cliente,ped.dir_cliente,pf.cod_producto, p.Descripcion_p, pf.cantidad,m.Descripcion_m, pf.precio, pf.Linea_total, 
(select sum(Linea_total) from pedido_filas where Cod_pedido=ped.Cod_pedido) as total_pedido
from pedido as ped INNER join pedido_filas as pf on pf.cod_pedido=ped.Cod_pedido INNER join productos as p on p.Cod_producto=pf.cod_producto inner JOIN medidas as m on m.id=p.Medida inner join estadop as e on e.id_e=ped.estado order by fecha desc  ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function all_pedidos_excel3($fechaa,$fechab){
    
    $sql ="SELECT ped.Cod_pedido, ped.mesa,CONVERT(ped.Fecha, date) as Fecha,e.Descripcion_ep, ped.n_cliente, ped.Doc_cliente, ped.Tel_cliente, ped.correo_cliente,ped.dir_cliente,pf.cod_producto, p.Descripcion_p, pf.cantidad,m.Descripcion_m, pf.precio, pf.Linea_total, 
(select sum(Linea_total) from pedido_filas where Cod_pedido=ped.Cod_pedido) as total_pedido
from pedido as ped INNER join pedido_filas as pf on pf.cod_pedido=ped.Cod_pedido INNER join productos as p on p.Cod_producto=pf.cod_producto inner JOIN medidas as m on m.id=p.Medida inner join estadop as e on e.id_e=ped.estado where  convert(fecha, date) between '$fechaa' and '$fechab' and ped.estado='3' order by fecha desc  ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function all_pedidos_excel2($pedido){
    
    $sql ="SELECT ped.Cod_pedido, ped.mesa,CONVERT(ped.Fecha, date) as Fecha,e.Descripcion_ep, ped.n_cliente, ped.Doc_cliente, ped.Tel_cliente, ped.correo_cliente,ped.dir_cliente,pf.cod_producto, p.Descripcion_p, pf.cantidad,m.Descripcion_m, pf.precio, pf.Linea_total, 
(select sum(Linea_total) from pedido_filas where Cod_pedido=ped.Cod_pedido) as total_pedido
from pedido as ped INNER join pedido_filas as pf on pf.cod_pedido=ped.Cod_pedido INNER join productos as p on p.Cod_producto=pf.cod_producto inner JOIN medidas as m on m.id=p.Medida inner join estadop as e on e.id_e=ped.estado where ped.Cod_pedido='$pedido' order by fecha desc ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function all_usuempresa($Cod_Empresa){
    
    $sql ="SELECT  s.Numdoc,s.usuario,s.Nombres,s.Apellidos,s.email,s.tipo_user,t.descripcion_user,s.telefono,s.cod_empresas,e.Razon_soc,s.cod_area,se.Nombre_Sucursal,s.estado,es.Descripcion_e  FROM usuarios as s inner JOIN empresas as e on e.cod_empresa=s.cod_empresas left JOIN sedes as se on se.Cod_sede=s.cod_area left JOIN tipos_usuarios as t on t.id_tipo_user=s.tipo_user left join estadosg AS es ON es.ID=s.estado where s.cod_empresas=$Cod_Empresa";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function all_mant1(){
    
    $sql ="SELECT e1.ID, e1.serial, e1.modelo,t1.descripcion as marca, t2.descripcion as tipo, e1.comentarios from equipos as e1 INNER join tipo_des as t1 on t1.ID=e1.marca INNER JOIN tipo_des as t2 on t2.ID=e1.tipo  where e1.ID NOT in (SELECT m.id_equipo FROM mantenimientos as m where m.id_equipo in (SELECT e.ID  from equipos as e ) and m.fecha>=(DATE_SUB(NOW(),INTERVAL 2 MONTH)))";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function all_mant(){
    
    $sql ="select id_mant, fecha,id_empresa,e.Razon_soc,id_sede,s.Nombre_Sucursal,id_equipo, eq.serial,eq.serial,tecnico,observaciones,nombre_contacto,m.tel_contacto,correo_contacto,funcionamiento from mantenimientos as m inner JOIN empresas as e on e.cod_empresa=m.id_empresa inner JOIN equipos as eq on eq.ID=m.id_equipo inner JOIN sedes as s on s.Cod_sede=m.id_sede";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function all_usuarios3(){
    
    $sql ="SELECT  s.Numdoc,s.usuario,s.Nombres,s.Apellidos,s.email,s.tipo_user,t.descripcion_user,s.telefono,s.cod_empresas,e.Razon_soc,s.cod_area,se.Nombre_Sucursal,s.estado,es.Descripcion_e  FROM usuarios as s inner JOIN empresas as e on e.cod_empresa=s.cod_empresas inner JOIN sedes as se on se.Cod_sede=s.cod_area inner JOIN tipos_usuarios as t on t.id_tipo_user=s.tipo_user inner join estadosg AS es ON es.ID=s.estado limit 2 ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function all_sedes(){
    
    $sql ="SELECT Cod_sede,e.Razon_soc,Nombre_Sucursal,s.Direccion,s.Contacto,s.Tel_contacto FROM sedes as s inner JOIN empresas as e on e.cod_empresa=s.Cod_empresa";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function all_sedese($Cod_Empresa){
    
    $sql ="SELECT Cod_sede,e.Razon_soc,Nombre_Sucursal,s.Direccion,s.Contacto,s.Tel_contacto FROM sedes as s inner JOIN empresas as e on e.cod_empresa=s.Cod_empresa where s.Cod_empresa=$Cod_Empresa";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}


public function count_enero1(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/01/01' and '2020/01/31' and t.estado='1'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_enero2(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/01/01' and '2020/01/31' and t.estado='2'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_enero3(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/01/01' and '2020/01/31' and t.estado='3'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            
//febrero
public function count_feb1(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/02/01' and '2020/02/29' and t.estado='1'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_feb2(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/02/01' and '2020/02/29' and t.estado='2'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_feb3(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/02/01' and '2020/02/29' and t.estado='3'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            
//Marzo
public function count_mar1(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/03/01' and '2020/03/31' and t.estado='1'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_mar2(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/03/01' and '2020/03/31' and t.estado='2'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_mar3(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/03/01' and '2020/03/31' and t.estado='3'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }            
            
//Abril
public function count_abr1(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/04/01' and '2020/04/30' and t.estado='1'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_abr2(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/04/01' and '2020/04/30' and t.estado='2'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_abr3(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/04/01' and '2020/04/30' and t.estado='3'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }            
            
 //Mayo
public function count_may1(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/05/01' and '2020/05/31' and t.estado='1'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_may2(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/05/01' and '2020/05/31' and t.estado='2'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_may3(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/05/01' and '2020/05/31' and t.estado='3'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            } 
            
  //Junio
public function count_jun1(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/06/01' and '2020/06/30' and t.estado='1'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_jun2(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/06/01' and '2020/06/30' and t.estado='2'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_jun3(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/06/01' and '2020/06/30' and t.estado='3'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            } 
            
//Julio
public function count_jul1(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/07/01' and '2020/07/31' and t.estado='1'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_jul2(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/07/01' and '2020/07/31' and t.estado='2'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_jul3(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/07/01' and '2020/07/31' and t.estado='3'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }  
            
  //Agosto
public function count_ago1(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/08/01' and '2020/08/31' and t.estado='1'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_ago2(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/08/01' and '2020/08/31' and t.estado='2'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_ago3(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/08/01' and '2020/08/31' and t.estado='3'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
 //sep
public function count_sep1(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/09/01' and '2020/09/30' and t.estado='1'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_sep2(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/09/01' and '2020/09/30' and t.estado='2'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_sep3(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/09/01' and '2020/09/30' and t.estado='3'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }  


//oct
public function count_oct1(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/10/01' and '2020/10/31' and t.estado='1'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_oct2(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/10/01' and '2020/10/31' and t.estado='2'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_oct3(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/10/01' and '2020/10/31' and t.estado='3'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }  

//nov
public function count_nov1(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/11/01' and '2020/11/30' and t.estado='1'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_nov2(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/11/01' and '2020/11/30' and t.estado='2'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_nov3(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/11/01' and '2020/11/30' and t.estado='3'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }  

//nov
public function count_dic1(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/12/01' and '2020/12/31' and t.estado='1'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_dic2(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/12/01' and '2020/12/31' and t.estado='2'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
public function count_dic3(){
    
     $sql ="select count(*) as enero_activo from tiket2 as t where t.fecha BETWEEN '2020/12/01' and '2020/12/31' and t.estado='3'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }  


///////////////////////////////////777            
            
public function sedes_b($Cod_sede){
    
    $sql ="SELECT Cod_sede,e.Razon_soc,e.cod_empresa,Nombre_Sucursal,s.Direccion,s.Contacto,s.Tel_contacto FROM sedes as s inner JOIN empresas as e on e.cod_empresa=s.Cod_empresa where Cod_sede=$Cod_sede";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function sedes_b2($cod_empresas){
    
    $sql ="SELECT Cod_sede,e.Razon_soc,e.cod_empresa,Nombre_Sucursal,s.Direccion,s.Contacto,s.Tel_contacto FROM sedes as s inner JOIN empresas as e on e.cod_empresa=s.Cod_empresa where e.cod_empresa='$cod_empresas'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function all_equipos(){
    
    $sql ="SELECT e.ID,t.descripcion,e.marca,t2.descripcion as descripcion2,e.modelo,e.serial,e.capacidad,e.cant_bat,e.Voltaje,s.Nombre_Sucursal FROM equipos as e left JOIN tipo_des as t on t.id_tipo=e.tipo left JOIN sedes as s ON s.Cod_sede=e.sede left JOIN tipo_des as t2 on t2.id_tipo=e.marca GROUP by e.ID";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function equipos_b($codequipo){
    
    $sql ="SELECT emp.Razon_soc, e.ID,e.tipo,t.descripcion,e.marca,t2.descripcion as descripcion2,e.modelo,e.serial,e.capacidad,e.cant_bat,e.Voltaje,s.Nombre_Sucursal,e.sede,e.comentarios, caracteristica, t3.descripcion as caract FROM equipos as e left JOIN tipo_des as t on t.id_tipo=e.tipo left JOIN sedes as s ON s.Cod_sede=e.sede left join tipo_des as t3 on t3.id_tipo=caracteristica left JOIN tipo_des as t2 on t2.id_tipo=e.marca left JOIN empresas as emp on emp.cod_empresa=s.Cod_empresa  where e.ID='$codequipo' group by e.ID order by Razon_soc ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}

public function count_usuarios($EmpresAct){
    
    $sql ="select  count(*) as total from usuarios as u inner join empresas as e on e.cod_empresa=u.cod_empresas where e.estado=1 and Razon_soc='$EmpresAct'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function count_usuarios_all(){
    
    $sql ="select  count(*) as total_all from usuarios as u inner join empresas as e on e.cod_empresa=u.cod_empresas where u.estado=1";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function count_usuarios_e($Cod_Empresa){
    
    $sql ="select  count(*) as total_all from usuarios as u inner join empresas as e on e.cod_empresa=u.cod_empresas where u.estado=1 and e.cod_empresa=$Cod_Empresa";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function count_sedes_all(){
    
    $sql ="SELECT count(*) as tclie from sedes as s INNER JOIN empresas as e on s.Cod_empresa=e.cod_empresa";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function count_sedes($Cod_Empresa){
    
    $sql ="SELECT count(*) as tclie from sedes as s INNER JOIN empresas as e on s.Cod_empresa=e.cod_empresa where e.cod_empresa=$Cod_Empresa";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
  
public function Tipo_user(){
    
    $sql ="select id_tipo_user, descripcion_user from tipos_usuarios order by descripcion_user";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function Tipo_user2(){
    
    $sql ="select id_tipo_user, descripcion_user from tipos_usuarios where id_tipo_user =1 order by descripcion_user";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function Tipo_empresa(){
    
    $sql ="select cod_empresa,Razon_soc from empresas order by Razon_soc";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function Tipo_categoria($cod_cat){
    
    $sql ="select id,categoria from cat_productos where id<>'$cod_cat' and estado=1 order by categoria asc";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function all_categoria(){
    
    $sql ="select id,categoria from cat_productos where estado=1 order by categoria";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function mover_linea(){
    
    $sql ="select Cod_pedido from pedido where  estado=1 order by Cod_pedido";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function recetaitems($cproducto){
    
    $sql ="select m.Descripcion_m ,p.Descripcion_p as des, sp.id,sp.cod_producto, sp.cod_sproducto as subp, sp.cantidad as cantsub from sub_productos as sp left join productos as p on p.Cod_producto=sp.cod_sproducto inner join medidas as m on m.id=p.Medida where sp.cod_producto='$cproducto' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function recetaitemscopia($cod_copia){
    
    $sql ="SELECT cod_sproducto,cantidad FROM sub_productos WHERE cod_producto='$cod_copia' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function recetaitems2($producto){
    
    $sql ="select m.Descripcion_m ,p.Descripcion_p as des, sp.id,sp.cod_producto, sp.cod_sproducto as subp, sp.cantidad as cantsub ,p.Stock from sub_productos as sp left join productos as p on p.Cod_producto=sp.cod_sproducto inner join medidas as m on m.id=p.Medida where sp.cod_producto='$producto' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}

public function p_mesas($mesan){
    
    $sql ="select Cod,estado,descripcion from mesas where estado in ('1','3','4') and Cod !='$mesan' order by descripcion";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}

public function usuarioped($numpedido){
    
    $sql ="select usuario from pedido where Cod_pedido='$numpedido'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function sprodped($productof){
    
    $sql ="select sp.cod_sproducto, sp.cantidad, p2.stock from productos as p inner join sub_productos as sp on sp.cod_producto=p.Cod_producto inner JOIN productos as p2 on p2.Cod_producto=sp.cod_sproducto WHERE p.Cod_producto='$productof' ORDER BY P2.stock asc";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}

public function Tipo_medida($Medida){
    
    $sql ="select id,Descripcion_m from medidas where id<>'$Medida' order by Descripcion_m";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function Tipo_almacen(){
    
    $sql ="select id,cod_almacen, descripcion from almacenes order by descripcion";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function Product_b($idpro){
    
    $sql ="select Cod_producto,Descripcion_p,Valor_unitario, cod_cat, c.categoria, almacen,a.descripcion,Medida,m3.Descripcion_m,p.estado,e.Descripcion_ep, Enlace, Despacho, Receta, Principal, Ingrediente, sub.id_s, sub.subcategoria from productos as p inner JOIN estadop as e on e.id_e=p.estado INNER JOIN almacenes as a on a.id=p.almacen INNER JOIN cat_productos as c on c.id=p.cod_cat INNER join medidas as m3 on m3.id=p.Medida left JOIN subcat_productos AS sub ON sub.id_s=p.id_subcategoria  where p.Cod_producto='$idpro'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
             if($res==TRUE){
				echo "Actualizado con exito";
			}else{
				echo '<b style="color: red;">error al crear la mesa</b>';
			}
            
    
}
public function Cliente_b($idpro){
    
    $sql ="select cod_cliente, nombre, Correo,telefono, direccion, tipo from clientes where cod_cliente='$idpro'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
             if($res==TRUE){
				echo "Actualizado con exito";
			}else{
				echo '<b style="color: red;">error al crear la mesa</b>';
			}
            
    
}
public function Prduct_u(){
    
    $sql ="UPDATE `productos` SET `Descripcion_p`=[value-2],`Valor_unitario`=[value-3],`Iva`=[value-4],`cod_cat`=[value-5],`Stock`=[value-6],`almacen`=[value-7],`Medida`=[value-8],`estado`=[value-9],`Enlace`=[value-10] WHERE 1";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function producto_s(){
    
    $sql ="select Cod_producto,Descripcion_p, Stock from productos where Stock>0 order by Descripcion_p";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function producto_s2(){
    
    $sql ="select p.Cod_producto,p.Descripcion_p, p.Stock, m.Descripcion_m from productos as p inner join medidas as m on m.id=p.Medida order by Descripcion_p";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function producto_sub2(){
    
    $sql ="select p.Cod_producto,p.Descripcion_p, p.Stock, m.Descripcion_m from productos as p inner join medidas as m on m.id=p.Medida where p.Receta='N' and Principal='N' order by Descripcion_p";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}

public function producto_sub12(){
    
    $sql ="select p.Cod_producto,p.Descripcion_p, p.Stock, m.Descripcion_m from productos as p inner join medidas as m on m.id=p.Medida and p.Receta='N' and Principal='Y'  order by Descripcion_p";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function producto_sub13(){
    
    $sql ="select p.Cod_producto,p.Descripcion_p, p.Stock, m.Descripcion_m from productos as p inner join medidas as m on m.id=p.Medida and p.Receta='Y' and Principal='N'  order by Descripcion_p";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}

public function Tipo_empresa2($Cod_Empresa){
    
    $sql ="select cod_empresa,Razon_soc from empresas where cod_empresa=$Cod_Empresa";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function Tipo_sede(){
    
    $sql ="select e.Razon_soc, a.Cod_sede,Nombre_Sucursal from sedes as a inner join empresas as e on a.Cod_empresa=e.cod_empresa order by Nombre_Sucursal";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function Tipo_Area(){
    
    $sql ="select id_tipo,descripcion from tipo_des WHERE id_tipo=2 order by descripcion ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function Tipo_Caracteristica(){
    
    $sql ="select id_tipo,descripcion from tipo_des WHERE id_tipo=3 order by descripcion ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function Tipo_Area2(){
    
    $sql ="select id_tipo,descripcion from tipo_des WHERE id_tipo=1 order by descripcion ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function Tipo_Area_B($b){
    
    $sql ="select a.cod_area,descripcion_area from areas  as a inner join empresas_areas as ea "
            . " on a.cod_area=ea.cod_area  inner join empresas as e on e.cod_empresa=ea.cod_empresa where e.cod_empresa='$b'  order by descripcion_area";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}

public function Sucursal_B($b){
    
      
    $sql ="select a.Cod_sede,Nombre_Sucursal from sedes as a inner join empresas as e on a.Cod_empresa=e.cod_empresa where e.cod_empresa='$b'  order by Nombre_Sucursal";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}

public function cuenta_tiket($user){
    
    $sql ="select COUNT(*) as ntiket from usuarios as u inner JOIN tiket as t on t.responsable1=u.Numdoc where usuario='$user' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}

public function cuenta_tiket2($user){
    
    $sql ="select COUNT(*) as ntiket from empresas as e inner JOIN tiket2 as t on t.empresa=e.cod_empresa where t.usuario='$user' and t.estado<3 ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function cuenta_tiketAtiket(){
    
    $sql ="select COUNT(*) as ntiket from tiket2 as t where t.estado <='2'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function cuenta_mant(){
    
    $sql ="SELECT COUNT(*) as num from equipos as e1 where e1.ID NOT in (SELECT m.id_equipo FROM mantenimientos as m where m.id_equipo in (SELECT e.ID  from equipos as e ) and m.fecha>=(DATE_SUB(NOW(),INTERVAL 2 MONTH)))";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function cuenta_ta(){
    
    $sql ="SELECT COUNT(*) as num from tiket2 where estado=1";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function cuenta_te(){
    
    $sql ="SELECT COUNT(*) as num from tiket2 where estado=2";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function cuenta_tc(){
    
    $sql ="SELECT COUNT(*) as num from tiket2 where estado=3";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}

public function cuenta_tiketAtiket3($Cod_Empresa){
    
    $sql ="select COUNT(*) as ntiket from tiket2 as t where t.estado <='2' and empresa=$Cod_Empresa  ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function solicitudes($Numdoc){
    
    $sql ="select count(*) as total, usuarios.Numdoc as usuariosId, usuarios.usuario as usuario, solicitudes.id as solicitudesId, solicitudes.usuario as solicitudesUsuario from solicitudes inner join usuarios on solicitudes.usuario=usuarios.Numdoc where solicitud='$Numdoc'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function solicitudes2($Numdoc){
    
    $sql ="select count(*) as total, usuarios.Numdoc as usuariosId, usuarios.usuario as usuario, solicitudes.id as solicitudesId, solicitudes.usuario as solicitudesUsuario from solicitudes inner join usuarios on solicitudes.usuario=usuarios.Numdoc where solicitud='$Numdoc'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function solicitudescomprueba($Numdoc,$id){
    
    $sql ="select count(*) as comprobado from contactos where usuario=$Numdoc and contacto=$id";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}

 public function confirmarsol($Numdoc,$id,$fecha) {
       
         $sql = "insert into contactos (usuario,contacto,fecha) VALUES ('$Numdoc','$id','$fecha')";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}
    
}
 public function up_pro($cod_producto,$des,$vru,$cat,$alma,$medx,$anom,$estadi,$despa,$recet,$principalt,$Ingrediente,$subcategoriano) {
     
         $sql = "update productos set  Descripcion_p='$des', Valor_unitario='$vru', cod_cat='$cat', almacen='$alma', Medida='$medx', Enlace='productos/$anom', estado='$estadi', Despacho='$despa', Receta='$recet', Principal='$principalt', Ingrediente='$Ingrediente',id_subcategoria='$subcategoriano'  where Cod_producto='$cod_producto';";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}
                        
                        
    
}
 public function up_clie($documento,$Nom2,$tel2,$mail2,$dir2,$tipo) {
     
         $sql = "update clientes set nombre='$Nom2', telefono='$tel2', Correo='$mail2', direccion='$dir2', tipo='$tipo' where cod_cliente='$documento';";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}
                        
                        
    
}
 public function up_pro2($cod_producto,$des,$vru,$cat,$alma,$medx,$estadi,$despa,$recet,$principalt,$Ingrediente,$subcategoriano) {
     
         $sql = "update productos set  Descripcion_p='$des', Valor_unitario='$vru', cod_cat='$cat', almacen='$alma', Medida='$medx', estado='$estadi', Despacho='$despa', Receta='$recet', Principal='$principalt', Ingrediente='$Ingrediente', id_subcategoria='$subcategoriano' where Cod_producto='$cod_producto';";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}
                        
                        
    
}
 public function Crea_pro($cod_producto,$des,$vru,$cat,$alma,$medx,$anom,$Despacho,$receta2,$principal2,$subcate,$ingrediente2) {
     
         $sql = "INSERT INTO productos (Cod_producto, Descripcion_p, Valor_unitario, Iva, cod_cat, Stock, almacen, Medida, estado, Enlace, Despacho,Receta,Principal,id_subcategoria,Ingrediente) VALUES ('$cod_producto','$des','$vru','19','$cat','0','$alma','$medx','1','$anom','$Despacho','$receta2','$principal2','$subcate','$ingrediente2');";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}
                        
                        
    
}
 public function Crea_spro($idpro,$cod_subp,$cants) {
     
         $sql = "INSERT INTO sub_productos (cod_producto , cod_sproducto, cantidad) VALUES ('$idpro','$cod_subp','$cants');";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}
                        
                        
    
}
 public function Crea_spro2($idpro,$idcod_sproducto,$idcantidad) {
     
         $sql = "INSERT INTO sub_productos (cod_producto , cod_sproducto, cantidad) VALUES ('$idpro','$idcod_sproducto','$idcantidad');";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}
                        
                        
    
}

public function borra_spro($idprosu) {
     
         $sql = "DELETE FROM sub_productos WHERE id ='$idprosu'";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}
                        
                        
    
}
 public function crea_salida($comentarios) {
       
         $sql = "insert into salidas (comentarios,referencia, ref2) VALUES ('$comentarios', 'Salida', 'S')";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}
    
}
 public function crea_entrada($comentarios) {
       
         $sql = "insert into entradas (comentarios,referencia) VALUES ('$comentarios','S')";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
							

				return true;
			}else{
				return false;
				
				echo $comentarios;
			}
    
}
 public function crea_salidalinea($salidab,$num,$unidades,$almacen,$ncantidad) {
       
         $sql = "insert into salidas_filas (cod_salida , cod_producto, unidades, almacen, Stock) VALUES ('$salidab','$num','$unidades','$almacen','$ncantidad')";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}
    
}
 public function crea_entradalinea($salidab,$num,$unidades,$precio,$preciof,$almacen,$ncantidad) {
       
         $sql = "insert into entradas_filas (cod_entrada , cod_producto, unidades, vr_uni, vr_total, almacen, Stock) VALUES ('$salidab','$num','$unidades','$precio','$preciof','$almacen','$ncantidad')";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}
    
}

 public function udpates($num,$ncantidad) {
     
     
         $sql = "update productos set Stock='$ncantidad' where Cod_producto='$num'";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
                           
				return true;
			}else{
                            
				return false;
			}
    
}
 public function salida_b2() {
       
         $sql = "SELECT id FROM salidas ORDER by id DESC limit 1";
			$res4 = mysqli_query($this->con, $sql);
                        
                      
				return $res4;
			
    
}
 public function salida_b3() {
       
         $sql = "SELECT id FROM entradas ORDER by id DESC limit 1";
			$res4 = mysqli_query($this->con, $sql);
                        
                      
				return $res4;
			
    
}
 public function Cuentasalida() {
       
         $sql = "select s.id, count(s2.cod_salida) num_salida from salidas as s left JOIN salidas_filas as s2 on s.id=s2.cod_salida GROUP by s.id  LIMIT 1";
			$ress = mysqli_query($this->con, $sql);
                        
                      
				return $ress;
			
    
}
 public function Cuentaentrada() {
       
         $sql = "select s.id, count(s2.cod_entrada) num_salida from entradas as s left JOIN entradas_filas as s2 on s.id=s2.cod_entrada GROUP by s.id LIMIT 1";
			$ress = mysqli_query($this->con, $sql);
                        
                      
				return $ress;
			
    
}
 public function prod_b($num) {
       
         $sql = "SELECT Stock, Valor_unitario as precio from productos where Cod_producto='$num';";
			$res53 = mysqli_query($this->con, $sql);
                        
                      
				return $res53;
			
    
}

public function eliminasol($Numdoc,$id){
    
    $sql ="delete from solicitudes where usuario=$id and solicitud=$Numdoc";
            $res2 = mysqli_query($this->con, $sql);
            if($res2){
				return true;
			}else{
				return false;
			}
            
    
}

public function contactos($Numdoc){
    
    $sql ="select Numdoc as contactoact, Nombres, Apellidos from contactos as c inner join usuarios as u on c.contacto=u.Numdoc where c.usuario='$Numdoc'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}
public function usrchat($id2){
    
    $sql ="select usuario from usuarios where Numdoc='$id2'";
            $res3 = mysqli_query($this->con, $sql);
            	
             return $res3;
            
    
}

/////tickets

public function empresa($idempresa){
    
            $sql ="select cod_empresa, Razon_soc as sucursal from empresas where cod_asoc=$idempresa order by Razon_soc";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
               public function empresa_all(){
    
            $sql ="select cod_empresa, Razon_soc from empresas where estado=1 order by Razon_soc";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
               public function empresa_mant($id2){
    
            $sql ="select id_mant,fecha,id_empresa,e.Razon_soc,id_sede,s.Nombre_Sucursal,id_equipo, eq.serial,eq.serial,tecnico,observaciones,nombre_contacto,m.tel_contacto,correo_contacto,funcionamiento 
from mantenimientos as m inner JOIN empresas as e on e.cod_empresa=m.id_empresa inner JOIN equipos as eq on eq.ID=m.id_equipo inner JOIN sedes as s on s.Cod_sede=m.id_sede where id_mant='$id2'";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
               public function sede($idempresa){
    
            $sql ="SELECT cod_sede, Nombre_Sucursal FROM sedes WHERE Cod_empresa=$idempresa order by Nombre_Sucursal";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
               public function equipo($b){
    
            $sql ="SELECT e.ID,e.serial,e.modelo from equipos as e INNER JOIN sedes as s on s.Cod_sede=e.sede WHERE e.ID=$b order by e.modelo ";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
               public function usuario($b){
    
            $sql ="select Numdoc, concat(Apellidos,' ',Nombres) as Nombre,descripcion_area from usuarios as n inner join areas as a on a.cod_area=n.cod_area where tipo_user=5 and cod_empresas=$b order by Nombre";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
               public function usuario2(){
    
            $sql ="select Numdoc, concat(Apellidos,' ',Nombres) as Nombre from usuarios as n order by Nombre";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
               public function usuario_emp($b2){
    
            $sql ="select usuario, concat(Apellidos,' ',Nombres) as Nombre from usuarios  as u where cod_empresas=$b2 order by Nombre";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
            

             public function Tipo_tiket(){
    
            $sql ="select cod_tipo_tiket, descripcion_tiket from tipo_tiket ";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
            
             public function Tiket_prio(){
    
            $sql ="select cod_prioridad, descripcion_prioridad from prioridad ";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
            
            public function empresabus($idempresa){
    
            $sql ="select cod_empresa, Razon_soc from empresas where cod_empresa=$idempresa order by Razon_soc";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
            
           public function Tiket_prio_bus($prioridad){
    
            $sql ="select cod_prioridad, descripcion_prioridad from prioridad where cod_prioridad=$prioridad ";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
            
             public function Tipo_tiket_bus($tipotiket){
    
            $sql ="select cod_tipo_tiket, descripcion_tiket from tipo_tiket where cod_tipo_tiket=$tipotiket ";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
            
            public function usuario_bus($usuario_resp){
    
            $sql ="select Numdoc, concat(Apellidos,' ',Nombres) as Nombre,descripcion_area from usuarios as n inner join areas as a on a.cod_area=n.cod_area where Numdoc=$usuario_resp";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
            
            
            public function clientes_tiket($b){
    
    $sql ="SELECT c.cod_cliente, c.Razon_soc as Razon  from clientes_asociados as cs INNER JOIN clientes as c on c.Nit=cs.cod_cliente where cs.cod_empresa=$b";
            $res = mysqli_query($this->con, $sql);
            return $res;
            
    
}

      public function clientes_tiket2($empresa){
    
    $sql ="SELECT c.cod_cliente, c.Razon_soc as Razon  from clientes_asociados as cs INNER JOIN clientes as c on c.Nit=cs.cod_cliente where c.cod_cliente=$empresa";
            $res = mysqli_query($this->con, $sql);
            return $res;
    
}
      public function sede1($sede){
    
    $sql ="SELECT Cod_sede,Nombre_Sucursal from sedes where Cod_sede=$sede";
            $res = mysqli_query($this->con, $sql);
            return $res;
    
}

 public function crea_tiket($idempresa,$tipotiket,$prioridad,$empresa,$nom_sol,$fuente,$usuario_resp,$asunto,$mesajet,$fecha_fin2) {
         
         $sql = "INSERT INTO tiket (cod_empresa,cod_tipo_tiket,cod_prioridad,cod_cliente,solicitante_cliente,fuente,responsable1,asunto,mensaje,fecha_fin)"
                 . " VALUES ('$idempresa','$tipotiket','$prioridad','$empresa','$nom_sol','$fuente','$usuario_resp','$asunto','$mesajet','$fecha_fin2')";
			$res2 = mysqli_query($this->con, $sql);
                        
                        if($res2){
				return true;
			}else{
				return false;
			}            
            }
            
 public function crea_tiket2($sede,$equipo,$nom_sol,$correo,$tel,$tipotiket,$archivos,$asunto,$mesajet,$empresa,$usuario1) {
         
         $sql = "INSERT INTO tiket2 (sede,equipo,nom_sol,correo,tel,tipotiket,archivo,asunto,mesajet,empresa,usuario)"
                 . " VALUES ('$sede','$equipo','$nom_sol','$correo','$tel','$tipotiket','$archivos','$asunto','$mesajet','$empresa','$usuario1')";
			$res2 = mysqli_query($this->con, $sql);
                        
                        if($res2){
				return true;
			}else{
				return false;
			}            
            }
            
            
            
            public function detalle_tiket(){
    
    $sql ="select  t.cod_tiket,t.asunto, t.estado,  convert(t.fecha, date) as fechat from usuarios as u inner JOIN tiket2 as t on u.usuario=t.usuario where t.estado<3 order by t.fecha desc ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            public function detalle_tiket2($user){
    
    $sql ="select  t.cod_tiket,t.asunto, t.estado,  convert(t.fecha, date) as fechat from usuarios as u inner JOIN tiket2 as t on u.usuario=t.usuario where t.usuario='$user' and t.estado<3 order by t.fecha desc ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            public function detalle_tiket3($Cod_Empresa,$user){
    
     $sql ="select t.cod_tiket,t.asunto,t.nom_sol, convert(t.fecha, date) as fechat, t.estado from tiket2 as t where t.empresa='$Cod_Empresa' and usuario='$user' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            
            public function detalle_tiket4($Cod_Empresa){
    
     $sql ="select  t.cod_tiket,t.cod_tipo_tiket,t.asunto,p.descripcion_prioridad,t.solicitante_cliente, t.cod_estado1,"
             . "t.cod_estado2,t.cod_estado3, convert(t.fecha, date) as fechat, t.fuente,t.cod_cliente, t.mensaje,convert(t.fecha_fin, date) as fecha_t2 "
             . "from tiket as t  inner join prioridad as p on p.cod_prioridad=t.cod_prioridad where cod_empresa='$Cod_Empresa'  ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }        
            
             public function detalle_tiket_open($cod_tiket){
    
    $sql =" select  t.cod_tiket, t.asunto,t.mesajet,t.estado,  t.fecha as fechat, t.usuario from  tiket2 as t left join usuarios as u on u.usuario=t.usuario  where t.cod_tiket=$cod_tiket order by fecha desc limit 1 ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            
            public function usuario_asignado_area($user){
    
    $sql ="select cod_area, cod_empresas from usuarios where usuario='$user' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            
            public function update_cerrar($cod_tiket){
    
    $sql ="UPDATE tiket2 SET estado='3' WHERE cod_tiket='$cod_tiket' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            public function pedido_cobrado($Cod_pedido,$nombreC,$docC,$telC,$corcl,$dircl,$efectivo,$tranferencia,$Tarjeta,$daviplata,$nequi){
    
    $sql ="UPDATE pedido SET estado='3', n_cliente='$nombreC', Doc_cliente='$docC', Tel_cliente='$telC', correo_cliente='$corcl', dir_cliente='$dircl', efectivo='$efectivo', transferencia='$tranferencia', tarjeta='$Tarjeta', daviplata='$daviplata', nequi='$nequi' WHERE Cod_pedido='$Cod_pedido' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            
            public function pedido_cobrado2($Cod_pedido,$efectivo,$tranferencia,$Tarjeta,$daviplata,$nequi){
    
    $sql ="UPDATE pedido SET estado='3', efectivo='$efectivo', transferencia='$tranferencia', tarjeta='$Tarjeta', daviplata='$daviplata', nequi='$nequi' WHERE Cod_pedido='$Cod_pedido' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            
            public function update_cerrar2($cod_tiket){
    
    $sql ="UPDATE tiket2 SET estado='2' WHERE cod_tiket='$cod_tiket' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            
            public function usuario_asignado1($area,$aempre){
    
    $sql ="select Numdoc, Nombres, Apellidos from usuarios where tipo_user='1' and cod_area='$area'  and cod_empresas='$aempre'  ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }

             public function upasignar_usuario2($usuario_resp,$cod_tiket){
    
    $sql ="UPDATE tiket SET responsable2='$usuario_resp',cod_estado3='3' WHERE cod_tiket='$cod_tiket' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            
           public function Salida_b($Cod_pedido){
    
            $sql ="select referencia, id from salidas where referencia=$Cod_pedido";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
           public function Cliente_b2($docC){
    
            $sql ="select cod_cliente, nombre, telefono,Correo,direccion from clientes where cod_cliente='$docC' ";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
            
           public function clientes($cod_cliente){
    
            $sql ="select cod_cliente, Razon_soc as cliente from clientes where cod_cliente=$cod_cliente";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
            
            public function tipo_t($fuente){
    
            $sql ="select cod_fuente, descripcion from fuente_tiket where cod_fuente=$fuente";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }   
            
            public function tipo_tiket2($cod_tipo_tiket){
    
            $sql ="select cod_tipo_tiket, descripcion_tiket from tipo_tiket where cod_tipo_tiket=$cod_tipo_tiket";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }      
            
            
            public function usuario_info($user){
    
    $sql ="SELECT usuario, Nombres, Apellidos, email, tipo_user, t.descripcion_user,u.telefono, cod_empresas,e.Razon_soc, u.estado FROM usuarios as u inner join tipos_usuarios as t on t.id_tipo_user=u.tipo_user inner JOIN empresas as e on e.cod_empresa=u.cod_empresas WHERE usuario='$user'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            }
            public function usuario_info2($coduser){
    
    $sql ="SELECT Numdoc, usuario, Nombres, Apellidos, email, tipo_user, t.descripcion_user,u.telefono, cod_empresas,e.Razon_soc, u.estado FROM usuarios as u inner join tipos_usuarios as t on t.id_tipo_user=u.tipo_user inner JOIN empresas as e on e.cod_empresa=u.cod_empresas WHERE Numdoc='$coduser'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            }
            public function ticketc(){
    
    $sql ="SELECT usuario, Nombres, Apellidos, email, tipo_user, t.descripcion_user,u.telefono, cod_empresas,e.Razon_soc, u.estado FROM usuarios as u inner join tipos_usuarios as t on t.id_tipo_user=u.tipo_user inner JOIN empresas as e on e.cod_empresa=u.cod_empresas WHERE usuario='$user'";
            $res = mysqli_query($this->con, $sql);
            return $res;
            }
            
             public function update_profile($nom,$apel,$email,$Telefono,$estado1u,$usuario1) {
         
         $sql = "update usuarios set Nombres='$nom', Apellidos='$apel',email='$email',telefono='$Telefono',estado='$estado1u' where usuario='$usuario1' ";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}
    
}
             public function update_profile2($nom1,$apel1,$email1,$Telefono1,$estado1,$Numdoc) {
         
         $sql = "update usuarios set Nombres='$nom1', Apellidos='$apel1',email='$email1',telefono='$Telefono1',estado='$estado1' where Numdoc='$Numdoc' ";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}
    
}
             public function update_pass($Passc,$usuario1) {
         
         $sql = "update usuarios set password='$Passc' where usuario='$usuario1' ";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}
    
}
             public function update_pass2($Passc,$usuario1) {
         
         $sql = "update usuarios set password='$Passc' where usuario='$usuario1' ";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}
    
}

            
 }
 
 

 