<?php
				
                   
                            @$usuarios2= new Usuarios();
				
				if(isset($_POST) && !empty($_POST)){
                                    
                                        $Numdoc = @$usuarios2->sanitize($_POST['documento']);
					$Nombres = @$usuarios2->sanitize($_POST['nombre']);
					$Telefono = @$usuarios2->sanitize($_POST['telefono']);
					$Email = @$usuarios2->sanitize($_POST['correo']);
					$direccion = @$usuarios2->sanitize($_POST['direccion']);
					$tipo = @$usuarios2->sanitize($_POST['estado']);
				
                                    if($_POST['documento']== null){
                                        
                                                $message="Debe llenar el documento";
						$class="alert alert-danger";
                                        }elseif ($Nombres == null) {
                                            
                                            $message="Debe llenar Nombre";
						$class="alert alert-danger";
                                        
                                        }elseif ($Telefono == null) {
                                            
                                            $message="Debe llenar Telefono";
						$class="alert alert-danger";
                                        
                                        }elseif ($Email == null) {
                                            
                                            $message="Debe llenar Email";
						$class="alert alert-danger fade in";
                                        
                                     
                                        }elseif ($direccion == null) {
                                            
                                            $message="Debe llenar Email";
						$class="alert alert-danger fade in";
                                        
                                        }else{
                                            
                                     $res2 = $usuarios2->crea_clie($Numdoc,$Nombres,$Telefono,$Email,$direccion,$tipo);
  
					?>

				
		<?php
                                        
				}
                                }
			?>