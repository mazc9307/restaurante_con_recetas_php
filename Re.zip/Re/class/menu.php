<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of menu
 *
 * @author Administrador
 */
class menu {
    //put your code here
    
        	 public $con;
		//$public $dbhost="localhost:3309";
		public $dbhost="localhost:4040";
		public $dbuser="root";
		public $dbpass="123456";
		//public $dbpass="Gbar2120*";
		public $dbname="bar";
		function __construct(){
			$this->connect_db();
		}
		public function connect_db(){
			$this->con = mysqli_connect($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname);
			if(mysqli_connect_error()){
				die("Conexión a la base de datos falló " . mysqli_connect_error() . mysqli_connect_errno());
			}
		}
		
		public function sanitize($var){
			$return = mysqli_real_escape_string($this->con, $var);
			return $return;
		}    
                
               public function menu_user(){
    
            $sql ="select Cod_menu, Nombre_menu, icono from menu";
//            $res = mysqli_query($this->con, $sql);
//            return $return ;
            $res = mysqli_query($this->con, $sql);
            return $res;
    
}

            public function submenus($cod_menu){
                $sql ="select Nombre_submenu, idcarga,Link, Cod_submenu "
                        . "from menu as m inner join sub_menu as s on m.Cod_menu=s.cod_menu  "
                        . "where m.Cod_menu='$cod_menu' ";
                $res = mysqli_query($this->con, $sql);
                return $res;
                
            }
  
            public function u_linea_E_1($pl){
    
     $sql ="UPDATE pedido_filas SET estado='-1' WHERE id='$pl' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
                   public function u_mueve($mv,$pas12){
    
     $sql ="UPDATE pedido_filas SET cod_pedido='$mv' WHERE id='$pas12' ";
            $res = mysqli_query($this->con, $sql);
            if($res==TRUE){
			$message ="Actualizado con exito";
                        $class="alert alert-success";
                        
                      echo'  <div class="'.$class.'">';
                      echo '<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>';
                      echo $message;
                      echo '</div>';	
                        
			}else{
                        $message= '<b style="color: red;">Error al mover el pedido</b>';
                        $class="alert alert-danger";
                        
                      echo'  <div class="'.$class.'">';
                      echo '<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>';
                      echo $message;
                      echo '</div>';	
                        
                      }
            

            }
            public function u_linea_E_2($pl){
    
     $sql ="UPDATE pedido_filas SET estado='-2' WHERE id='$pl' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            public function u_linea_E($pl){
    
     $sql ="UPDATE pedido_filas SET estado='3' WHERE id='$pl' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }
            public function u_linea_3($pl){
    
     $sql ="UPDATE pedido_filas SET estado='1' WHERE id='$pl' ";
            $res = mysqli_query($this->con, $sql);
            return $res;
            

            }


   
               public function menu_user2($user){
    
            $sql ="select m.Cod_menu, m.Nombre_menu, m.icono from menu as m inner JOIN sub_menu as s ON s.cod_menu=m.Cod_menu INNER JOIN permisos as p on p.cod_consulta=s.Cod_submenu INNER JOIN usuarios as u on u.Numdoc=p.cod_usuario where u.usuario='$user' GROUP BY m.Cod_menu, m.Nombre_menu,m.icono;";
//            $res = mysqli_query($this->con, $sql);
//            return $return ;
            $res = mysqli_query($this->con, $sql);
            return $res;
    
}
               public function menu_image($user){
    
            $sql ="select imagen from empresas as e inner join usuarios as u on u.cod_empresas=cod_empresa where u.usuario='$user' ;";
//            $res = mysqli_query($this->con, $sql);
//            return $return ;
            $res = mysqli_query($this->con, $sql);
            return $res;
    
}

            public function submenus2($user,$cod_menu){
                $sql ="select s.Nombre_submenu, s.idcarga,s.Link, s.Cod_submenu from menu as m inner JOIN sub_menu as s ON s.cod_menu=m.Cod_menu INNER JOIN permisos as p on p.cod_consulta=s.Cod_submenu INNER JOIN usuarios as u on u.Numdoc=p.cod_usuario where u.usuario='$user' and m.Cod_menu='$cod_menu' ";
                $res = mysqli_query($this->con, $sql);
                return $res;
                
            }

            
            public function usuario(){
    
            $sql ="select usuario, Numdoc, concat(Apellidos,' ',Nombres) as Nombre,descripcion_area from usuarios as n left join areas as a on a.cod_area=n.cod_area ";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
            
            public function existentes($usuario,$num){
    
            $sql ="select count(*) as uno from permisos as mc left join
                sub_menu as c on c.Cod_submenu=mc.cod_consulta where mc.cod_usuario='$usuario' and mc.cod_consulta='$num'";
            $res = mysqli_query($this->con, $sql);
            return $res;   
            }
            
              public function crea_permiso($usuario, $num) {
         
         $sql = "insert into permisos(cod_usuario,Cod_consulta) VALUES ('$usuario','$num')";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}            
            }
              public function up_online($user) {
         
         $sql = "update usuarios set online='2' where usuario='$user'";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}            
            }
            
              public function up_offline($user) {
         
         $sql = "update usuarios set online='1' where usuario='$user'";
			$res = mysqli_query($this->con, $sql);
                        
                        if($res){
				return true;
			}else{
				return false;
			}            
            }
            
            
            
            

    
    
}
