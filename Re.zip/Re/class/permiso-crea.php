<?php


if ($_SERVER["REQUEST_METHOD"] == "POST") { 
    
    
  @$numero=$_POST["numero"];
  if($numero==null){
      
     
  }else{
  
  $usuario=$_POST["usuario"];
    $count = count($numero);
    
    for ($i = 0; $i < $count; $i++) {
        
       $num = $numero[$i];
       
        
     $res = $usuariosCon->existentes($usuario,$num);
     while (@$row=mysqli_fetch_object(@$res)){
    
             $uno=$row->uno;
           
      if( $uno==1 ){
        ?>
<div class="">
                  <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                  <strong>ya esta asignado </strong> </div>

<?php
      }elseif($uno==0) {
          
            ?>
<div class="">
                  <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                  <strong>se inserto permiso nuevo</strong> </div>

<?php
    $res = $usuariosCon->crea_permiso($usuario,$num);
 
   }
   // aqui
   
    
}}}}
?>