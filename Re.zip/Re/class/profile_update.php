<?php
				
				$usuario= new Usuarios();
                                
                                
				if(isset($_POST) && !empty($_POST)){
                                    
                                    	@$nom1 = $usuario->sanitize($_POST['nombre']);
                                    	@$apel1 = $usuario->sanitize($_POST['apellido']);
					@$email1 = $usuario->sanitize($_POST['email']);
					@$Telefono1= $usuario->sanitize($_POST['Telefono']);
					@$estado1u = $usuario->sanitize($_POST['estado']);
                                        
					@$usuario1= $usuario->sanitize($_POST['usuario']);
					
					
                                        
                                        if($_POST['nombre']== null){
                                        
                                                $message="Nombre Vacio";
						$class="alert alert-danger";
                                        }elseif($_POST['apellido']== null){
                                        
                                                $message="Apellido Vacio";
						$class="alert alert-danger";
                                        }elseif($_POST['email']== null){
                                        
                                                $message="Email Vacio";
						$class="alert alert-danger";
                                        }elseif($_POST['Telefono']== null){
                                        $message="Telefono Vacio";
						$class="alert alert-danger";
                                                
                                        }else{
                                            
                                        
                                      
					$res = $usuario->update_profile($nom1,$apel1,$email1,$Telefono1,$estado1u,$usuario1);
					if($res){
						$message= "Datos Actualizados con éxito";
						$class="alert alert-success";
                                       
                                                  ?>
                                      
                            <script>
                            function myFunction() {
                              alert("datos actualizados con exito!<?php echo $estado1; ?>");
                            window.location="all_users.php";
                            }
                            myFunction();
                            </script>


                                          <?php
					}else{
						$message="No se pudieron insertar los datos";
						$class="alert alert-danger";
                                        }}
                        
					?>
                            <div style="height: 50px;" class="<?php echo @$class?>">
                                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
				  <?php echo @$message;?>
				  <?php echo @$campo;
                                ?>
				</div>	
					<?php
				}
                                
                                if(isset($_POST) && !empty($_POST)){
                                    
                                  
					$pass1 = $usuario->sanitize($_POST['password']);
					$rpass1= $usuario->sanitize($_POST['rpassword']);
					
					
                                        
                                        if($_POST['password']== null && $_POST['rpassword']== null){
                                        $message1=NULL;
						$class2=NULL;
                                                
                                        }elseif($_POST['password']== null && $_POST['rpassword'] != null){
                                        
                                                $message1="password Vacio";
						$class2="alert alert-danger";
                                                
                                        }elseif($_POST['password'] !=  $_POST['rpassword']){
                                            
                                                $message1="Los password no coinciden";
						$class2="alert alert-danger";
                                                
                                        }elseif($_POST['password'] != null && $_POST['rpassword']== null){
                                            
                                                $message1="RPassword  Vacio";
						$class2="alert alert-danger";
                                                
                                        }else{
                                            
                                          $Passc = sha1($rpass1);
                                        
					$res = $usuario->update_pass($Passc,$usuario1);
					if($res){
						$message1= "Datos Actualizados con éxito";
						$class2="alert alert-success";
                                       
                                                  ?>
                                      
                            


                                          <?php
					}else{
						$message1="Se Cambio la contraseña";
						$class2="alert alert-danger";
                                        }}
                        
					?>
                            <div style="height: 50px;" class="<?php echo @$class?>">
                                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
				  <?php echo @$message1;?>
				  <?php echo @$campo;
                                ?>
				</div>	
					<?php
				}
	
			?>