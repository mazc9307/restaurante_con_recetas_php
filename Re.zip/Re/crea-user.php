 <?php   session_start(); 
 @$user = $_SESSION["k_username"]; 
 @$tip_user = $_SESSION["tipo_user"];
 @$EmpresAct = $_SESSION["EmpresAct"];
 @$Cod_Empresa = $_SESSION["Cod_Empresa"];
 @$Numdoc = $_SESSION["Numdoc"];
 
 if($user== null){
          
     ?>
     
     <script language="javascript" type="text/javascript">                        
		window.location="logout.php";
		</script>
     <?php
 }else{
 
 ?>
<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Crear Usuario</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
   <?php   include 'class/menu.php' ?>
<?php   include './menu_user.php'; ?>
        
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <?php  
               
               include './menu_notifi.php'; ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    
             
                   <!-- Content Row -->
                    <div class="row ">
                        
               
                        <form method="post" id="formulario" class="jumbotron col-sm-7 mx-auto">
            
            <?php 
            include 'class/usuarios.php';
            
            if($tip_user==3){ 
                 $usuariosCon = new Usuarios();
                $listadoemp=$usuariosCon->Tipo_empresa();
                ?>
            <div class="input-group mb-3">
                    <label  class="col-sm-3 control-label">Empresa Asociada</label>
                  <div class="col-sm-9">
                      
                      <select required name="Tempresa" class="form-control" id="busqueda">
                        <option  value="">Seleccione una opcion </option>
                      <?php 
					while ($row=mysqli_fetch_object($listadoemp)){
						$Nit=$row->cod_empresa;
						$descripcionemp=$row->Razon_soc;
                                             
				?>
                    
                     <option value="<?php echo $Nit; ?>"><?php echo $descripcionemp; ?> </option>
                     
                                        <?php } ?>
                     </select>
                  </div><!--/col-sm-9-->
                  <label></label>   
                </div><!--/form-group-->
                
                
            <?php }
                
                
           if ($tip_user==3 ) {
                        
                $listado=$usuariosCon->Tipo_user();
                                
                ?>
                
                
                
                <div class="input-group mb-3">
                    <label class="col-sm-3 control-label">Tipo Usuario</label>
                  <div class="col-sm-9">
                      
                      <select required name="tipo_user" class="form-control" id="source2">
                        <option value="">Seleccione una opcion </option>
                      <?php 
					while ($row=mysqli_fetch_object($listado)){
						$Tipo_u=$row->id_tipo_user;
						$descripcionu=$row->descripcion_user;
                                             
				?>
                    
                     <option value="<?php echo $Tipo_u; ?>"><?php echo $descripcionu; ?> </option>
                     
                                        <?php } ?>
                     </select>
                  </div><!--/col-sm-9-->
                  
                  <label></label>   
                </div><!--/form-group-->
                
                
           <?php  } ?>

                <div id="resultado"></div>
		<div class="form-group">
                  <label>Documento</label>
                  <input type="text" name="documento" maxlength="10" required placeholder="Ingrese documento" class="form-control">
                </div><!--/form-group-->
                <div class="form-group">
                  <label>Usuario</label>
                  <input type="text" name="usuario" parsley-trigger="change" required placeholder="Ingrese usuario" class="form-control">
                </div><!--/form-group-->
                <div class="form-group">
                  <label>Nombres</label>
                  <input type="text" name="nombres" parsley-trigger="change" required placeholder="Ingrese nombres" class="form-control">
                </div><!--/form-group-->
                <div class="form-group">
                  <label>Apellidos</label>
                  <input type="text" name="apellidos" parsley-trigger="change" required placeholder="Ingrese Apellidos" class="form-control">
                      
                </div><!--/form-group-->
                <div class="form-group">
                  <label>Telefono</label>
                  <input type="text" name="telefono" parsley-trigger="change" required placeholder="Ingrese Telelfono" class="form-control">
                </div><!--/form-group-->
                <div class="form-group">
                  <label>Correo Electronico</label>
                  <input type="email" name="correo" parsley-trigger="change" required placeholder="Ingrese correo" class="form-control">
                </div><!--/form-group-->
                <div class="form-group">
                  <label>Password</label>
                  <input id="pass1" type="password" placeholder="Password" required class="form-control">
                </div><!--/form-group-->
                <div class="form-group">
                  <label>Repita Password</label>
                  <input parsley-equalto="#pass1" name="password" type="password" required placeholder="Password" class="form-control">
                </div><!--/form-group-->
                <div class="checkbox">
                </div><!--/checkbox-->
                <input id="btn-ingresar" class="btn btn-primary" type="submit" value="Crear"/>
                <div id="resp"></div>
        
                
	</form>      
            </div>
        
            
                  <?php include './class/user-creado.php';   ?>   
                        
            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

   

    <?php include './footer.php'; ?>

</body>

</html>

 <?php } ?>