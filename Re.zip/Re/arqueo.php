 <?php   session_start(); 
 @$user = $_SESSION["k_username"]; 
 @$tip_user = $_SESSION["tipo_user"];
 @$EmpresAct = $_SESSION["EmpresAct"];
 @$Cod_Empresa = $_SESSION["Cod_Empresa"];
 @$Numdoc = $_SESSION["Numdoc"];
 
 if($user== null){
          
     ?>
     
     <script language="javascript" type="text/javascript">                        
		window.location="logout.php";
		</script>
     <?php
 }else{
 
 ?>
<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Arqueo</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
     <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">


</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
   <?php   include 'class/menu.php' ?>
<?php   include './menu_user.php'; ?>
        
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <?php   include './menu_notifi.php'; 
               
               
               include ('class/usuarios.php');
				$usuariosCon = new Usuarios();
                              ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                   <!-- Content Row -->
                   <?php 
                     @$mesa = $_POST["mesa"];
                     @$descripcion = $_POST["Fecha"];
                     @$aforo = $_POST["aforo"];
                     @$base = $_POST["base"];
                     
                            
                if($mesa==null){
                }else{
                ?>
                
                <div   class="alert alert-success" >
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                
                                
                <?php   $pr=$usuariosCon->creacadia($descripcion,$base); ?>  
                
		</div>
                
                <?php
                            }
                            
@$mesa2=$_POST["mesa2"];//id del arqueo
@$aforo2=$_POST["aforo2"];
@$estados2=$_POST["estados2"];
@$fecha2=$_POST["fecha"];
@$efectivo2=$_POST["efectivo"];
@$transferencia2=$_POST["transferencia"];
@$tarjeta2=$_POST["tarjeta"];
@$nequi2=$_POST["nequi"];
@$daviplata2=$_POST["daviplata"];
@$extras2=$_POST["extras"];
@$gastos2=$_POST["gastos"];
@$comentarios2=$_POST["comentarios"];
@$basest=$_POST["Basecaja"];
@$diferencia2=$_POST["diferencia"];






@$totala= $efectivo2+$transferencia2+$tarjeta2+$nequi2+$daviplata2+$extras2+$gastos2+$basest;



if(@$mesa2==null){
    
    
    
    
}else{
    
                  ?>
                
                <div   class="alert alert-success" >
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                

                <?php 
                
                $pr=$usuariosCon->uarqueo($estados2,$mesa2,$comentarios2,$efectivo2,$transferencia2,$tarjeta2,$nequi2,$daviplata2,$extras2,$gastos2,$totala,$diferencia2); ?>  
                
		</div>
                
                <?php
    
    
    
}
                              
                            
                            ?>
         
                   
                   <?php
                  
                   
                   if($mesa2>0){
                   @$update = $mesa2;
                   
                   
                   } else {
                       @$update = $_POST["pedido"];
                   }
                   
                   
                   if($update==null) {
                       
                       ?>
                   
                    <form method="post" id="formulario" class="card card-body col-sm-7 mx-auto" >
                        
          <div class="input-group mb-3">
              <h1>Habilitar dia</h1>  
          </div><!--/form-group-->      
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Descripcion</label>
          <div class="col-sm-9">
              <input value="" placeholder="Fecha" name="Fecha" type="date" />
          <input value="1" name="mesa" type="hidden" />
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Base Caja</label>
          <div class="col-sm-9">
              <input value="" placeholder="Base Caja" name="base" type="text" />
         
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label"></label>
          <div class="col-sm-9">
              <input value="Habilitar dia" name="crear" required="true" type="submit" maxlength="2" max="20" min="1" />
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
                
          </form>
                   
                   <br>
                   <br>
                                <?php 

                       
                       
                   }else{
                       
                       $mesa=$usuariosCon->arqueo_b($update);
                       $pro2=mysqli_fetch_object($mesa);
                       
                                                $nums2=$pro2->ID;
						$estado=$pro2->estado;
						$tranferencia=$pro2->Transferencia;
						$efectivo=$pro2->Efectivo;
						$daviplata=$pro2->Daviplata;
						$nequi=$pro2->Nequi;
						$tarjeta=$pro2->Tarjeta;
						$extras=$pro2->Extras;
						$gastos=$pro2->Gastos;
						$total=$pro2->Total;
						$comentarios=$pro2->Comentarios;	
						$fecha=$pro2->Fecha;
						$base3=$pro2->base;
                                                
                                                
                                 $numearqueo=$usuariosCon->total_arqueo($fecha); 
                                $rowp=mysqli_fetch_object($numearqueo);
                                $tefectivo=$rowp->tefectivo;
                                $ttransferencia=$rowp->ttransferencia;
                                $ttarjeta=$rowp->ttarjeta;
                                $tdaviplata=$rowp->tdaviplata;
                                $tnequi=$rowp->tnequi;
                                $ttotal=$rowp->ttotal;
                                
                                
                                 $numearqueo1=$usuariosCon->base_b($fecha); 
                                $rowp1=mysqli_fetch_object($numearqueo1);
                                $tbase=$rowp1->base;
                                
                                                
                   
                   ?>
                   
                    <form method="post" id="formulario" class="card card-body col-sm-7 mx-auto" >
                        <h4>Detalle del dia <?php echo $fecha; ?></h4>
                        <br>
                        <br>
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">ID</label>
          <div class="col-sm-9">
          <input readonly="true" value="<?php  echo $nums2;?>" placeholder="" maxlength="50"  name="mesa2" required="true" type="text" />
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Fecha</label>
          <div class="col-sm-9">
          <input readonly="true" value="<?php  echo $fecha;?>" placeholder="" maxlength="50"  name="fecha" required="true" type="text" />
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Efectivo</label>
          <div class="col-sm-9">
          <input value="<?php  echo $efectivo;?>" placeholder="Efectivo"  required="true" name="efectivo" type="text" /> $ <?php  echo $tefectivo;?>
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Transferencia</label>
          <div class="col-sm-9">
          <input value="<?php  echo $tranferencia;?>" placeholder="Transferencia"  required="true" name="transferencia" type="text" /> $ <?php  echo $ttransferencia;?>
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Tarjeta</label>
          <div class="col-sm-9">
          <input value="<?php  echo $tarjeta;?>" placeholder="Tarjeta"  required="true" name="tarjeta" type="text" /> $ <?php  echo $ttarjeta;?>
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Nequi</label>
          <div class="col-sm-9">
          <input value="<?php  echo $nequi;?>" placeholder="Nequi"  required="true" name="nequi" type="text" /> $ <?php  echo $tnequi;?>
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Daviplata</label>
          <div class="col-sm-9">
          <input value="<?php  echo $daviplata;?>" placeholder="Daviplata"  required="true" name="daviplata" type="text" /> $ <?php  echo $tdaviplata;?>
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Extra</label>
          <div class="col-sm-9">
          <input value="<?php  echo $extras;?>" placeholder="Extras"  required="true" name="extras" type="text" />
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Gastos</label>
          <div class="col-sm-9">
          <input value="<?php  echo $gastos;?>" placeholder="Gastos"  required="true" name="gastos" type="text" />
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Base Caja</label>
          <div class="col-sm-9">
              <input value="<?php  echo $tbase;?>" readonly="true" placeholder="Base Caja"  required="true" name="Basecaja" type="text" />
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Total en caja: <?php  $totalcaja= $total ; echo $totalcaja;?></label>
          <div class="col-sm-9">
           / Total pagos: $ <?php  echo $ttotal;?>
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          <div class="input-group mb-3">
          <label  class="col-sm-9 control-label">Diferencia: <?php  
          
          $dife= $total-$ttotal-$tbase ;
          if($dife<0){
              
              echo '<div style=" color: red">'.$dife.'</div>';
          }else{
              if($dife==0){
                  echo $dife;
              }else{
             echo '+'.$dife;
          }}
          
          
          ?></label>
              <input value="<?php  echo $dife;?>"  name="diferencia" type="hidden" />

          <label></label>   
          </div><!--/form-group-->
          
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label">Comentarios:</label>
          <div class="col-sm-9">
          <textarea  placeholder="Comentarios"   name="comentarios"/><?php  echo $comentarios ;?></textarea>
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
          
          <div class="form-group">
                    <label  class="col-sm-3 control-label">Estado</label>
                  <div class="col-sm-9">
                      
                      <select required name="estados2" class="form-control" id="busqueda">
                   <option  value="<?php if($estado==1){ echo'1'; }else{ echo '0';} ?>"><?php if($estado==1){ echo'Habilitado'; }else{ echo 'Cerrado';} ?></option>  
                     <option value="<?php if($estado==1){ echo'0'; }else{ echo '1';} ?>"><?php if($estado==1){ echo'Cerrado'; }else{ echo 'Habilitado';}; ?> </option>
                     
                                       
                     </select>
                  </div><!--/col-sm-9-->
                  <label></label>   
                </div><!--/form-group-->
          <div class="input-group mb-3">
          <label  class="col-sm-3 control-label"></label>
          <div class="col-sm-9">
              <?php if($estado==0){} else { ?>
              <input value="Actualizar" name="Actualizar" required="true" type="submit" maxlength="2" max="20" min="1" />
              <?php } ?>
          </div><!--/col-sm-9-->
          <label></label>   
          </div><!--/form-group-->
                
          </form>
                   
                   <br>
                   <br>
                   
                   <?php }
                   
                   ?>
                          
                           <!-- Page Heading -->
                    
                    <!-- DataTales Example -->
                                  <div class="card shadow mb-4" style="width: 100%;">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary"></h6>
                        </div>
                        <div class="card-body">
                            
                            <div class="table-responsive">
                                <table class="table table-bordered"  id="dataTable" width="100%" cellspacing="0">
                                  <thead>
                              <tr>
                                
                                 
                                  <th>id</th>
                                  <th>Estado</th>
<!--                                  <th>Tipo</th>-->
                                  <th>Fecha</th>
                                  <th>Efectivo</th>
                                  <th>Transf.</th>
                                  <th>Tarjeta</th>
                                  <th>Daviplata</th>
                                  <th>Nequi</th>
                                  <th>Extras</th>
                                  <th>Gastos</th>
                                  <th>Base</th>
                                  <th>Total</th>
                                  <th>Diferencia</th>
                                  <th>Ver</th>
                                  
                                 
                                  
                                 
                              </tr>
           
                              <?php 
				
                                
                                
                                if ($tip_user==3){
				
				?>
                              </thead>
                              
                              <tbody>
                                  <?php 
                               
                                  
                                  $productos=$usuariosCon->all_arqueo();
					while ($pro=mysqli_fetch_object($productos)){
                                            
                                           
						$nums=$pro->id;
						$estadoc=$pro->estado;
						$refe=$pro->Fecha;
						$efectivo1=$pro->Efectivo;
						$tranferencia1=$pro->Transferencia;
						$Tarjeta1=$pro->Tarjeta;
						$daviplata1=$pro->Daviplata;
						$nequi1=$pro->Nequi;
						$extras1=$pro->Extras;
						$Gastos1=$pro->Gastos;
						$base1=$pro->base;
						$Total1=$pro->Total;
						$diferenciat=$pro->diferencia;
                                                 
						
                                               
                                                
				?>
                              <tr class="">
                                  
                             
                                                               
                                  
                                  <td><?php echo $nums;  ?></td>
                                  <td><?php if($estadoc==1){ echo'Habilitado'; }else{ echo 'Cerrado';} ?></td>
<!--                              <td><?php //echo $comen;?></td>-->
                                  <td><?php echo $refe;?></td>
                                  <td><?php echo $efectivo1;?></td>
                                  <td><?php echo $tranferencia1;?></td>
                                  <td><?php echo $Tarjeta1;?></td>
                                  <td><?php echo $daviplata1;?></td>
                                  <td><?php echo $nequi1;?></td>
                                  <td><?php echo $extras1;?></td>
                                  <td><?php echo $Gastos1;?></td>
                                  <td><?php echo $base1;?></td>
                                  <td><?php echo $Total1;?></td>
                                  <td><?php   
                                  if($diferenciat<0){
              
              echo '<div style=" color: red">'.$diferenciat.'</div>';
          }else{
              if($diferenciat==0){
                  echo $diferenciat;
              }else{
             echo '+'.$diferenciat;
          }}
                                  ?></td>
                                  <td> <form method="post" action="">
                                    <input value="<?php echo $nums;?>" type="hidden" name="pedido" >
                                    <input value="Ver" type="submit" name="Ver" >
                                          
                                      </form> </td>
                                  
                                  
                                      
                               </form>
                                  
                              </tr>
                              <?php
					}
                                        
                                }
				?>
                          
                        
                                </table>
                            </div>
                        </div>
                   
                    </div>

                </div>
                    
 
            </div><!--/porlets-content--> 
                   
                   
                   
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

   

    <?php include './footer.php'; ?>

</body>

</html>

 <?php } ?>