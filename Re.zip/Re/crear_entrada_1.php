 <?php   session_start(); 
 @$user = $_SESSION["k_username"]; 
 @$tip_user = $_SESSION["tipo_user"];
 @$EmpresAct = $_SESSION["EmpresAct"];
 @$Cod_Empresa = $_SESSION["Cod_Empresa"];
 @$Numdoc = $_SESSION["Numdoc"];
 
 if($user== null){
          
     ?>
     
     <script language="javascript" type="text/javascript">                        
		window.location="logout.php";
		</script>
     <?php
 }else{
 
 ?>
<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Entrada</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
     <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
   <?php   include 'class/menu.php' ?>
<?php   include './menu_user.php';
include './class/usuarios.php';
                                $Conexion = new Usuarios();

?>
        
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <?php   include './menu_notifi.php'; ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                   <!-- Content Row -->
                   
                   <?php
                   
                   if ($_SERVER["REQUEST_METHOD"] == "POST") { 
    
    
  @$numero=$_POST["cod_p"];
  @$uni=$_POST["unidades"];
  @$alma=$_POST["almacen"];
  @$comentarios=$_POST["comen"];
 
  
    $count = count($numero);
    
        $ress = $Conexion->Cuentaentrada();
        $rows3=mysqli_fetch_object($ress);
        $cuenta_l=$rows3->num_salida;
        $num_salida=$rows3->id;
        
        if($cuenta_l==0){
          $salidab=$num_salida;
		  
		 
        }else{
        
        $res3 = $Conexion->crea_entrada($comentarios);
        $res4 = $Conexion->salida_b3();
        $row43=mysqli_fetch_object($res4);
        $salidab=$row43->id;
		
        }
        $cuenta= 0;
        
        
    ?>

                   <h2>No. de la Entrada: <?php echo $salidab; ?></h2>   <br>                
<?php
    for ($i = 0; $i < $count; $i++) {
        $cuenta++;
       $num = $numero[$i];      
       $unidades = $uni[$i];
       $almacen = $alma[$i];
       $res53 = $Conexion->prod_b($num);      
       $row53=mysqli_fetch_object($res53);      
       @$stock2=$row53->Stock;
       @$precio=$row53->precio;
       $ncantidad= $stock2+$unidades;
       $preciof= $precio*$unidades;
       if($ncantidad<0){
           
           echo 'No se puede realizar la salida, porque el inventario recae en negativo cod producto: '.$num.'<br>';
       }else{
       // crea linea de la salida
       if ($num==null or $unidades == null ){
           echo 'no se puedo realizar las entrada la linea se econtraba vacia';
       }else{
        // consultar stock del item
       
        
        $res = $Conexion->udpates($num,$ncantidad);
        
         $res = $Conexion->crea_entradalinea($salidab,$num,$unidades,$precio,$preciof,$almacen,$ncantidad);
        
       ?>
                   
                   <div class="container" style="background-color: whitesmoke;">
                       
                       <?php echo $cuenta.' / Cod Producto: '.$num.' '.' / Catidad: '.$unidades.' / Almacen: '.$almacen;
                       echo ' / Operacion Correcta';
                       ?>
                   </div>
                   <br>
        
        <?php
        
       }  }
}

    }
                   
                   ?>
                   
                   
                           <!-- Page Heading -->
                           <br>
                           Comentarios: <?php echo $comentarios; ?> 

                </div>
                    
 
            </div><!--/porlets-content--> 
                   
                   
                   
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

   

    <?php include './footer.php'; ?>

</body>

</html>

 <?php } ?>
