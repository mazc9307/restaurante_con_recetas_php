 <?php   session_start(); 
 @$user = $_SESSION["k_username"]; 
 @$tip_user = $_SESSION["tipo_user"];
 @$EmpresAct = $_SESSION["EmpresAct"];
 @$Cod_Empresa = $_SESSION["Cod_Empresa"];
 @$Numdoc = $_SESSION["Numdoc"];
 
 if($user== null){
          
     ?>
     
     <script language="javascript" type="text/javascript">                        
		window.location="logout.php";
		</script>
     <?php
 }else{
 
 ?>
<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Permisos</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
   <?php   include 'class/menu.php' ?>
<?php   include './menu_user.php'; ?>
        
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <?php  
               
               include './menu_notifi.php'; ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    
             
                   <!-- Content Row -->
                   
                        
                 
              <div class="row">
         
                
          <div >
            <div>
                
               <h3 >Asignar permisos</h3>
              <div>
                  <form method="post"  role="form">
                  <div >
                    <label >Solicita a:</label>
                  <div >                      
                      <select required name="usuario" class="form-control">
                        <option value="">Seleccione una opcion </option>
                            <?php   include 'class/usuarios.php' ?>
                      <?php        
                      
                      
                      $usuariosCon = new Usuarios();
                       $permisos=$usuariosCon->usuario2();
					while ($row=mysqli_fetch_object($permisos)){
						$R1=$row->Numdoc;
						$R2=$row->Nombre;
						$R3=$row->descripcion_area;
						$R4=$row->usuario;
                                             
				?>
                    
                     <option value="<?php echo $R1; ?>"><?php echo $R2.' - usuario: '.$R4; ?> </option>
                     
                                        <?php } ?>
                     </select>
                  </div><!--/col-sm-9-->
                  
                  <label></label>   
                </div><!--/form-group-->
                 <?php
                  $premisos2=$usuariosCon->menu_user2();
                    while ($row=mysqli_fetch_object($premisos2)){
						$cod_menu2=$row->Cod_menu;
						$Nom_menu2=$row->Nombre_menu;
						$icono2=$row->icono;
      
                                
        
        ?>
                  
                  
                  
                  <h5><?php echo $Nom_menu2; ?></h5>
                   <?php 
               $sub=$usuariosCon->submenus($cod_menu2);
               while ($row=mysqli_fetch_object($sub)){
                                                $Nom_sub=$row->Nombre_submenu;
						$link=$row->Link;
						$cod_sub=$row->Cod_submenu;
               
               ?> 
                <ul >
                    <li >
                    <label >
                        
                        <input name="numero[]" value="<?php echo $cod_sub; ?>"  type="checkbox"></input>
                    <span></span> </label>
                    <?php echo $Nom_sub; ?> <span> <a  href="#"><i class="fa fa-times"></i></a> </span> </li>
                    
                   <?php } ?> 
                    
                </ul>
          <?php }?>
                  
                
                    <button  type="submit"><i class="fa fa-plus"></i> Asignar Permisos</button>
                    <br></br>
                  </form>
                <!-- /list-group -->
              </div>
              <!--/porlets-content-->
            </div>
            <!--/block-web-->
           
          
        </div>
        <!--/row end-->
        <div class="col-sm-4 ">
              <?php include './class/permiso-crea.php'; ?>
              
               
          </div>
          <!--/col-md-4 end-->
        
        
        
         
        
      </div>
            
            
   
   


            </div>       
     
            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

   

    <?php include './footer.php'; ?>

</body>

</html>

 <?php } ?>