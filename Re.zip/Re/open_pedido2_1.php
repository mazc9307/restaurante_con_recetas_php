 <?php   session_start(); 
 @$user = $_SESSION["k_username"]; 
 @$tip_user = $_SESSION["tipo_user"];
 @$EmpresAct = $_SESSION["EmpresAct"];
 @$Cod_Empresa = $_SESSION["Cod_Empresa"];
 @$Numdoc = $_SESSION["Numdoc"];
 
 $pedido_o=$_GET["pedido"];
 
 if($pedido_o==null){
 
     ?>
     
     <script language="javascript" type="text/javascript">                        
		window.history.back();
		</script>
     <?php
 }
 
 if($user== null){
          
     ?>
     
     <script language="javascript" type="text/javascript">                        
		window.location="logout.php";
		</script>
     <?php
 }else{
 
 ?>
<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Pedido Estado</title>

    <!-- Custom fonts for this template-->
    
    
    <!-- Custom styles for this template-->
    
<style type="text/css"> body {
    font-size:20px;
	}
  </style>
</head>

</head>

<body >

    <!-- Page Wrapper -->
 
   <?php   include 'class/menu.php' ?>
<?php   
        include ('class/usuarios.php');
	$usuariosCon = new Usuarios();
        
        $numpropina=$usuariosCon->countpropina($pedido_o); 
        $rowpr=mysqli_fetch_object($numpropina);
        $numpr=$rowpr->num;
                         
       if($numpr==0){
                                
        @$propina2 =$_POST["propina"];
        
        if ($propina2>0) {
            $pedidoLinea2=$usuariosCon->creapedidolineas3($pedido_o,$propina2);
            
                                }}
                
                ?>
 <center style="color:red;font-size:12px;">
 Comercializadora Soul 45 sas<br>
 Nit 901.413.688-8<br> 
 Cll 45 # 19-30<br>
 Autorizado el 2021-01-16 del No. 1 al 10.000<br>
 # de autorizacion 18764009736407
 
 <br><br><br>
 					
                   
                                Pedido No.:
                                <?php 
                                $numeropedido=$usuariosCon->all_pedidos_num($pedido_o); 
                                $rowp=mysqli_fetch_object($numeropedido);
                                $numpedido=$rowp->Cod_pedido;
                                $totalpedido=$rowp->linea_total;
                                echo $numpedido;
                                ?>
                                <br>
							

                             
                              <?php 

				$listado=$usuariosCon->all_pedidos_open($pedido_o);
				?>
                              
                                  <?php 
                                  $num =1;
					while ($row=mysqli_fetch_object($listado)){
                                            
                                            
						$Cod_pedido=$row->Cod_pedido;
                                                $mesa=$row->mesa;
						$usuario=$row->usuario;
						$Descripcion_ep=$row->Descripcion_ep;
						$Fecha=$row->Fecha;
                                                $n_cliente=$row->n_cliente;
                                                $Doc_cliente=$row->Doc_cliente;
                                                $Tel_cliente=$row->Tel_cliente;
                                                $dir_cliente=$row->dir_cliente;
                                                $cor_cliente=$row->correo_cliente;
						
						
			
                                                
				?>
                                  
                                
                                 Mesa No.<?php echo $mesa;?><br>
                                 Usuario: <?php echo $usuario;?><br>
                                 Estado <?php echo $Descripcion_ep;?><br>
                                 Fecha: <?php echo $Fecha;?><br>
								
                                  
                                  
                           <br>
                            
                                 <b>Datos Cliente</b>
                            <br>
                                 
                                  
                                  <table>
                                  <tr><td>Nombre: <?php echo $n_cliente;?></td></tr>
                                  <tr><td>Documento: <?php echo $Doc_cliente;?></td></tr>
                                  <tr><td>Telefono: <?php echo $Tel_cliente;?></td></tr>
                                  <tr><td>Correo: <td><?php echo $cor_cliente;?></td></tr>
                                  <tr><td>Direccion: <td><?php echo $dir_cliente;?></td></tr>
								  </table>
                                  
                            
                              
                                 <?php
                                  
                                  }
                                        
                                
				?>
                          
                        
                                
                                        
                                    
                                 <?php 
                                  $numpedido = $pedido_o;
                                  
                                  
                                  $listadopro=$usuariosCon->mesa_pedido_suma_linea2($numpedido); 
                                  while ($rowlp=mysqli_fetch_object($listadopro)){
                                            
                                            
						$cod_producto=$rowlp->cod_producto;
						$Descripcion_p=$rowlp->Descripcion_p;
						$cant=$rowlp->cant;
						$price=$rowlp->precio;
						$lt=$rowlp->lt;
                                  
                                  ?>
                                  
                                  
								  <table>
								  <tr><td><?php echo $Descripcion_p; ?> /
                                  Unid:(<?php echo $cant; ?>)/
                                  ($<?php echo $price; ?>)/
								  </td><td>
                                  ($<?php echo $lt; ?>)</td></tr>
								 
								  </table>
								  
									
                                
                    
        
                            
                                                        <?php
                                                        
                                                    }
                    
                    ?>
                      <br>
								  <b>Total a pagar:$ <?php echo $totalpedido; ?></b>
                
                  </center>  
				  
				  <br>
				  <br>
                    
                
  <?php 
  
  @$pedl = $_POST['pedidolinea'];
  $sstockprf=$usuariosCon->Actualizar_impr($pedl);
  
  ?>

</body>

</html>

 <?php } ?>
