 $(document).ready(function() {   
     
     document.getElementById("btn-ingresar").addEventListener('click',validarEstado,false);
   
     
     function validarEstado (){
                var url = "cocina2.php";                                      
		$.ajax({                        
		   type: "POST",                 
		   url: url,                    
		   data: $("#enviar").serialize(),
                   
                   beforeSend: function(){
		//imagen de carga
                    $("#resp").html("<p align='center'><img src='imagenes/ajax-loader.gif' /></p>");
								   },
                    error: function(){
                    alert("error peticion ajax");
                    },
		success: function(data){                                                    
		$('#resp').html(data);  
										
									}
		  
		 });
   
   }
            
        });


