
<?php
include './class/usuarios.php';
 $usuariosCon = new Usuarios();

 $idcat = $_POST["b"];
?>

  <div class="input-group mb-3">
                    <label  class="col-sm-3 control-label">Sub Categoria</label>
                  <div class="col-sm-9">
                      
                      <select  name="subcate" class="form-control">
                      <option value="<?php echo 0; ?>"><?php echo 'seleccione una opcion'; ?></option>
                      <?php             $listadoemp=$usuariosCon->b_subcate($idcat);
					while ($row=mysqli_fetch_object($listadoemp)){
						$Nit=$row->id_s;
						$descripcionemp=$row->subcategoria;
						$No=$row->No;
				?>
                    
                     
                     <option value="<?php echo $Nit; ?>"><?php echo $descripcionemp; ?></option>
                     
                                        <?php } ?>
                     </select>
                  </div><!--/col-sm-9-->
                  <label></label>   
                </div><!--/form-group-->