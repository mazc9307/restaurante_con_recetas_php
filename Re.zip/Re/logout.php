<?php
session_start();
@$user = $_SESSION["k_username"];
// Borramos toda la sesion

include './class/menu.php';
$menu = new Menu();
 $online=$menu->up_offline(@$user);
session_destroy();
?>
<SCRIPT LANGUAGE="javascript">
location.href = "login.php";
</SCRIPT>