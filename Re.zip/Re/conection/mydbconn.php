

<?php

$con=mysqli_connect("localhost:4040","root","123456","bar") or 
      die("Problemas con la conexion a la base de datos");

//Gbar2120* 3307
	  
?>

