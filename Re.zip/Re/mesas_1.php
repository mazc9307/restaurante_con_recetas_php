
                                              <?php   include './class/usuarios.php'; 
                      
                            $usuariosCon = new Usuarios();
                            $usero=$usuariosCon->user_on();
                      
                            ?>
<div class="card mb-4" style="width: 18rem;">
    <div class="card-header">Usuarios conectados</div>
<div class="card-body">
                            <div class="table-responsive">
                <table class="table table-bordered">
              
                <tbody>
                
                            
                            <?php
                            
                                while ($row2=mysqli_fetch_object($usero)){
						$useronline=$row2->usuario;
						
                                         
                                                 ?>
          
                <tr>
                    <td>   <?php echo $useronline; ?></div></td>
                    <td><div class="btn btn-success btn-circle btn-sm"></td>
                </tr>
                    <?php 
                
            
                                                        
                                }
                            
                                ?>
                </tbody>
                </table>
                            </div>
                            </div>
                            </div>
    
                                <?php
                            
                            
                                $listmesas=$usuariosCon->mesas();
                      
                                while ($row=mysqli_fetch_object($listmesas)){
						$No=$row->No;
						$esm=$row->estado;
						$afo=$row->Aforo;
						$esmesa=$row->estado_mesa;
						
                                
                      ?>
                        <!-- Earnings (Monthly) Card Example -->
                        <form method="post" action="pedido.php" style="display: inline-block;">
                            <input type="hidden" name="m" value="<?php echo $No; ?>">
                            <input type="hidden" name="estadomesa" value="<?php echo $esmesa; ?>">
                            <button style=" border: none;">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Mesa No. <?php echo $No ;?></div>
                                            <div class=" mb-0 font-weight-bold text-gray-800">Estado: <?php echo $esm ;?></div>
                                            <div class=" mb-0 font-weight-bold text-gray-800">Aforo: <?php echo $afo ;?></div>
                                            
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-table fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </button>
</form>
                
                        <?php } ?>
    </div>